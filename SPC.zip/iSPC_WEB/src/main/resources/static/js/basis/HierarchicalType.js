var left_Id;//左边table中的id
var right_Id;//右边childsTable中的id
var public_Url="productModel/";//公共controller
var right_Title="";//右边childsTable中的标题
var flag = true;//查询左边表用到的变量
var bx_id=1;//点击备选值时的层次号
var xg_id=1;//点击修改时的层次号


//新增按钮，弹出模态框
function showAdd(){
	$("#myModalThree").modal('show');
}

//增加方法
function add(){
	if($("#maintainNames").val()==""){//判断文本框内容是否为空
		toastr.warning("名称不得为空!");
		return false;
	}
	$.ajax({
		url:public_Url+"add.action",
        type: "POST",
        dataType:"JSON",
        data:{
        	name:$("#maintainNames").val()//新增只传name，获取文本框输入的值
        },
        success: function(data) {
        	if(data.code == "0000"){
        		toastr.success(data.message);
        		$('#tableChilds').bootstrapTable('refresh');//刷新表
        		$("#maintainNames").val('');//清空文本框
        		$("#myModalThree").modal('hide');//隐藏模态框
        	}else{
        		toastr.error(data.message);
        	}
        },
        error: function(data) {
        	toastr.error(data.message);
        },
	});
}

//修改层次名称弹窗确定按钮
function updateOne(){
	$.ajax({
		url:"type/update.action",
        type: "POST",
        dataType:"JSON",
        data: {
				"id" : left_Id,//修改层次名称传id，name
				"name" : $("#hierarchyName").val()
			},
        success: function(data) {
        	if(data.code == "0000"){
        		toastr.success(data.message);
        		if(xg_id==bx_id){//修改层次名称后，备选值标题也要随之改变
        			 $("#updateTitle").html( $("#hierarchyName").val()+"备选值");//根据输入值更新标题
        		}
        		 showTable();
        		$("#myModalOne").modal('hide');//隐藏模态框
				$("#hierarchyName").val('');//清空文本框
        	}else{
        		toastr.error(data.message);
        	}
        },
        error: function(data) {
        	toastr.error(data.message);
        },
	});
}

function updateTwo(){
	if($("#maintainName").val()==""){//判断文本框内容是否为空
		toastr.warning("名称不得为空!");
		return false;
	}
	$.ajax({
		url:public_Url+"update.action",
        type: "POST",
        dataType:"JSON",
        data:{
			"id" : right_Id,//修改传id,name,state,state=1为修改,state=0为删除
			"name" : $("#maintainName").val(),
			"state":1
		},
        success: function(data) {
        	if(data.code == "0000"){
        		toastr.success(data.message);
        		$('#tableChilds').bootstrapTable('refresh');//修改完后，刷新右边表
        		$("#myModalTwo").modal('hide');
				$("#maintainName").val('');
				
        	}else{
        		toastr.error(data.message);
        	}
        },
        error: function(data) {
        	toastr.error(data.message);
        },
	});
}

function operate(value, row, index) {
	var str = "";
	str += '<a class="btn btn-warning btn-xs updateDetail">修改</a>&nbsp';
    str += '<a class="btn btn-info btn-xs detail">备选值</a>&nbsp';
	return str;
}
/**
 * 操作点击事件
 */
window.operateEvents = {
		'click .updateDetail' : function(e, value, row, index) {
			$("#myModalOne").modal('show');
			$("#hierarchyName").val(row.name);//获取名称
			left_Id=row.id;//给变量赋值，cch相当于id
			xg_id=row.id;//点击修改时，把层次id赋值给xg_id
		},
		'click .detail' : function(e, value, row, index) {//点击备选值时
			switch(row.id){
			case 1:
				public_Url="productModel/";
			  break;
			case 2:
				public_Url="productName/";
			  break;
			case 3:
				public_Url="productLine/";
			  break;
			case 4:
				public_Url="productRank/";
			  break;
			case 5:
				public_Url="equipment/";
			  break;
			case 6:
				public_Url="supplier/";
			  break;
			case 7:
				public_Url="client/";
			  break;
			case 8:
				public_Url="batch/";
			  break;
			case 9:
				public_Url="workNumber/";
				
			  break;
			}
			bx_id=row.id;//点击备选值时，把层次id赋值给bx_id
			$("#updateTitle").html(row.name+"备选值");//根据表内的name字段更新右边表标题
			showChildsTable(public_Url);
		}
};


function operateChilds(value, row, index) {
	var str = "";
    str += '<a class="btn btn-warning btn-xs updateChilds">修改</a>&nbsp';
    str += '<a class="btn btn-danger btn-xs  deleteChilds">删除</a>&nbsp';
    return str;
}
/**
 * 操作点击事件
 */
window.operateChildsEvents = {
		'click .updateChilds' : function(e, value, row, index) {
			$("#myModalTwo").modal('show');
			$("#maintainName").val(row.name);
			right_Id=row.id;//赋值给右边childsTable中的id
		},
		'click .deleteChilds' : function(e, value, row, index) {//删除
			Showbo.Msg.confirm('确认删除？',function(btn){
				if(btn == "yes"){
					$.ajax({
						url:public_Url+"update.action",
				        type: "POST",
				        dataType:"JSON",
				        data:{
				        	id:row.id,
				        	state:0
				        },
				        success: function(data) {
				        	if(data.code == "0000"){
				        		toastr.success(data.message);
				        		$('#tableChilds').bootstrapTable('refresh');
				        	}else{
				        		toastr.error(data.message);
				        	}
				        },
				        error: function(data) {
				        	toastr.error(data.message);
				        },
					});
				}
			})
		}
};

showTable();


function showTable() {
	$('#table').bootstrapTable('destroy').bootstrapTable({		
		striped : false, // 是否显示行间隔色
		pagination : true, // 是否显示分页（*）
		sortable : false, // 是否启用排序
		sortOrder : "asc", // 排序方式
        toolbar:"#toolbar",
		pageNumber : 1, // 初始化加载第一页，默认第一页
		pageSize : 10, // 每页的记录行数（*）
		pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
		strictSearch : true,
		clickToSelect : true, // 是否启用点击选中行
		height : 412, // 行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		columns : [ 
       {
    	   field : "id",
    	   title : "层次号",
    	   align:"center",
       }, 
       {
		field : 'name',
		title : "名称",
		align:"center"
	   }, 
		 {
			field : "",
			title : "操作",
			align:"center",
			formatter : operate,
			events : operateEvents,
		}		
		],
		onLoadSuccess : function(data) {
			console.log(data);
		},
	});
	
	$.ajax({
		url:"type/search.action",
        type: "GET",
        dataType:"JSON",
        data:{},
        success: function(data) {
        	if(data.code == "0000"){
        		$('#table').bootstrapTable('load',data.rows);
        		if(flag){
            		 left_Id=data.rows[0].id;
            		 $("#updateTitle").html(data.rows[0].name+"备选值");//右边表初始值
            		 showChildsTable(public_Url);
            		 flag=false;
        		}
        	}else{
        		toastr.error(data.message);
        	}
        },
        error: function(data) {
        	toastr.error(data.message);
        },
	});
	
};


function showChildsTable(url) {//url参数
	$('#tableChilds').bootstrapTable('destroy').bootstrapTable({
		url : url+"search.action",//url为公共路径
		queryParams : function(params){
			var temp = { //这里的键的名字和控制器的变量名必须一直，这边改动，控制器也需要改成一样的  
					limit : params.limit,// 每页记录数
					offset : params.offset,// 从第几条记录开始
				};
			return temp;
	},//传递参数（*） 
		sidePagination : "server", //分页方式：client客户端分页，server服务端分页（*）  
		striped : false, // 是否显示行间隔色
		pagination : true, // 是否显示分页（*）
		sortable : false, // 是否启用排序
		sortOrder : "asc", // 排序方式
        toolbar:"#toolbar",
		pageNumber : 1, // 初始化加载第一页，默认第一页
		pageSize : 10, // 每页的记录行数（*）
		pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
		strictSearch : true,
		clickToSelect : true, // 是否启用点击选中行
		uniqueId:"id",
		height : 412, // 行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		columns : [ 
       {
		field : 'name',
		title : '名称',
		align:"center",
		
	   }, 
	   {
			field : '',
			title : '操作',
			align:"center",
			formatter : operateChilds,
			events : operateChildsEvents
		}		
		],
		onLoadSuccess : function(data) {
		}
	});
};