package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.ControlChartInfomation;

public interface ControlChartInfomationMapper {
    int delete(Integer kztxxId);

    int insert(ControlChartInfomation record);

    ControlChartInfomation findById(Integer kztxxId);

    int update(ControlChartInfomation record);

    List<ControlChartInfomation> findByCondition(Map<String,Object> map);
    
    int count(Map<String,Object> map);
}