package com.nbst.service;

import java.util.Map;

import com.nbst.model.ControlChartInfomationHierarchicalInformationRelationship;

/**
 * 表头数据查找
 * 
 * @param ControlChartInfomationHierarchicalInformationRelationship 层次信息
 * @author lijiajun
 * @return
 */
public interface IControlChartHeadDataService {

	Map<String, Object> updateControlChartHeadData(
			ControlChartInfomationHierarchicalInformationRelationship controlChartInfomationHierarchicalInformationRelationship);
}
