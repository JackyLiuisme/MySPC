package com.nbst.dao.datasource;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Slf4j
@Component
public class DataSourceAspect {
	private static final Logger LOG = LoggerFactory.getLogger(DataSourceAspect.class);
	@Around("execution(* com.nbst.dao.mapper.ispcweb.*.*(..))")
	public Object privMapper(ProceedingJoinPoint joinPoint) throws Throwable{
		if(DynamicDataSourceHolder.getDataSource() == null){
			DynamicDataSourceHolder.setDataSource("spcDataSource");
			LOG.debug("切换到spc数据源");
		}
		return joinPoint.proceed(joinPoint.getArgs());
	}
}
