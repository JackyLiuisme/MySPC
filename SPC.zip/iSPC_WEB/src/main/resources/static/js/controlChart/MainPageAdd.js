var flag=1;//用与判断保存按钮调用的方法
var groupId=1;//分组id
var kztBh=1;//控制图编号
var kztList_id;//控制图列表id
var kzt_Bt="控制图管理";//初始化表标题
var public_Url;//公共controller
var flags=true;
var level1,level2,level3,level4,level5,level6,level7,level8,level9;

$(document).ready(function() {//当没有选中结点时，不显示修改，删除，新增控制图
//	showTree();
	setTimeout(function(){
		showTree();
//		change();
		$("#addLevel").show();
		$("#addLeaf").hide();
		$("#modify").hide();
		$("#remove").hide();
		$("#mainAdd").hide();		
		$.ajax({
			url:"controlChartMessage/searchTypeLevelName.action",
	        type: "GET",
	        dataType:"JSON",
	        data: {},
	        success: function(data) {
	        	if(data.success == "0000"){
	        		for(var i=0;i<data.rows.length;i++){
	        			if(data.rows[i].ccmcName!=""){//层次名称不为空，则查询他的备选值
	        				var head={
	        						field:'cc' + (i+1),
	        						title:data.rows[i].ccmcName,
	        						align:"center"
	        						};
		        			shuzu.splice(5+i,0,head);//从第五个开始插入表头
		        			var str="cc"+(i+1);
		        			$("#"+str).html(data.rows[i].ccmcName);//给控制图层次信息赋值
		        			switch(i){
			        			case 0:
			        				public_Url="productModel/";
			        			  break;
			        			case 1:
			        				public_Url="productName/";
			        			  break;
			        			case 2:
			        				public_Url="productLine/";
			        			  break;
			        			case 3:
			        				public_Url="productRank/";
			        			  break;
			        			case 4:
			        				public_Url="equipment/";
			        			  break;
			        			case 5:
			        				public_Url="supplier/";
			        			  break;
			        			case 6:
			        				public_Url="client/";
			        			  break;
			        			case 7:
			        				public_Url="batch/";
			        			  break;
			        			case 8:
			        				public_Url="workNumber/";
		        			  break;
		        			}
		        			searchType(public_Url,i);
	        			}	
	        		}
	        		
//	        		console.log(shuzu);
	        		showKztList();
	        	}else{
	        		toastr.error(data.message);
	        	}
	        },
	        error: function(data) {
	        	toastr.error(data.message);
	        },
		});
	}, 150)
});

function searchType(url,i){//调用查询备选值接口
	$.ajax({
		url:url+"search.action",
        type: "GET",
        dataType:"JSON",
        data:{},
        success: function(data) {
        	if(data.code == "0000"){
        		if(flags){
        			var str = i+1;
        			eval("level"+str+'='+'(data.rows)');//level保存所有备选值
//        			console.log(eval(("level"+str)));
        			$("#level"+str).html(eval("level"+str));
        		}
        	}else{
        		toastr.error(data.message);
        	}
        },
        error: function(data) {
        	toastr.error(data.message);
        },
	});
}

function showBXZ(){//选项显示备选值
	for(var i=0;i<9;i++){
		var arr=eval("level"+(i+1));
		var html="";
//		console.log(arr.length);
		for(var j=0;j<arr.length;j++){
//			console.log(arr[j]);
			html += "<option value='"+arr[j].id+"'>"+arr[j].name+"</option>";
		}
//		console.log(html);
		$("#level"+(1+i)).html(html);//给选项赋值
	}
	
}




/********************************主页面****************************/
function showTree(){
	$(document).ready(function() {
		$(document).ready(function() {
			$.ajax({
				url : "group/searchTree.action",
				type : 'GET',
				dataType : 'jsonp',
				data : {},
				success : function(data) {
					//加载有数据的树形
					$.fn.zTree.init($("#menu"), setting, data.rows);
					var zTree = $.fn.zTree.getZTreeObj("menu");
					var nodes = zTree.getNodes();
					zTree.expandAll(true);//默认展开全部结构
				},
				error:function(data){
				},xhrFields: { withCredentials: true }
			})
		});
	});	

}

//配置树形
var setting = {
	async : {
		enable : true,
//			url : zTreeUrl(),
//		    type : "GET",
//			dataFilter : filter
	},
	view : {
		selectedMulti : false,
		showIcon : false,
	    fontCss : {"color":"black"},
	},
	edit : {
		enable : true,
		showRemoveBtn : false,
		showRenameBtn : false
	},
	data : {
		keep: { parent:true, leaf:true }, 
		simpleData : {
			enable : true,
		}
	},
	callback : {
		onClick : onClick,
//		onAsyncSuccess: zTreeOnAsyncSuccess
	}
};

/*
 * @Description: 点击节点事件
 * @param : event	js event对象
 * @param : treeId	对应zTree的treeId
 * @param : treeNode	被点击的节点JSON数据对象
 * @param : clickFlag	节点被单击后的选中类型
 */
function onClick(event, treeId, treeNode, clickFlag) {//鼠标点击方法
	if(treeId == "menu"){
		menuName=treeNode.name;
		sblxstate=2;
		pId = treeNode.pId; 
		id = parseInt(treeNode.id);
		groupId=parseInt(treeNode.id);//分组id （控制图方法）
		$("#addLevel").show();
		$("#addLeaf").show();
		$("#modify").show();
		$("#remove").show();
		$("#mainAdd").show();
		$("#kztBt").html(treeNode.name);//根据点击的zTree节点更新表头
//		var id=1;
//		showKztList(id);
//		showParts();
	}
}

/**
 * 删除
*/
function remove(data){
	var zTree = $.fn.zTree.getZTreeObj("menu");//获取zTree对象
	nodes = zTree.getSelectedNodes();
	treeNode = nodes[0];
	if (nodes[0].children != undefined) {//判断该节点是否有下级目录
		if(nodes[0].children==""){
			Showbo.Msg.confirm('确认删除？',function(btn){
				if(btn == "yes"){
					var data = {};
					data.fzId = treeNode.id;
					data.fzExtend2 = 0;
					removeSure(data);//调用方法，传data
				}
			})	
			return;
		} else{
			toastr.warning("该分类已有下级不能删除！！！");
			return;
		}
	}
	Showbo.Msg.confirm('确认删除？',function(btn){
		if(btn == "yes"){
			var data = {};
			data.fzId = treeNode.id;
			data.fzExtend2 = 0;
			removeSure(data);
		}
	})
}
function removeSure(data){//点击确认删除后调用接口
	var zTree = $.fn.zTree.getZTreeObj("menu");
	nodes = zTree.getSelectedNodes(),
	treeNode = nodes[0];
	$.ajax({
		url:"group/update.action",
        type: "POST",
        dataType:"JSON",
        data : data,
        success: function(data) {
        	if(data.code=="0000"){
        		toastr.success(data.message);
        		zTree.removeNode(treeNode);
        	}else{
        		toastr.warning(data.message);
        	}
        },
        error: function(request) {
        	toastr.error('系统出错,请联系管理员');
        },xhrFields: { withCredentials: true }
	});
}

//修改按钮，弹出模态框
function showModify(){
	$("#myModalOne").modal('show');
}

//新增同级按钮，弹出模态框
function showAddLevel(){
	$("#myModalTwo").modal('show');
}

//新增下级按钮，弹出模态框
function showAddLeaf(){
	$("#myModalThree").modal('show');
}

/**
修改
*/
function modify(data){
	var zTree = $.fn.zTree.getZTreeObj("menu")
	nodes = zTree.getSelectedNodes(),
	treeNode = nodes[0];
	$.ajax({
		url:"group/update.action",
        type: "POST",
        dataType:"JSON",
        data : {
        	fzId : treeNode.id,			//分组id【必传】
        	fzName : $("#modifyText").val(),    //分组名称【必传】
        	fzExtend2 : "1" ,		//状态
        },
        success: function(data) {
        	if(data.code=="0000"){
        		toastr.success(data.message);
        		treeNode.name = $("#modifyText").val();
				zTree.updateNode(treeNode);
        		$("#modifyText").val('');//清空文本框
        		$("#myModalOne").modal('hide');//隐藏模态框
        	}else{
        		toastr.warning(data.message);
        	}
        },
        error: function(request) {
        	toastr.error('系统出错,请联系管理员');
        },xhrFields: { withCredentials: true }
	});
}

function addLevel(data){
	var zTree = $.fn.zTree.getZTreeObj("menu");
	nodes = zTree.getSelectedNodes();
	treeNode = nodes[0];
	if(nodes.length==0){
		$.ajax({
			url:"group/add.action",
	        type: "POST",
	        dataType:"JSON",
	        data : {
//	        	fzId : treeNode.id,			//分组id【必传】
	        	fzName : $("#addLevelText").val(),    //分组名称【必传】
	        	fzExtend2 : 1,
	        	fzExtend1 : 0,		//分组父id
	        },
	        success: function(data) {
	        	if(data.code == "0000"){
		        		var zTree = $.fn.zTree.getZTreeObj("menu");
		        		var nodes = zTree.getNodes();
		        		treeNode = nodes[0];
		        		treeNode = zTree.addNodes(null, {
							id : data.id,
							pId : -1,
							name : $("#addLevelText").val(),
						});
		        		showTree();
		        		toastr.success(data.message);
		        		$("#addLevelText").val('');//清空文本框
		        		$("#myModalTwo").modal('hide');//隐藏模态框
		        		$("#addLevel").show();
		    			$("#addLeaf").show();
		    			$("#modify").show();
		    			$("#remove").show();
		    			$("#mainAdd").show();
//		        		reset();
	        	}else if(data.code == "9999"){
	        		toastr.warning("存在同名类型");
	        	}else if(data.code == "9997" ){
	        		toastr.error(data.message);
	        	}
	        },
	        error: function(request) {
	        	toastr.error('系统出错,请联系管理员');
	        },xhrFields: { withCredentials: true }
		});
	}else{
		var pid;
		if(treeNode.pId==null || treeNode.pId==0){
			pid=0;
		}else{
			pid=treeNode.pId;
		}
		$.ajax({
			url:"group/add.action",
	        type: "POST",
	        dataType:"JSON",
	        data : {
	        	fzName : $("#addLevelText").val(),    //分组名称【必传】
	        	fzExtend1 : pid ,		//分组父id
	        	fzExtend2:1
	        },
	        success: function(data) {
	        	if(data.code == "0000"){
		        		var zTree = $.fn.zTree.getZTreeObj("menu")
		        		var  nodes = zTree.getSelectedNodes();
	                    var  treeNode = nodes[0];
		        		treeNode = zTree.addNodes(treeNode.getParentNode(), {
							id : data.id,
							pId : treeNode.pId,
							name : $("#addLevelText").val()
						});
		        		showTree();
		        		toastr.success(data.message);
		        		$("#addLevelText").val('');//清空文本框
		        		$("#myModalTwo").modal('hide');//隐藏模态框
//		        		reset();
		        		$("#addLevel").show();
		    			$("#addLeaf").show();
		    			$("#modify").show();
		    			$("#remove").show();
		    			$("#mainAdd").show();
	        	}else if(data.code == "9999"){
	        		toastr.warning("存在同名分组");
	        	}else if(data.code == "9997" ){
	        		toastr.error(data.message);
	        	}
	        },
	        error: function(request) {
	        	toastr.error('系统出错,请联系管理员');
	        },xhrFields: { withCredentials: true }
		});
	}
}

function addLeaf(data){
	var zTree = $.fn.zTree.getZTreeObj("menu");
	nodes = zTree.getSelectedNodes();
	treeNode = nodes[0];
	if(nodes.length==0){
		$.ajax({
			url:"group/add.action",
			type: "POST",
			dataType:"JSON",
			data : {
	        	fzName : $("#addLeafText").val(),    //分组名称【必传】
	        	fzExtend1 : 1 ,		//分组父id
	        	fzExtend2 : 1
	        },
			success: function(data) {
				if(data.code == "0000"){
					var zTree = $.fn.zTree.getZTreeObj("menu")
					var nodes = zTree.getNodes();
					treeNode = nodes[0];
					treeNode = zTree.addNodes(null, {
						id : Number(data.id),
						pId : -1,
						name :$("#addLeafText").val()
					});
					showTree();
					toastr.success(data.message);
					$("#addLeafText").val('');//清空文本框
	        		$("#myModalThree").modal('hide');//隐藏模态框
//					reset();
				}else if(data.code == "9999"){
					toastr.warning("存在同名类型");
				}else if(data.code == "9997" ){
					toastr.error(data.message);
				}
			},
			error: function(request) {
				toastr.error('系统出错,请联系管理员');
			},xhrFields: { withCredentials: true }
		});
	}else{
		var pid;
		pid=treeNode.id;//子节点pid等于当前节点id
		$.ajax({
			url:"group/add.action",
			type: "POST",
			dataType:"JSON",
			data : {
	        	fzName : $("#addLeafText").val(),    //分组名称【必传】
	        	fzExtend1 : pid ,		//分组父id
	        	fzExtend2 : 1
	        },
			success: function(data) {
				if(data.code == "0000"){
					var zTree = $.fn.zTree.getZTreeObj("menu")
					var  nodes = zTree.getSelectedNodes();
					var  treeNode = nodes[0];
					treeNode = zTree.addNodes(treeNode, {
						id : Number(data.id),
						pId : pid,
						name : $("#addLeafText").val()
					});
					showTree();
					toastr.success(data.message);
					$("#addLeafText").val('');//清空文本框
	        		$("#myModalThree").modal('hide');//隐藏模态框
//					reset();
					$("#addLevel").show();
	    			$("#addLeaf").show();
	    			$("#modify").show();
	    			$("#remove").show();
	    			$("#mainAdd").show();	        	
				}else if(data.code == "9999"){
					toastr.warning("存在同名类型");
				}else if(data.code == "9998" ){
					toastr.error(data.message);
				}
			},
			error: function(request) {
				toastr.error('系统出错,请联系管理员');
			},xhrFields: { withCredentials: true }
		});
	}
}

/*******************************zTree*********************************/




/********************************控制图设置****************************/
function clearInput(){//清空输入
	$("#kztbh").val('');			//（控制图编号）
	$("#kztlx").val('');			//（控制图类型id）
	$("#testProject").val('');		//（检测项目id）
	$("#ggsx").val('');				//（规格上限）
	$("#mbz").val('');				//（目标值）
	$("#ggxx").val('');				//（规格下限）
	$("#ybrl").val('');				//（样本容量）
	$("#xsws").val('');				//（小数位数）
	$("#stskzx").val('');			//（上图上控制限）
	$("#stmbz").val('');			//（上图目标值）
	$("#stxkzx").val('');			//（上图下控制限）
	$("#xtskzx").val('');			//（下图上控制限）
	$("#xtmbz").val('');			//（下图目标值）
	$("#xtxkzx").val('');			//（下图下控制限）
	$("#kztms").val('');			//（控制图描述）
	$("#zdykztbt").val('');			//（自定义控制图标题）
}

function setting_back(){
	$(".main").show();
	$(".setting").hide();
}

function searchTestProject(){
	$.ajax({
		url :"DetectionItem/search.action",
		dataType:"json",
		success : function(data) {
			var option = "";
			$("#testProject").empty();
			option = '<option value="">请选择检测项目</option>';
			for (var i=0;i<data.rows.length;i++) {
				option += '<option value="' + data.rows[i].jcxmId + '">'+ data.rows[i].jcxmName + '</option>';
			}
			$("#testProject").append(option);
			$("#testProject").selectpicker('refresh');
			$("#testProject").selectpicker('render');
		},
	});
}

function setting_save(){
	if(flag==1){//flag等于1时增加，等于2时修改
		$.ajax({
			url:"controlChartMessage/add.action",
	        type: "POST",
	        dataType:"JSON",
	        data:{
	        	kztxxGroupId:groupId,				//（分组id--【必传】）
	        	kztxxNumber:$("#kztbh").val(),			//（控制图编号--【必传】）
	        	kztxxTypeId:$("#kztlx").val(),			//（控制图类型id--【必传】）
	        	kztxxDetectionItemId:$("#testProject").val(),			//（检测项目id--【必传】）
	        	kztxxSpecificationUpperLimit:$("#ggsx").val(),			//（规格上限--【必传】）
	        	kztxxTargetValue:$("#mbz").val(),						//（目标值--【必传】）
	        	kztxxSpecificationDownLimit:$("#ggxx").val(),			//（规格下限--【必传】）
	        	kztxxSampleCapacity:$("#ybrl").val(),					//（样本容量--【非必传】）
	        	kztxxDecimalNumber:$("#xsws").val(),					//（小数位数--【非必传】）
	        	kztxxAboveUpperControlLimit:$("#stskzx").val(),					//（上图上控制限--【非必传】）
	        	kztxxAboveTargetValue:$("#stmbz").val(),							//（上图目标值--【非必传】）
	        	kztxxAboveLowerControlLimit:$("#stxkzx").val(),					//（上图下控制限--【非必传】）
	        	kztxxFollowGraphUpperControlLimit:$("#xtskzx").val(),				//（下图上控制限--【非必传】）
	        	kztxxFollowGraphTargetValue:$("#xtmbz").val(),					//（下图目标值--【非必传】）
	        	kztxxFollowGraphLowerControlLimit:$("#xtxkzx").val(),				//（下图下控制限--【非必传】）
	        	kztxxControlChartDiscription:$("#kztms").val(),						//（控制图描述--【非必传】）
	        	kztxxCustomizedControlChartTitle:$("#zdykztbt").val(),					//（自定义控制图标题--【非必传】）
	        	//kztxxDetectionDeviceId:1,								//（检测设备id--【非必传】）
	        //	kztxxDetectionFrequency:123123,							//（自动检测频率（秒）--【非必传】）
	        },
	        success: function(data) {
	        	if(data.success == "0000"){
	        		toastr.success(data.message);
	        		$('#kztList').bootstrapTable('refresh');//刷新表
	        		//清空新增时的输入框
	        	}else{
	        		toastr.error(data.message);
	        	}
	        },
	        error: function(data) {
	        	toastr.error(data.message);
	        },
		});
		$(".main").show();
		$(".setting").hide();	
	}else if(flag==2){
		$.ajax({
			url:"controlChartMessage/update.action",
	        type: "POST",
	        dataType:"JSON",
	        data: {
					"kztxxId" : kztList_id,//修改控制图信息传id，state
					"state" : 0,
					kztxxGroupId:groupId,				//（分组id--【必传】）
		        	kztxxNumber:$("#kztbh").val(),			//（控制图编号--【必传】）
		        	kztxxTypeId:$("#kztlx").val(),			//（控制图类型id--【必传】）
		        	kztxxDetectionItemId:$("#testProject").val(),			//（检测项目id--【必传】）
		        	kztxxSpecificationUpperLimit:$("#ggsx").val(),			//（规格上限--【必传】）
		        	kztxxTargetValue:$("#mbz").val(),						//（目标值--【必传】）
		        	kztxxSpecificationDownLimit:$("#ggxx").val(),			//（规格下限--【必传】）
		        	kztxxSampleCapacity:$("#ybrl").val(),					//（样本容量--【非必传】）
		        	kztxxDecimalNumber:$("#xsws").val(),					//（小数位数--【非必传】）
		        	kztxxAboveUpperControlLimit:$("#stskzx").val(),					//（上图上控制限--【非必传】）
		        	kztxxAboveTargetValue:$("#stmbz").val(),							//（上图目标值--【非必传】）
		        	kztxxAboveLowerControlLimit:$("#stxkzx").val(),					//（上图下控制限--【非必传】）
		        	kztxxFollowGraphUpperControlLimit:$("#xtskzx").val(),				//（下图上控制限--【非必传】）
		        	kztxxFollowGraphTargetValue:$("#xtmbz").val(),					//（下图目标值--【非必传】）
		        	kztxxFollowGraphLowerControlLimit:$("#xtxkzx").val(),				//（下图下控制限--【非必传】）
		        	kztxxControlChartDiscription:$("#kztms").val(),						//（控制图描述--【非必传】）
		        	kztxxCustomizedControlChartTitle:$("#zdykztbt").val(),					//（自定义控制图标题--【非必传】）
				},
	        success: function(data) {
	        	if(data.success == "0000"){
	        		toastr.success(data.message);
	        		$('#kztList').bootstrapTable('refresh');
	        		showLztList();
//清空文本框
	        	}else{
	        		toastr.error(data.message);
	        	}
	        },
	        error: function(data) {
	        	toastr.error(data.message);
	        },
		});
		$(".main").show();
		$(".setting").hide();	
	}
}

function searchSet(){
	$.ajax({
		url:"controlChartMessage/searchSet.action",
        type: "GET",
        dataType:"JSON",
        data: {
				"id" : kztList_id,
			},
        success: function(data) {
        	if(data.success == "0000"){
//        		console.log(data);
        		kztxxGroupId=data.rows.kztxxGroupId;			//（分组id）
            	$("#kztbh").val(data.rows.kztxxNumber);		//（控制图编号）
            	$("#kztlx").val(data.rows.kztxxTypeId);			//（控制图类型id）
            	$("#testProject").selectpicker('val',data.rows.kztxxDetectionItemId);//（检测项目id）		
            	$("#ggsx").val(data.rows.kztxxSpecificationUpperLimit);			//（规格上限）
            	$("#mbz").val(data.rows.kztxxTargetValue);						//（目标值）
            	$("#ggxx").val(data.rows.kztxxSpecificationDownLimit);			//（规格下限）
            	$("#ybrl").val(data.rows.kztxxSampleCapacity);					//（样本容量）
            	$("#xsws").val(data.rows.kztxxDecimalNumber);					//（小数位数）
            	$("#stskzx").val(data.rows.kztxxAboveUpperControlLimit);				//（上图上控制限--【非必传】）
            	$("#stmbz").val(data.rows.kztxxAboveTargetValue);							//（上图目标值--【非必传】）
            	$("#stxkzx").val(data.rows.kztxxAboveLowerControlLimit);					//（上图下控制限--【非必传】）
            	$("#xtskzx").val(data.rows.kztxxFollowGraphUpperControlLimit);				//（下图上控制限--【非必传】）
            	$("#xtmbz").val(data.rows.kztxxFollowGraphTargetValue);					//（下图目标值--【非必传】）
            	$("#xtxkzx").val(data.rows.kztxxFollowGraphLowerControlLimit);				//（下图下控制限--【非必传】）
            	$("#kztms").val(data.rows.kztxxControlChartDiscription);						//（控制图描述--【非必传】）
            	$("#zdykztbt").val(data.rows.kztxxCustomizedControlChartTitle);					//（自定义控制图标题--【非必传】）
    //kztxxDetectionDeviceId:1,								//（检测设备id--【非必传】）
//    	kztxxDetectionFrequency:123123,							//（自动检测频率（秒）--【非必传】）
        	}else{
        		toastr.error(data.message);
        	}
        },
        error: function(data) {
        	toastr.error(data.message);
        },
	});
}

function searchKZTSJD(){//查询控制图层次信息以及数据点层次信息
	$.ajax({
		url:"controlChartHierarchicalInformationRelationship/search.action",
        type: "GET",
        dataType:"JSON",
        data: {
				"id" : kztBh,
			},
        success: function(data) {
        	if(data.success == "0000"){
        		console.log(data);		
        	}else{
        		toastr.error(data.message);
        	}
        },
        error: function(data) {
        	toastr.error(data.message);
        },
	});
}

window.operateEvents = {
		'click .update' : function(e, value, row, index) {
			flag=2;//修改模式
			kztList_id=row.id;//给控制图列表id赋值
			searchTestProject();//调用查询检测项目方法
			searchSet();//查询设置信息
			searchKZTSJD();//查询控制图层次信息以及数据点层次信息
			$(".setting").show();
			$(".main").hide();
		},
		'click .delete' : function(e, value, row, index) {
			Showbo.Msg.confirm('确认删除？',function(btn){
				if(btn == "yes"){
					$.ajax({
						url:"controlChartMessage/update.action",
				        type: "POST",
				        dataType:"JSON",
				        data:{
				        	"kztxxId":row.id,
				        	"state":1
				        },
				        success: function(data) {
				        	if(data.success == "0000"){
				        		toastr.success(data.message);
				        		$('#kztList').bootstrapTable('refresh');
				        	}else{
				        		toastr.error(data.message);
				        	}
				        },
				        error: function(data) {
				        	toastr.error(data.message);
				        },
					});
				}
			});
		},
		'click .input' : function(e, value, row, index) {
			$(".content").show();
			$(".main").hide();
//			showEcharts();
		},
		'click .check' : function(e, value, row, index) {
			$(".content").show();
			$(".main").hide();
			searchHandsonTableBt(row);
//			showEcharts();

		},
		'click .dispose' : function(e, value, row, index) {
			$("#disposeModal").modal('show');
			showDisposeList();
		}
		
};

var shuzu=[ 
           {field : 'state',title : '',align:"center",valign:'middle',formatter : operate2},	
           {field : 'bh',title : '编号',align:"center"},
           {field : 'jcxm',title : '检测项目',align:"center"}, 
           {field : 'tl',title : '图类',align:"center"}, 
           {field : 'ybrl',title : '样本容量',align:"center"}, 
           
           {field : 'ggsx',title : '规格上限',align:"center"}, 
           {field : 'mbz',title : '目标值',align:"center"}, 
           {field : 'ggxx',title : '规格下限',align:"center"}, 
           {field : 'ypgz',title : '判异规则',align:"center"}, 
           {field : 'gxyh',title : '更新用户',align:"center"}, 
           {field : 'gxsj',title : '更新时间',align:"center"}, 
    		{field : 'op',title : '操作',align:"center",formatter : operate,events : operateEvents}		
    		];

/**
 * 操作按钮
 */		
function operate(value, row, index) {
	var str = "";
	str += "<div style='width:240px;height:30px;' >"
    str += '<a class="btn btn-warning btn-xs update">修改</a>&nbsp';
    str += '<a class="btn btn-danger btn-xs delete">删除</a>&nbsp';
    str += '<a class="btn btn-info btn-xs input">录入</a>&nbsp';
    str += '<a class="btn btn-info btn-xs check">查看</a>&nbsp';
    str += '<a class="btn btn-info btn-xs dispose">失控处理</a>&nbsp';
    str += "</div>"
	return str;
}
/**
 * 操作点击事件
 */

function operate2(value, row, index) {
	var str = "";
    str += '<div style="width:15px;height:15px;background:red;border-radius:15px;" ></div>';
	return str;
}

function showKztList() {
	$('#kztList').bootstrapTable('destroy').bootstrapTable({
		url : "controlChartMessage/search.action",
		queryParams : function(params){
			var temp = { //这里的键的名字和控制器的变量名必须一直，这边改动，控制器也需要改成一样的  
					limit : params.limit,// 每页记录数
					offset : params.offset,// 从第几条记录开始
				};
			return temp;
	},//传递参数（*） 
		sidePagination : "server", //分页方式：client客户端分页，server服务端分页（*）
		striped : false, // 是否显示行间隔色
		pagination : true, // 是否显示分页（*）
		sortable : false, // 是否启用排序
		sortOrder : "asc", // 排序方式
        toolbar:"#toolbar",
		pageNumber : 1, // 初始化加载第一页，默认第一页
		pageSize : 10, // 每页的记录行数（*）
		pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
		strictSearch : true,
		clickToSelect : true, // 是否启用点击选中行
		height : 512, // 行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		columns : shuzu,
		
		onLoadSuccess : function(data) {		
			console.log(data);
		}
	});
};

function main_add(){
	clearInput();
	searchTestProject();//调用查询检测项目方法
	flag=1;//增加模式
	$(".setting").show();
	$(".main").hide();
}

function content_back(){
	$(".content").hide();
	$(".main").show();
	des();
}
























