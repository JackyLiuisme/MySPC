package com.nbst.service.Impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nbst.dao.mapper.ispcweb.DetectionDeviceMapper;
import com.nbst.model.DetectionDevice;
import com.nbst.service.IDetectionDeviceService;

import groovy.util.logging.Slf4j;

/**
 * @author yangl
 *
 */
@Slf4j
@Service
@Transactional
public class DetectionDeviceServiceImpl implements IDetectionDeviceService {
	@Autowired
	DetectionDeviceMapper mapper;

	/**
	 * 新增检测设备
	 * 
	 * @param detectionDevice
	 * @return
	 */
	@Override
	public Object addDetectionDevice(DetectionDevice detectionDevice) {
		Map<String, Object> resultMap = new HashMap<>();
		int flag = mapper.insert(detectionDevice);
		if (flag != 0) {
			resultMap.put("message", "新增成功");
			resultMap.put("code", "0000");
		} else {
			resultMap.put("message", "新增失败");
			resultMap.put("code", "9997");
			return resultMap;
		}

		return resultMap;
	}

	/**
	 * 删除/修改检测设备，state=0：删除,state=1:修改
	 * 
	 * @param detectionDevice
	 * @param state
	 * @return
	 */
	@Override
	public Object alterDetectionDevice(DetectionDevice detectionDevice, Integer state) {
		Map<String, Object> resultMap = new HashMap<>();
		// 删除
		if (state == 0) {
			DetectionDevice item = mapper.findById(detectionDevice.getJcsbId());
			item.setJcsbState(2);
			int flag = mapper.update(item);
			if (flag > 0) {
				resultMap.put("message", "删除成功");
				resultMap.put("code", "0000");
			} else {
				resultMap.put("message", "删除失败");
				resultMap.put("code", "9996");
			}
			return resultMap;
		}
		// 修改
		int flag = mapper.update(detectionDevice);
		if (flag > 0) {
			resultMap.put("message", "修改成功");
			resultMap.put("code", "0000");
		} else {
			resultMap.put("message", "修改失败");
			resultMap.put("code", "9994");
		}
		return resultMap;
	}

	/**
	 * 查询检测设备
	 * 
	 * @param limit
	 * @param offset
	 * @return
	 */
	@Override
	public Object searchDetectionDevice(Integer limit, Integer offset) {
		Map<String, Object> resultMap = new HashMap<>();
		Map<String, Object> conditionMap = new HashMap<>();
		conditionMap.put("jcsbState", "1");

		int count = mapper.count(conditionMap);
		conditionMap.put("limit", limit);
		conditionMap.put("offset", offset);

		resultMap.put("total", count);
		resultMap.put("code", "0000");
		resultMap.put("message", "查找成功");
		resultMap.put("rows", mapper.findByCondition(conditionMap));
		return resultMap;
	}

}
