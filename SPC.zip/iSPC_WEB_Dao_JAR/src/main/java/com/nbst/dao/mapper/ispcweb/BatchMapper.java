package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.Batch;

public interface BatchMapper {
	int delete(Integer pcId);

	int insert(Batch record);

	Batch findById(Integer pcId);

	int update(Batch record);

	List<Batch> findByCondition(Map map);

	int count(Map<String, Object> map);
}