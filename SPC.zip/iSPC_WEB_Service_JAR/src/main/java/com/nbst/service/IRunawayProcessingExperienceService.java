package com.nbst.service;

import java.util.Map;

import com.nbst.model.RunawayProcessingExperience;

/**
 * @author huangjx
 *
 */
public interface IRunawayProcessingExperienceService {
	/**
	 * 新增历史处理经验
	 * @param experience
	 * @return {
	 * 		"code":""
	 * 		"message":""
	 * 		"id":Integer
	 * }
	 */
	Map<String,Object> add(RunawayProcessingExperience rpe);

	/**
	 * 更新id对应的历史经验
	 * @param rpe 用rpe来更新rpe的id对应的记录或者删除rpe的id对应的记录
	 * @param state state为1代表修改记录，state为0代表删除记录
	 * @return
	 */
	Map<String,Object> update(RunawayProcessingExperience rpe,Integer state);
	
	/**
	 * @param limit
	 * @param offset
	 * @return
	 */
	Map<String,Object> search(Integer limit,Integer offset);
}
