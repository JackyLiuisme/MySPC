package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.ControlChartInfomationHierarchicalInformationRelationship;

public interface ControlChartInfomationHierarchicalInformationRelationshipMapper {
    int delete(Integer kztxxccglId);

    int insert(ControlChartInfomationHierarchicalInformationRelationship record);

    ControlChartInfomationHierarchicalInformationRelationship findById(Integer kztxxccglId);

    int update(ControlChartInfomationHierarchicalInformationRelationship record);

    List<ControlChartInfomationHierarchicalInformationRelationship> findByCondition(Map<String,Object> map);
    
    int count(Map<String,Object> map);
}