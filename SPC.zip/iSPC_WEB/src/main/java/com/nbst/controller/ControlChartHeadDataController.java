package com.nbst.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nbst.comnutil.AppUtil;
import com.nbst.model.ControlChartInfomationHierarchicalInformationRelationship;
import com.nbst.service.IControlChartHeadDataService;

import groovy.util.logging.Slf4j;

@Controller
@RequestMapping("/controlChartTitleQuery")
@Slf4j
@CrossOrigin
public class ControlChartHeadDataController {

	private IControlChartHeadDataService ControlChartTitleQueryService;

	/**
	 * 表头数据修改
	 * 
	 * @param kztxxId
	 * @param kztxxGroupId
	 * @param kztxxNumber
	 * @param 
	 * @author lijiajun
	 * @return
	 */
	@RequestMapping(value = "/updata.action", method = RequestMethod.POST)
	@ResponseBody
	public Object updateControlChartHeadData(ControlChartInfomationHierarchicalInformationRelationship controlChartInfomationHierarchicalInformationRelationship) {
		return AppUtil.conversionJsonp(ControlChartTitleQueryService.updateControlChartHeadData(controlChartInfomationHierarchicalInformationRelationship));
	}
}
