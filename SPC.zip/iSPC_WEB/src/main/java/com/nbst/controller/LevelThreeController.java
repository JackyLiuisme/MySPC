package com.nbst.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nbst.comnutil.AppUtil;
import com.nbst.service.IQueryService;

import groovy.util.logging.Slf4j;

@Controller
@RequestMapping("/productLine")
@Slf4j
@CrossOrigin
public class LevelThreeController {
	@Autowired
	private IQueryService queryService;

	/**
	 * 层次3增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	@RequestMapping(value = "/add.action", method = RequestMethod.POST)
	@ResponseBody
	public Object addLevelThreeItems(String name) {
		return AppUtil.conversionJsonp(queryService.addLevelThreeItems(name));
	}

	/**
	 * 层次3删除和修改
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	@RequestMapping(value = "/update.action", method = RequestMethod.POST)
	@ResponseBody
	public Object updateLevelThreeItems(Integer id, String name, Integer state) {
		return AppUtil.conversionJsonp(queryService.updateLevelThreeItems(id, name, state));
	}

	/**
	 * 层次3查詢
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	@RequestMapping(value = "/search.action", method = RequestMethod.GET)
	@ResponseBody
	public Object searchLevelThreeItems(Integer limit, Integer offset) {
		return AppUtil.conversionJsonp(queryService.searchLevelThreeItems(limit, offset));
	}
}
