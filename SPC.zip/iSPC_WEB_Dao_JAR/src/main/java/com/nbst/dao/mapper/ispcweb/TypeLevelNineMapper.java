package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.TypeLevelNine;

public interface TypeLevelNineMapper {
	int delete(Integer cclxnineId);

	int insert(TypeLevelNine record);

	TypeLevelNine findById(Integer cclxnineId);

	int update(TypeLevelNine record);

	List<TypeLevelNine> findByCondition(Map<String, Object> map);

	int count(Map<String, Object> map);
}