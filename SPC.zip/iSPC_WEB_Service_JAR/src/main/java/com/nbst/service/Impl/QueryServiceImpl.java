package com.nbst.service.Impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nbst.dao.mapper.ispcweb.TypeLevelEightMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelFiveMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelFourMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelNameMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelNineMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelOneMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelSevenMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelSixMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelThreeMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelTwoMapper;
import com.nbst.model.TypeLevelEight;
import com.nbst.model.TypeLevelFive;
import com.nbst.model.TypeLevelFour;
import com.nbst.model.TypeLevelName;
import com.nbst.model.TypeLevelNine;
import com.nbst.model.TypeLevelOne;
import com.nbst.model.TypeLevelSeven;
import com.nbst.model.TypeLevelSix;
import com.nbst.model.TypeLevelThree;
import com.nbst.model.TypeLevelTwo;
import com.nbst.service.IQueryService;

import groovy.util.logging.Slf4j;

@Slf4j
@Service
@Transactional
public class QueryServiceImpl implements IQueryService {

	@Autowired
	private TypeLevelFourMapper typeLevelFourMapper;
	@Autowired
	private TypeLevelFiveMapper typeLevelFiveMapper;
	@Autowired
	private TypeLevelOneMapper typeLevelOneMapper;
	@Autowired
	private TypeLevelTwoMapper typeLevelTwoMapper;
	@Autowired
	private TypeLevelThreeMapper typeLevelThreeMapper;
	@Autowired
	private TypeLevelSixMapper typeLevelSixMapper;
	@Autowired
	private TypeLevelSevenMapper typeLevelSevenMapper;
	@Autowired
	private TypeLevelEightMapper typeLevelEightMapper;
	@Autowired
	private TypeLevelNineMapper typeLevelNineMapper;
	@Autowired
	private TypeLevelNameMapper typeLevelNameMapper;

	/**
	 * 层次4增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> addLevelFourItems(String name) {
		TypeLevelFour typeLevelFour = new TypeLevelFour();
		Map<String, Object> map = new HashMap<>();
		Map<String, Object> conditionmap = new HashMap<>();
		conditionmap.put("cclxfourExtend1", 1);
		conditionmap.put("cclxfourName", name);
		List<TypeLevelFour> list = typeLevelFourMapper.findByCondition(conditionmap);
		if (!list.isEmpty()) {

			map.put("message", "名字重复新增失败");
			map.put("code", "9999");

		} else {

			typeLevelFour.setCclxfourName(name);
			typeLevelFour.setCclxfourExtend1("1");
			typeLevelFourMapper.insert(typeLevelFour);
			map.put("message", "新增成功");
			map.put("code", "0000");
		}

		return map;
	}

	/**
	 * 层次4查找
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> searchLevelFourItems(Integer limit, Integer offset) {
		Map<String, Object> conditionmap = new HashMap<>();
		Map<String, Object> returnmap = new HashMap<>();
		conditionmap.put("cclxfourExtend1", 1);
		List<TypeLevelFour> list1 = typeLevelFourMapper.findByCondition(conditionmap);
		List<Object> list2 = new ArrayList<>();
		for (TypeLevelFour typeLevelFour : list1) {
			Map<String, Object> map = new HashMap<>();
			map.put("name", typeLevelFour.getCclxfourName());
			map.put("id", typeLevelFour.getCclxfourId());
			map.put("state", typeLevelFour.getCclxfourExtend1());
			list2.add(map);
		}
		conditionmap.put("offset", offset);
		conditionmap.put("limit", limit);
		int count = typeLevelFourMapper.findByCondition(conditionmap).size();
		returnmap.put("rows", list2);
		returnmap.put("code", "0000");
		returnmap.put("total", count);
		returnmap.put("message", "查询成功");

		return returnmap;
	}

	/**
	 * 删除和修改层次4
	 * 
	 * @param id
	 * @param state
	 * @param state
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> updateLevelFourItems(Integer id, String name, Integer state) {
		Map<String, Object> map = new HashMap<>();
		if (state == 0) {
			TypeLevelFour typeLevelFour = new TypeLevelFour();
			typeLevelFour = typeLevelFourMapper.findById(id);
			typeLevelFour.setCclxfourExtend1("0");
			int users = typeLevelFourMapper.update(typeLevelFour);
			if (users == 1) {

				map.put("message", "删除成功");
				map.put("code", "0000");
			} else {
				map.put("message", "删除失败");
				map.put("code", "9999");
			}

		} else if (state == 1) {
			TypeLevelFour typeLevelFour = new TypeLevelFour();
			typeLevelFour = typeLevelFourMapper.findById(id);
			Map<String, Object> conditionmap = new HashMap<>();
			conditionmap.put("cclxfourExtend1", 1);
			conditionmap.put("cclxfourName", name);
			List<TypeLevelFour> list = typeLevelFourMapper.findByCondition(conditionmap);
			conditionmap.put("cclxfourId", id);
			List<TypeLevelFour> list1 = typeLevelFourMapper.findByCondition(conditionmap);
			if (!list.isEmpty() && list1.isEmpty()) {

				map.put("message", "名字重复修改失败");
				map.put("code", "9999");

			} else {
				typeLevelFour.setCclxfourName(name);
				int users = typeLevelFourMapper.update(typeLevelFour);
				if (users == 1) {

					map.put("message", "修改成功");
					map.put("code", "0000");
				} else {
					map.put("message", "修改失败");
					map.put("code", "9999");
				}

			}
		}

		return map;
	}

	/**
	 * 层次5增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> addLevelFiveItems(String name) {
		TypeLevelFive typeLevelFive = new TypeLevelFive();
		Map<String, Object> map = new HashMap<>();
		Map<String, Object> conditionmap = new HashMap<>();
		conditionmap.put("cclxfiveExtend1", 1);
		conditionmap.put("cclxfiveName", name);
		List<TypeLevelFive> list = typeLevelFiveMapper.findByCondition(conditionmap);
		if (!list.isEmpty()) {
			map.put("message", "名字重复新增失败");
			map.put("code", "9999");

		} else {

			typeLevelFive.setCclxfiveName(name);
			typeLevelFive.setCclxfiveExtend1("1");
			typeLevelFiveMapper.insert(typeLevelFive);
			map.put("message", "新增成功");
			map.put("code", "0000");
		}

		return map;
	}

	/**
	 * 层次5查找
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> searchLevelFiveItems(Integer limit, Integer offset) {
		Map<String, Object> conditionmap = new HashMap<>();
		Map<String, Object> returnmap = new HashMap<>();
		conditionmap.put("cclxfiveExtend1", 1);
		List<TypeLevelFive> list1 = typeLevelFiveMapper.findByCondition(conditionmap);
		List<Object> list2 = new ArrayList<>();
		for (TypeLevelFive typeLevelFive : list1) {
			Map<String, Object> map = new HashMap<>();
			map.put("name", typeLevelFive.getCclxfiveName());
			map.put("id", typeLevelFive.getCclxfiveId());
			map.put("state", typeLevelFive.getCclxfiveExtend1());
			list2.add(map);
		}
		int count = typeLevelFiveMapper.findByCondition(conditionmap).size();
		conditionmap.put("limit", limit);
		conditionmap.put("offset", offset);
		conditionmap.put("state", 1);
		returnmap.put("rows", list2);
		returnmap.put("code", "0000");
		returnmap.put("total", count);
		returnmap.put("message", "查询成功");

		return returnmap;
	}

	/**
	 * 删除和修改层次5
	 * 
	 * @param id
	 * @param state
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> updateLevelFiveItems(Integer id, String name, Integer state) {
		Map<String, Object> map = new HashMap<>();

		if (state == 0) {
			TypeLevelFive typeLevelFive = new TypeLevelFive();
			typeLevelFive = typeLevelFiveMapper.findById(id);
			typeLevelFive.setCclxfiveExtend1("0");
			int users = typeLevelFiveMapper.update(typeLevelFive);
			if (users == 1) {
				map.put("message", "删除成功");
				map.put("code", "0000");
			} else {
				map.put("message", "删除失败");
				map.put("code", "9999");
			}

		} else if (state == 1) {
			TypeLevelFive typeLevelFive = new TypeLevelFive();
			typeLevelFive = typeLevelFiveMapper.findById(id);
			Map<String, Object> conditionmap = new HashMap<>();
			conditionmap.put("cclxfiveExtend1", 1);
			conditionmap.put("cclxfiveName", name);
			List<TypeLevelFive> list = typeLevelFiveMapper.findByCondition(conditionmap);
			conditionmap.put("cclxfiveId", id);
			List<TypeLevelFive> list1 = typeLevelFiveMapper.findByCondition(conditionmap);
			if (!list.isEmpty() && list1.isEmpty()) {

				map.put("message", "名字重复修改失败");
				map.put("code", "9999");

			} else {
				typeLevelFive.setCclxfiveName(name);
				int users = typeLevelFiveMapper.update(typeLevelFive);
				if (users == 1) {
					map.put("message", "修改成功");
					map.put("code", "0000");
				} else {
					map.put("message", "修改失败");
					map.put("code", "9999");
				}

			}
		}

		return map;
	}

	/**
	 * 层次2增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */

	@Override
	public Map<String, Object> addLevelTwoItems(String name) {
		Map<String, Object> map = new HashMap<>();
		Map<String, Object> conditionmap = new HashMap<>();
		conditionmap.put("cclxtwoExtend1", 1);
		conditionmap.put("cclxtwoName", name);
		List<TypeLevelTwo> list = typeLevelTwoMapper.findByCondition(conditionmap);
		if (!list.isEmpty()) {
			map.put("message", "名字重复新增失败");
			map.put("code", "9999");
		} else {
			TypeLevelTwo typeLevelTwo = new TypeLevelTwo();
			typeLevelTwo.setCclxtwoName(name);
			typeLevelTwo.setCclxtwoExtend1("1");
			typeLevelTwoMapper.insert(typeLevelTwo);
			map.put("message", "新增成功");
			map.put("code", "0000");
		}

		return map;
	}

	/**
	 * 层次2删除和修改
	 * 
	 * @param id
	 * @param offset
	 * @author lijiajun
	 * @return
	 */

	@Override
	public Map<String, Object> updateLevelTwoItems(Integer id, String name, Integer state) {
		Map<String, Object> map = new HashMap<>();

		if (state == 0) {
			TypeLevelTwo typeLevelTwo = new TypeLevelTwo();
			typeLevelTwo = typeLevelTwoMapper.findById(id);
			typeLevelTwo.setCclxtwoExtend1("0");
			int users = typeLevelTwoMapper.update(typeLevelTwo);
			if (users == 1) {
				map.put("message", "删除成功");
				map.put("code", "0000");
			} else {
				map.put("message", "删除失败");
				map.put("code", "9999");
			}

		} else if (state == 1) {
			TypeLevelTwo typeLevelTwo = new TypeLevelTwo();
			typeLevelTwo = typeLevelTwoMapper.findById(id);
			Map<String, Object> conditionmap = new HashMap<>();
			conditionmap.put("cclxtwoExtend1", 1);
			conditionmap.put("cclxtwoName", name);
			List<TypeLevelTwo> list = typeLevelTwoMapper.findByCondition(conditionmap);
			conditionmap.put("cclxtwoId", id);
			List<TypeLevelTwo> list1 = typeLevelTwoMapper.findByCondition(conditionmap);
			if (!list.isEmpty() && list1.isEmpty()) {

				map.put("message", "名字重复修改失败");
				map.put("code", "9999");

			} else {
				typeLevelTwo.setCclxtwoName(name);
				int users = typeLevelTwoMapper.update(typeLevelTwo);
				if (users == 1) {
					map.put("message", "修改成功");
					map.put("code", "0000");
				} else {
					map.put("message", "修改失败");
					map.put("code", "9999");
				}

			}
		}

		return map;
	}

	/**
	 * 层次2查找
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */

	@Override
	public Map<String, Object> searchLevelTwoItems(Integer limit, Integer offset) {
		Map<String, Object> conditionmap = new HashMap<>();
		Map<String, Object> returnmap = new HashMap<>();
		conditionmap.put("cclxtwoExtend1", 1);
		List<TypeLevelTwo> list1 = typeLevelTwoMapper.findByCondition(conditionmap);
		List<Object> list2 = new ArrayList<>();
		for (TypeLevelTwo typeLevelTwo : list1) {
			Map<String, Object> map = new HashMap<>();
			map.put("name", typeLevelTwo.getCclxtwoName());
			map.put("id", typeLevelTwo.getCclxtwoId());
			map.put("state", typeLevelTwo.getCclxtwoExtend1());
			list2.add(map);
		}
		int count = typeLevelTwoMapper.findByCondition(conditionmap).size();
		conditionmap.put("limit", limit);
		conditionmap.put("offset", offset);
		conditionmap.put("state", 1);

		returnmap.put("message", "查询成功");
		returnmap.put("total", count);
		returnmap.put("code", "0000");
		returnmap.put("rows", list2);

		return returnmap;
	}

	/**
	 * 层次1增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> addLevelOneItems(String name) {
		TypeLevelOne typeLevelOne = new TypeLevelOne();
		Map<String, Object> map = new HashMap<>();
		Map<String, Object> conditionmap = new HashMap<>();
		conditionmap.put("cclxoneExtend1", 1);
		conditionmap.put("cclxoneName", name);
		List<TypeLevelOne> list = typeLevelOneMapper.findByCondition(conditionmap);
		if (!list.isEmpty()) {
			map.put("message", "名字重复新增失败");
			map.put("code", "9999");

		} else {
			typeLevelOne.setCclxoneName(name);
			typeLevelOne.setCclxoneExtend1("1");
			typeLevelOneMapper.insert(typeLevelOne);
			map.put("message", "新增成功");
			map.put("code", "0000");
		}
		return map;
	}

	/**
	 * 层次1删除和修改
	 * 
	 * @param id
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> updateLevelOneItems(Integer id, String name, Integer state) {
		Map<String, Object> map = new HashMap<>();

		if (state == 0) {
			TypeLevelOne typeLevelOne = new TypeLevelOne();
			typeLevelOne = typeLevelOneMapper.findById(id);
			typeLevelOne.setCclxoneExtend1("0");
			int users = typeLevelOneMapper.update(typeLevelOne);
			if (users == 1) {
				map.put("message", "删除成功");
				map.put("code", "0000");
			} else {
				map.put("message", "删除失败");
				map.put("code", "9999");
			}
		} else if (state == 1) {
			TypeLevelOne typeLevelOne = new TypeLevelOne();
			typeLevelOne = typeLevelOneMapper.findById(id);
			Map<String, Object> conditionmap = new HashMap<>();
			conditionmap.put("cclxoneExtend1", 1);
			conditionmap.put("cclxoneName", name);
			List<TypeLevelOne> list = typeLevelOneMapper.findByCondition(conditionmap);
			conditionmap.put("cclxoneId", id);
			List<TypeLevelOne> list1 = typeLevelOneMapper.findByCondition(conditionmap);
			if (!list.isEmpty() && list1.isEmpty()) {

				map.put("message", "名字重复修改失败");
				map.put("code", "9999");

			} else {
				typeLevelOne.setCclxoneName(name);
				int users = typeLevelOneMapper.update(typeLevelOne);
				if (users == 1) {
					map.put("message", "修改成功");
					map.put("code", "0000");
				} else {
					map.put("message", "修改失败");
					map.put("code", "9999");
				}
			}

		}
		return map;
	}

	/**
	 * 层次1查找
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */

	@Override
	public Map<String, Object> searchLevelOneItems(Integer limit, Integer offset) {
		Map<String, Object> conditionmap = new HashMap<>();
		Map<String, Object> returnmap = new HashMap<>();
		conditionmap.put("cclxoneExtend1", 1);
		List<Object> list2 = new ArrayList<>();
		int count = typeLevelOneMapper.findByCondition(conditionmap).size();
		List<TypeLevelOne> list1 = typeLevelOneMapper.findByCondition(conditionmap);
		for (TypeLevelOne typeLevelOne : list1) {
			Map<String, Object> map = new HashMap<>();
			map.put("name", typeLevelOne.getCclxoneName());
			map.put("id", typeLevelOne.getCclxoneId());
			map.put("state", typeLevelOne.getCclxoneExtend1());
			list2.add(map);
		}
		conditionmap.put("limit", limit);
		conditionmap.put("offset", offset);
		conditionmap.put("state", 1);
		returnmap.put("rows", list2);
		returnmap.put("code", "0000");
		returnmap.put("total", count);
		returnmap.put("message", "查询成功");

		return returnmap;
	}

	/**
	 * 层次3增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> addLevelThreeItems(String name) {
		TypeLevelThree typeLevelThree = new TypeLevelThree();
		List<TypeLevelThree> list = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		Map<String, Object> conditionmap = new HashMap<>();
		conditionmap.put("cclxthreeExtend1", 1);
		conditionmap.put("cclxthreeName", name);
		list = typeLevelThreeMapper.findByCondition(conditionmap);
		if (!list.isEmpty()) {

			map.put("message", "名字重复新增失败");
			map.put("code", "9999");

		} else {

			typeLevelThree.setCclxthreeName(name);
			typeLevelThree.setCclxthreeExtend1("1");
			typeLevelThreeMapper.insert(typeLevelThree);
			map.put("message", "新增成功");
			map.put("code", "0000");
		}

		return map;
	}

	/**
	 * 层次3删除和修改
	 * 
	 * @param id
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> updateLevelThreeItems(Integer id, String name, Integer state) {
		Map<String, Object> map = new HashMap<>();

		if (state == 0) {
			TypeLevelThree typeLevelThree = new TypeLevelThree();
			typeLevelThree = typeLevelThreeMapper.findById(id);
			typeLevelThree.setCclxthreeExtend1("0");
			int users = typeLevelThreeMapper.update(typeLevelThree);
			if (users == 1) {

				map.put("message", "删除成功");
				map.put("code", "0000");
			} else {
				map.put("message", "删除失败");
				map.put("code", "9999");
			}

		} else if (state == 1) {
			TypeLevelThree typeLevelThree = new TypeLevelThree();
			typeLevelThree = typeLevelThreeMapper.findById(id);
			Map<String, Object> conditionmap = new HashMap<>();
			conditionmap.put("cclxthreeExtend1", 1);
			conditionmap.put("cclxthreeName", name);
			List<TypeLevelThree> list = typeLevelThreeMapper.findByCondition(conditionmap);
			conditionmap.put("cclxthreeId", id);
			List<TypeLevelThree> list1 = typeLevelThreeMapper.findByCondition(conditionmap);
			if (!list.isEmpty() && list1.isEmpty()) {

				map.put("message", "名字重复修改失败");
				map.put("code", "9999");

			} else {
				typeLevelThree.setCclxthreeName(name);
				int users = typeLevelThreeMapper.update(typeLevelThree);
				if (users == 1) {

					map.put("message", "修改成功");
					map.put("code", "0000");
				} else {
					map.put("message", "修改失败");
					map.put("code", "9999");
				}
			}

		}
		return map;
	}

	/**
	 * 层次3查找
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */

	@Override
	public Map<String, Object> searchLevelThreeItems(Integer limit, Integer offset) {
		Map<String, Object> conditionmap = new HashMap<>();
		Map<String, Object> returnmap = new HashMap<>();
		conditionmap.put("cclxthreeExtend1", 1);
		List<TypeLevelThree> list1 = typeLevelThreeMapper.findByCondition(conditionmap);
		List<Object> list2 = new ArrayList<>();
		for (TypeLevelThree typeLevelThree : list1) {
			Map<String, Object> map = new HashMap<>();
			map.put("name", typeLevelThree.getCclxthreeName());
			map.put("id", typeLevelThree.getCclxthreeId());
			map.put("state", typeLevelThree.getCclxthreeExtend1());
			list2.add(map);
		}
		int count = typeLevelThreeMapper.findByCondition(conditionmap).size();
		conditionmap.put("limit", limit);
		conditionmap.put("offset", offset);
		conditionmap.put("state", 1);
		returnmap.put("rows", list2);
		returnmap.put("code", "0000");
		returnmap.put("total", count);
		returnmap.put("message", "查询成功");

		return returnmap;
	}

	/**
	 * 层次6增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> addLevelSixItems(String name) {
		TypeLevelSix typeLevelSix = new TypeLevelSix();
		Map<String, Object> map = new HashMap<>();
		Map<String, Object> conditionmap = new HashMap<>();
		conditionmap.put("cclxsixExtend1", 1);
		conditionmap.put("cclxsixName", name);
		List<TypeLevelSix> list = typeLevelSixMapper.findByCondition(conditionmap);
		if (!list.isEmpty()) {

			map.put("message", "名字重复新增失败");
			map.put("code", "9999");

		} else {

			typeLevelSix.setCclxsixName(name);
			typeLevelSix.setCclxsixExtend1("1");
			typeLevelSixMapper.insert(typeLevelSix);
			map.put("message", "新增成功");
			map.put("code", "0000");
		}

		return map;
	}

	/**
	 * 层次6删除和修改
	 * 
	 * @param id
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> updateLevelSixItems(Integer id, String name, Integer state) {
		Map<String, Object> map = new HashMap<>();

		if (state == 0) {
			TypeLevelSix typeLevelSix = new TypeLevelSix();
			typeLevelSix = typeLevelSixMapper.findById(id);
			typeLevelSix.setCclxsixExtend1("0");
			int users = typeLevelSixMapper.update(typeLevelSix);
			if (users == 1) {

				map.put("message", "删除成功");
				map.put("code", "0000");
			} else {
				map.put("message", "删除失败");
				map.put("code", "9999");
			}

		} else if (state == 1) {
			TypeLevelSix typeLevelSix = new TypeLevelSix();
			typeLevelSix = typeLevelSixMapper.findById(id);
			Map<String, Object> conditionmap = new HashMap<>();
			conditionmap.put("cclxsixExtend1", 1);
			conditionmap.put("cclxsixName", name);
			List<TypeLevelSix> list = typeLevelSixMapper.findByCondition(conditionmap);
			conditionmap.put("cclxsixId", id);
			List<TypeLevelSix> list1 = typeLevelSixMapper.findByCondition(conditionmap);
			if (!list.isEmpty() && list1.isEmpty()) {

				map.put("message", "名字重复修改失败");
				map.put("code", "9999");

			} else {
				typeLevelSix.setCclxsixName(name);
				int users = typeLevelSixMapper.update(typeLevelSix);
				if (users == 1) {

					map.put("message", "修改成功");
					map.put("code", "0000");
				} else {
					map.put("message", "修改失败");
					map.put("code", "9999");
				}
			}

		}
		return map;

	}

	/**
	 * 层次6查找
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */

	@Override
	public Map<String, Object> searchLevelSixItems(Integer limit, Integer offset) {
		Map<String, Object> conditionmap = new HashMap<>();
		Map<String, Object> returnmap = new HashMap<>();
		conditionmap.put("cclxsixExtend1", 1);
		List<TypeLevelSix> list1 = typeLevelSixMapper.findByCondition(conditionmap);

		List<Object> list2 = new ArrayList<>();
		for (TypeLevelSix typeLevelSix : list1) {
			Map<String, Object> map = new HashMap<>();
			map.put("name", typeLevelSix.getCclxsixName());
			map.put("id", typeLevelSix.getCclxsixId());
			map.put("state", typeLevelSix.getCclxsixExtend1());
			list2.add(map);
		}
		int count = typeLevelSixMapper.findByCondition(conditionmap).size();
		conditionmap.put("limit", limit);
		conditionmap.put("offset", offset);
		conditionmap.put("state", 1);

		returnmap.put("message", "查询成功");
		returnmap.put("total", count);
		returnmap.put("code", "0000");
		returnmap.put("rows", list2);
		return returnmap;
	}

	/**
	 * 层次7增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> addLevelSevenItems(String name) {
		TypeLevelSeven typeLevelSeven = new TypeLevelSeven();
		Map<String, Object> map = new HashMap<>();
		Map<String, Object> conditionmap = new HashMap<>();
		conditionmap.put("cclxsevenExtend1", 1);
		conditionmap.put("cclxsevenName", name);
		List<TypeLevelSeven> list = typeLevelSevenMapper.findByCondition(conditionmap);
		if (!list.isEmpty()) {

			map.put("message", "名字重复新增失败");
			map.put("code", "9999");

		} else {

			typeLevelSeven.setCclxsevenName(name);
			typeLevelSeven.setCclxsevenExtend1("1");
			typeLevelSevenMapper.insert(typeLevelSeven);
			map.put("message", "新增成功");
			map.put("code", "0000");
		}

		return map;
	}

	/**
	 * 层次7删除和修改
	 * 
	 * @param id
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> updateLevelSevenItems(Integer id, String name, Integer state) {
		Map<String, Object> map = new HashMap<>();

		if (state == 0) {
			TypeLevelSeven typeLevelSeven = new TypeLevelSeven();
			typeLevelSeven = typeLevelSevenMapper.findById(id);
			typeLevelSeven.setCclxsevenExtend1("0");
			int users = typeLevelSevenMapper.update(typeLevelSeven);
			if (users == 1) {

				map.put("message", "删除成功");
				map.put("code", "0000");
			} else {
				map.put("message", "删除失败");
				map.put("code", "9999");
			}

		} else if (state == 1) {
			TypeLevelSeven typeLevelSeven = new TypeLevelSeven();
			typeLevelSeven = typeLevelSevenMapper.findById(id);
			Map<String, Object> conditionmap = new HashMap<>();
			conditionmap.put("cclxsevenExtend1", 1);
			conditionmap.put("cclxsevenName", name);
			List<TypeLevelSeven> list = typeLevelSevenMapper.findByCondition(conditionmap);
			conditionmap.put("cclxsevenId", id);
			List<TypeLevelSeven> list1 = typeLevelSevenMapper.findByCondition(conditionmap);
			if (!list.isEmpty() && list1.isEmpty()) {
				map.put("message", "名字重复修改失败");
				map.put("code", "9999");

			} else {
				typeLevelSeven.setCclxsevenName(name);
				int users = typeLevelSevenMapper.update(typeLevelSeven);
				if (users == 1) {

					map.put("message", "修改成功");
					map.put("code", "0000");
				} else {
					map.put("message", "修改失败");
					map.put("code", "9999");
				}

			}

		}
		return map;
	}

	/**
	 * 层次7查找
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */

	@Override
	public Map<String, Object> searchLevelSevenItems(Integer limit, Integer offset) {
		Map<String, Object> conditionmap = new HashMap<>();
		Map<String, Object> returnmap = new HashMap<>();
		conditionmap.put("cclxsevenExtend1", 1);
		List<TypeLevelSeven> list1 = typeLevelSevenMapper.findByCondition(conditionmap);
		List<Object> list2 = new ArrayList<>();
		for (TypeLevelSeven typeLevelSeven : list1) {
			Map<String, Object> map = new HashMap<>();
			map.put("name", typeLevelSeven.getCclxsevenName());
			map.put("id", typeLevelSeven.getCclxsevenId());
			map.put("state", typeLevelSeven.getCclxsevenExtend1());
			list2.add(map);
		}
		int count = typeLevelSevenMapper.findByCondition(conditionmap).size();
		conditionmap.put("limit", limit);
		conditionmap.put("offset", offset);
		conditionmap.put("state", 1);

		returnmap.put("message", "查询成功");
		returnmap.put("total", count);
		returnmap.put("code", "0000");
		returnmap.put("rows", list2);
		return returnmap;
	}

	/**
	 * 层次8增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> addLevelEightItems(String name) {
		TypeLevelEight typeLevelEight = new TypeLevelEight();
		Map<String, Object> map = new HashMap<>();
		Map<String, Object> conditionmap = new HashMap<>();
		conditionmap.put("cclxeightExtend1", 1);
		conditionmap.put("cclxeightName", name);
		List<TypeLevelEight> list = typeLevelEightMapper.findByCondition(conditionmap);
		if (!list.isEmpty()) {

			map.put("message", "名字重复新增失败");
			map.put("code", "9999");

		} else {

			typeLevelEight.setCclxeightName(name);
			typeLevelEight.setCclxeightExtend1("1");
			typeLevelEightMapper.insert(typeLevelEight);
			map.put("message", "新增成功");
			map.put("code", "0000");
		}

		return map;
	}

	/**
	 * 层次8删除和修改
	 * 
	 * @param id
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> updateLevelEightItems(Integer id, String name, Integer state) {
		Map<String, Object> map = new HashMap<>();

		if (state == 0) {
			TypeLevelEight typeLevelEight = new TypeLevelEight();
			typeLevelEight = typeLevelEightMapper.findById(id);
			typeLevelEight.setCclxeightExtend1("0");
			int users = typeLevelEightMapper.update(typeLevelEight);
			if (users == 1) {

				map.put("message", "删除成功");
				map.put("code", "0000");
			} else {
				map.put("message", "删除失败");
				map.put("code", "9999");
			}

		} else if (state == 1) {
			TypeLevelEight typeLevelEight = new TypeLevelEight();
			typeLevelEight = typeLevelEightMapper.findById(id);
			Map<String, Object> conditionmap = new HashMap<>();
			conditionmap.put("cclxeightExtend1", 1);
			conditionmap.put("cclxeightName", name);
			List<TypeLevelEight> list = typeLevelEightMapper.findByCondition(conditionmap);
			conditionmap.put("cclxeightId", id);
			List<TypeLevelEight> list1 = typeLevelEightMapper.findByCondition(conditionmap);
			if (!list.isEmpty() && list1.isEmpty()) {
				map.put("message", "名字重复修改失败");
				map.put("code", "9999");

			} else {
				typeLevelEight.setCclxeightName(name);
				int users = typeLevelEightMapper.update(typeLevelEight);
				if (users == 1) {
					map.put("message", "修改成功");
					map.put("code", "0000");
				} else {
					map.put("message", "修改失败");
					map.put("code", "9999");
				}

			}

		}
		return map;
	}

	/**
	 * 层次8查找
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */

	@Override
	public Map<String, Object> searchLevelEightItems(Integer limit, Integer offset) {
		Map<String, Object> conditionmap = new HashMap<>();
		Map<String, Object> returnmap = new HashMap<>();
		conditionmap.put("cclxeightExtend1", 1);
		List<TypeLevelEight> list1 = new ArrayList<>();
		list1 = typeLevelEightMapper.findByCondition(conditionmap);

		List<Object> list2 = new ArrayList<>();
		for (TypeLevelEight typeLevelEight : list1) {
			Map<String, Object> map = new HashMap<>();
			map.put("name", typeLevelEight.getCclxeightName());
			map.put("id", typeLevelEight.getCclxeightId());
			map.put("state", typeLevelEight.getCclxeightExtend1());
			list2.add(map);
		}
		int count = typeLevelEightMapper.findByCondition(conditionmap).size();
		conditionmap.put("limit", limit);
		conditionmap.put("offset", offset);
		conditionmap.put("state", 1);

		returnmap.put("message", "查询成功");
		returnmap.put("total", count);
		returnmap.put("code", "0000");
		returnmap.put("rows", list2);
		return returnmap;
	}

	/**
	 * 层次9增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> addLevelNineItems(String name) {
		TypeLevelNine typeLevelNine = new TypeLevelNine();
		List<TypeLevelNine> list = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		Map<String, Object> conditionmap = new HashMap<>();
		conditionmap.put("cclxnineExtend1", 1);
		conditionmap.put("cclxnineName", name);
		list = typeLevelNineMapper.findByCondition(conditionmap);
		if (!list.isEmpty()) {

			map.put("message", "名字重复新增失败");
			map.put("code", "9999");

		} else {

			typeLevelNine.setCclxnineName(name);
			typeLevelNine.setCclxnineExtend1("1");
			typeLevelNineMapper.insert(typeLevelNine);
			map.put("message", "新增成功");
			map.put("code", "0000");
		}

		return map;
	}

	/**
	 * 层次9删除和修改
	 * 
	 * @param id
	 * @param offset
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> updateLevelNineItems(Integer id, String name, Integer state) {
		Map<String, Object> map = new HashMap<>();
		if (state == 0) {
			TypeLevelNine typeLevelNine = new TypeLevelNine();
			typeLevelNine = typeLevelNineMapper.findById(id);
			typeLevelNine.setCclxnineExtend1("0");
			int users = typeLevelNineMapper.update(typeLevelNine);
			if (users == 1) {
				map.put("message", "删除成功");
				map.put("code", "0000");
			} else {
				map.put("message", "删除失败");
				map.put("code", "9999");
			}

		} else if (state == 1) {
			TypeLevelNine typeLevelNine = new TypeLevelNine();

			typeLevelNine = typeLevelNineMapper.findById(id);
			Map<String, Object> conditionmap = new HashMap<>();
			conditionmap.put("cclxnineExtend1", 1);
			conditionmap.put("cclxnineName", name);
			List<TypeLevelNine> list = typeLevelNineMapper.findByCondition(conditionmap);
			conditionmap.put("cclxnineId", id);
			List<TypeLevelNine> list1 = typeLevelNineMapper.findByCondition(conditionmap);
			if (!list.isEmpty() && list1.isEmpty()) {
				map.put("message", "名字重复修改失败");
				map.put("code", "9999");
			} else {
				typeLevelNine.setCclxnineName(name);
				int users = typeLevelNineMapper.update(typeLevelNine);
				if (users == 1) {

					map.put("message", "修改成功");
					map.put("code", "0000");
				} else {
					map.put("message", "修改失败");
					map.put("code", "9999");
				}

			}

		}
		return map;
	}

	/**
	 * 层次9查找
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */

	@Override
	public Map<String, Object> searchLevelNineItems(Integer limit, Integer offset) {
		Map<String, Object> conditionmap = new HashMap<>();
		Map<String, Object> returnmap = new HashMap<>();
		conditionmap.put("cclxnineExtend1", 1);
		List<TypeLevelNine> list1 = typeLevelNineMapper.findByCondition(conditionmap);
		List<Object> list2 = new ArrayList<>();
		for (TypeLevelNine typeLevelNine : list1) {
			Map<String, Object> map = new HashMap<>();
			map.put("id", typeLevelNine.getCclxnineId());
			map.put("name", typeLevelNine.getCclxnineName());
			map.put("state", typeLevelNine.getCclxnineExtend1());

			list2.add(map);
		}
		int count = typeLevelNineMapper.findByCondition(conditionmap).size();
		conditionmap.put("limit", limit);
		conditionmap.put("offset", offset);
		conditionmap.put("state", 1);
		returnmap.put("rows", list2);
		returnmap.put("code", "0000");
		returnmap.put("total", count);
		returnmap.put("message", "查询成功");

		return returnmap;
	}

	/**
	 * 层次name修改
	 * 
	 * @param id
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	@Override
	public Map<String, Object> updateLevelNameItems(Integer id, String name) {
		TypeLevelName typeLevelName = new TypeLevelName();
		Map<String, Object> map = new HashMap<>();
		typeLevelName = typeLevelNameMapper.findById(id);
		Map<String, Object> conditionmap = new HashMap<>();
		conditionmap.put("ccmcName", name);
		List<TypeLevelName> list = typeLevelNameMapper.findByCondition(conditionmap);
		conditionmap.put("ccmcId", id);
		List<TypeLevelName> list1 = typeLevelNameMapper.findByCondition(conditionmap);
		if (!list.isEmpty() && list1.isEmpty()) {
				map.put("message", "名字重复修改失败");
				map.put("code", "9999");
	

		} else {
			typeLevelName.setCcmcName(name);
			int users = typeLevelNameMapper.update(typeLevelName);
			if (users == 1) {
				map.put("message", "修改成功");
				map.put("code", "0000");
			} else {
				map.put("message", "修改失败");
				map.put("code", "9999");
			}

		}
		return map;

	}

	/**
	 * 层次name查找
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */

	@Override
	public Map<String, Object> searchLevelNameItems() {
		Map<String, Object> conditionmap = new HashMap<>();
		Map<String, Object> returnmap = new HashMap<>();
		conditionmap.put("cclxnineExtend1", 1);
		List<TypeLevelName> list1 = typeLevelNameMapper.findByCondition(conditionmap);
		List<Object> list2 = new ArrayList<>();
		for (TypeLevelName typeLevelName : list1) {
			Map<String, Object> map = new HashMap<>();
			map.put("id", typeLevelName.getCcmcId());
			map.put("name", typeLevelName.getCcmcName());
			list2.add(map);
		}
		int count = typeLevelNineMapper.findByCondition(conditionmap).size();
		returnmap.put("rows", list2);
		returnmap.put("code", "0000");
		returnmap.put("total", count);
		returnmap.put("message", "查询成功");

		return returnmap;
	}

}
