package com.nbst.service;

import java.util.Map;

public interface IQueryService {
	/**
	 * 层次4增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> addLevelFourItems(String name);

	/**
	 * 层次4删除修改
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> updateLevelFourItems(Integer id, String name, Integer state);

	/**
	 * 层次4查询
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> searchLevelFourItems(Integer limit, Integer offset);

	/**
	 * 层次5增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> addLevelFiveItems(String name);

	/**
	 * 层次5删除修改
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> updateLevelFiveItems(Integer id, String name, Integer state);

	/**
	 * 层次5查询
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> searchLevelFiveItems(Integer limit, Integer offset);

	/**
	 * 层次2增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> addLevelTwoItems(String name);

	/**
	 * 层次2删除修改
	 * 
	 * @param id
	 * @param state
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> updateLevelTwoItems(Integer id, String name, Integer state);

	/**
	 * 层次2查询
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> searchLevelTwoItems(Integer limit, Integer offset);

	/**
	 * 层次1增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> addLevelOneItems(String name);

	/**
	 * 层次1删除修改
	 * 
	 * @param id
	 * @param state
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> updateLevelOneItems(Integer id, String name, Integer state);

	/**
	 * 层次1查询
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> searchLevelOneItems(Integer limit, Integer offset);

	/**
	 * 层次3增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> addLevelThreeItems(String name);

	/**
	 * 层次3删除修改
	 * 
	 * @param id
	 * @param state
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> updateLevelThreeItems(Integer id, String name, Integer state);

	/**
	 * 层次3查询
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> searchLevelThreeItems(Integer limit, Integer offset);

	/**
	 * 层次6增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> addLevelSixItems(String name);

	/**
	 * 层次6删除修改
	 * 
	 * @param id
	 * @param state
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> updateLevelSixItems(Integer id, String name, Integer state);

	/**
	 * 层次6查询
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> searchLevelSixItems(Integer limit, Integer offset);

	/**
	 * 层次7增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> addLevelSevenItems(String name);

	/**
	 * 层次7删除修改
	 * 
	 * @param id
	 * @param state
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> updateLevelSevenItems(Integer id, String name, Integer state);

	/**
	 * 层次7查询
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> searchLevelSevenItems(Integer limit, Integer offset);

	/**
	 * 层次8增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> addLevelEightItems(String name);

	/**
	 * 层次8删除修改
	 * 
	 * @param id
	 * @param state
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> updateLevelEightItems(Integer id, String name, Integer state);

	/**
	 * 层次8查询
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> searchLevelEightItems(Integer limit, Integer offset);

	/**
	 * 层次9增加
	 * 
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> addLevelNineItems(String name);

	/**
	 * 层次9删除修改
	 * 
	 * @param id
	 * @param state
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> updateLevelNineItems(Integer id, String name, Integer state);

	/**
	 * 层次9查询
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> searchLevelNineItems(Integer limit, Integer offset);

	/**
	 * 层次name删除修改
	 * 
	 * @param id
	 * @param state
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> updateLevelNameItems(Integer id, String name);

	/**
	 * 层次name查询
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	Map<String, Object> searchLevelNameItems();

}
