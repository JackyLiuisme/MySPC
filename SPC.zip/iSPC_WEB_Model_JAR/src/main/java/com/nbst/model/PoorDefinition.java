package com.nbst.model;

public class PoorDefinition {
    private Integer bldyId;

    private String bldyCode;

    private String bldyName;

    private String bldyDecribe;

    private String bldyExtend1;

    private String bldyExtend2;

    private String bldyExtend3;

    private String bldyExtend4;

    private String bldyExtend5;

    public Integer getBldyId() {
        return bldyId;
    }

    public void setBldyId(Integer bldyId) {
        this.bldyId = bldyId;
    }

    public String getBldyCode() {
        return bldyCode;
    }

    public void setBldyCode(String bldyCode) {
        this.bldyCode = bldyCode == null ? null : bldyCode.trim();
    }

    public String getBldyName() {
        return bldyName;
    }

    public void setBldyName(String bldyName) {
        this.bldyName = bldyName == null ? null : bldyName.trim();
    }

    public String getBldyDecribe() {
        return bldyDecribe;
    }

    public void setBldyDecribe(String bldyDecribe) {
        this.bldyDecribe = bldyDecribe == null ? null : bldyDecribe.trim();
    }

    public String getBldyExtend1() {
        return bldyExtend1;
    }

    public void setBldyExtend1(String bldyExtend1) {
        this.bldyExtend1 = bldyExtend1 == null ? null : bldyExtend1.trim();
    }

    public String getBldyExtend2() {
        return bldyExtend2;
    }

    public void setBldyExtend2(String bldyExtend2) {
        this.bldyExtend2 = bldyExtend2 == null ? null : bldyExtend2.trim();
    }

    public String getBldyExtend3() {
        return bldyExtend3;
    }

    public void setBldyExtend3(String bldyExtend3) {
        this.bldyExtend3 = bldyExtend3 == null ? null : bldyExtend3.trim();
    }

    public String getBldyExtend4() {
        return bldyExtend4;
    }

    public void setBldyExtend4(String bldyExtend4) {
        this.bldyExtend4 = bldyExtend4 == null ? null : bldyExtend4.trim();
    }

    public String getBldyExtend5() {
        return bldyExtend5;
    }

    public void setBldyExtend5(String bldyExtend5) {
        this.bldyExtend5 = bldyExtend5 == null ? null : bldyExtend5.trim();
    }
}