package com.nbst.model;

public class TypeLevelSix {
	// ID
	private Integer cclxsixId;
	// 层次类型名称
	private String cclxsixName;
	//状态
	private String cclxsixExtend1;

	private String cclxsixExtend2;

	private String cclxsixExtend3;

	private String cclxsixExtend4;

	private String cclxsixExtend5;

	public Integer getCclxsixId() {
		return cclxsixId;
	}

	public void setCclxsixId(Integer cclxsixId) {
		this.cclxsixId = cclxsixId;
	}

	public String getCclxsixName() {
		return cclxsixName;
	}

	public void setCclxsixName(String cclxsixName) {
		this.cclxsixName = cclxsixName == null ? null : cclxsixName.trim();
	}

	public String getCclxsixExtend1() {
		return cclxsixExtend1;
	}

	public void setCclxsixExtend1(String cclxsixExtend1) {
		this.cclxsixExtend1 = cclxsixExtend1 == null ? null : cclxsixExtend1.trim();
	}

	public String getCclxsixExtend2() {
		return cclxsixExtend2;
	}

	public void setCclxsixExtend2(String cclxsixExtend2) {
		this.cclxsixExtend2 = cclxsixExtend2 == null ? null : cclxsixExtend2.trim();
	}

	public String getCclxsixExtend3() {
		return cclxsixExtend3;
	}

	public void setCclxsixExtend3(String cclxsixExtend3) {
		this.cclxsixExtend3 = cclxsixExtend3 == null ? null : cclxsixExtend3.trim();
	}

	public String getCclxsixExtend4() {
		return cclxsixExtend4;
	}

	public void setCclxsixExtend4(String cclxsixExtend4) {
		this.cclxsixExtend4 = cclxsixExtend4 == null ? null : cclxsixExtend4.trim();
	}

	public String getCclxsixExtend5() {
		return cclxsixExtend5;
	}

	public void setCclxsixExtend5(String cclxsixExtend5) {
		this.cclxsixExtend5 = cclxsixExtend5 == null ? null : cclxsixExtend5.trim();
	}

	@Override
	public String toString() {
		return "TypeLevelSix [cclxsixId=" + cclxsixId + ", cclxsixName=" + cclxsixName + ", cclxsixExtend1="
				+ cclxsixExtend1 + ", cclxsixExtend2=" + cclxsixExtend2 + ", cclxsixExtend3=" + cclxsixExtend3
				+ ", cclxsixExtend4=" + cclxsixExtend4 + ", cclxsixExtend5=" + cclxsixExtend5 + "]";
	}
}