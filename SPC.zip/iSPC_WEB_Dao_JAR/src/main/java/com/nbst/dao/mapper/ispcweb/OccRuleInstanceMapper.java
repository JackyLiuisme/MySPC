package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.OccRuleInstance;

public interface OccRuleInstanceMapper {
    int delete(Integer pygzslId);

    int insert(OccRuleInstance record);

    OccRuleInstance findById(Integer pygzslId);

    int update(OccRuleInstance record);

    List<OccRuleInstance> findByCondition(Map<String,Object> map);
    
    int count(Map<String,Object> map);

    //根据控制图id查询关联的判异规则的id和编号
    List<Map<String, String>> findOOCRuleByControlChartId(Integer pygzslControlChartId);

    //根据控制图id和判异规则id查询判异规则实例的值
    List<Integer> findOOCRuleInstanceByControlChartIdOccRuleId(Map<String,Object> map);
}