package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.DetectionData;

public interface DetectionDataMapper {
    int delete(Integer jcsjId);

    int insert(DetectionData record);

    DetectionData findById(Integer jcsjId);

    int update(DetectionData record);

    List<DetectionData> findByCondition(Map<String,Object> map);
    
    int count(Map<String,Object> map);
}