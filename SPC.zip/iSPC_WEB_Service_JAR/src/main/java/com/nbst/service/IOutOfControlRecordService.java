package com.nbst.service;

import java.util.Map;

import com.nbst.model.OutOfControlRecord;

/**
 * @author huangjx
 *
 */
public interface IOutOfControlRecordService {
	
	/**
	 * 提交失控处理，第一次失控处理要新增失控记录，后面失控处理修改失控记录
	 * @param controlChartId
	 * @param detectionDataId
	 * @param reason
	 * @param step
	 * @param managerPersonId
	 * @param state,0，再次失控处理为1
	 * @return
	 */
	Map<String,Object> alterOutOfControl(Integer controlChartId,Integer detectionDataId,String reason,String step,Integer managerPersonId,Integer state);
	/**
	 *根据检测数据id查找对应的失控记录
	 * @param detectionDataId
	 * @return
	 */
	Map<String,Object> searchOutOfControl(Integer detectionDataId);
	
	/**
	 * 根据record中skjlDetectionDataId找到相应的失控记录，用record中的审核信息去更新这条失控记录
	 * @param record
	 * @return
	 */
	Map<String,Object> updateAudit(Integer detectionDataId,Integer auditResult,String auditDiscription,Integer auditorId);
	
	
	/**
	 * @param state,显示已审核、未审核、未处理、全部的失控点数据
	 * @param controlChartId，查找的失控点数据属于该id对应的控制图
	 * @return
	 */
	Map<String,Object> searchList(Integer state,Integer controlChartId);
}
