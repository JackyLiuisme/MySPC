package com.nbst.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nbst.comnutil.AppUtil;
import com.nbst.model.DetectionDeviceDetectionItemRelationship;
import com.nbst.service.IDetectionDeviceDetectionItemRelationshipService;

import groovy.util.logging.Slf4j;

/**
 * @author yangl
 *
 */
@Controller
@RequestMapping("/DetectionDeviceDetectionItemRelationship")
@Slf4j
@CrossOrigin
public class DetectionDeviceDetectionItemRelationshipController {
	@Autowired
	private IDetectionDeviceDetectionItemRelationshipService relationService;

	/**
	 * 检测设备检测项关联新增
	 * 
	 * @param relation
	 * @return
	 */
	@RequestMapping(value = "/add.action", method = RequestMethod.POST)
	@ResponseBody
	public Object addDetectionItem(DetectionDeviceDetectionItemRelationship relation) {
		return AppUtil.conversionJsonp(relationService.add(relation));
	}

	/**
	 * 检测设备检测项关联修改/删除
	 * 
	 * @param relation
	 * @param state
	 * @return
	 */
	@RequestMapping(value = "/update.action", method = RequestMethod.POST)
	@ResponseBody
	public Object update(DetectionDeviceDetectionItemRelationship relation, Integer state) {
		return AppUtil.conversionJsonp(relationService.alter(relation, state));
	}

	/**
	 * 检测设备检测项关联查询
	 * 
	 * @param limit
	 * @param offset
	 * @return
	 */
	@RequestMapping(value = "/search.action", method = RequestMethod.GET)
	@ResponseBody
	public Object search(Integer limit, Integer offset) {
		return AppUtil.conversionJsonp(relationService.search(limit, offset));
	}
}
