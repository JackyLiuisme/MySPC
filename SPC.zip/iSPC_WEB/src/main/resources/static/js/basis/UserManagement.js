var yhId='';//保存id，用于修改
var flag='';
/**
 * @method 
 * @desc  弹出新增窗口
 * @author gj
 * @date 2018年10月14日
 */

function showAdd(){
	$("#username,#name,#password").val("");
	flag=1;
	$("#myModalLabel").html("添加");
	$("#myModal").modal('show');
}

/**
 * 提交新增和修改
 */
  
function save(){//新增,修改	
	if(flag==1){
		if($("#username").val()==""){
			toastr.warning("用户名不得为空!");
			return false;
		}
		if($("#name").val()==""){
			toastr.warning("姓名不得为空!");
			return false;
		}
		if($("#password").val()==""){
			toastr.warning("密码不得为空!");
			return false;
		}
		$.ajax({
			url:"userManagement/add.action",
	        type: "POST",
	        dataType:"JSON",
	        data:{
	        	yhUsername:$("#username").val(),
	        	yhName:$("#name").val(),
	        	yhPassword:$("#password").val()
	        },
	        success: function(data) {
	        	if(data.code=="0000"){
	        		toastr.success(data.message);
	        		$("#myModal").modal('hide');
		        	showTable();
	        	}else{
	        		toastr.error(data.message);
	        	}
	        	
	        },
	        error: function(request) {
	        	console.log(request);
	        }
		});
	}else if(flag==2){//修改
		if(yhId==''){
			toastr.warning("请选择用户!");
			return false;
		}
		if($("#yhUserName").val()==""){
			toastr.warning("用户名不得为空!");
			return false;
		}
		if($("#yhName").val()==""){
			toastr.warning("姓名不得为空!");
			return false;
		}
		var data={};
		data.yhId=yhId;
		data.yhUsername=$("#yhUserName").val();
		data.yhName=$("#yhName").val();
		if($("#yhPassword").val()!=""){
			data.yhUserPassword=$("#yhPassword").val();
		}
		data.state=1;
		$.ajax({
			url:"userManagement/update.action",
	        type: "POST",
	        dataType:"JSON",
	        data:data,
	        success: function(data) {
	        	if(data.code=="0000"){
	        		toastr.success(data.message);
		        	showTable();
	        	}else{
	        		toastr.error(data.message);
	        	}
	        },
	        error: function(request) {
	        	console.log(request);
	        }
		});
}}

/**
 * 操作格式化
 */

function operate(value, row, index) {
	var str = "";
    str += '<a class="btn btn-info btn-xs update" style="background-color: #f5b834;border-color: #f5b834">修改</a>&nbsp';
    str += '<a class="btn btn-info btn-xs delete" style="background-color: #f23333;border-color: #f23333">删除</a>&nbsp';
	return str;
}
/**
 * 操作点击事件
 */

window.operateEvents = {
		'click .update' : function(e, value, row, index) {//修改	
			loadData(row,"#table");
			$("#yhUserName").val(row.yhUsername);
			$("#yhName").val(row.yhName);
			$("#yhPassword").val('');
			$("#myModalLabel").html("用户信息");
			flag=2;
			yhId=row.yhId;
		},
		'click .delete' : function(e, value, row, index) {
			Showbo.Msg.confirm('是否确认删除？',
			function(btn){
				if(btn == "yes"){
					$.ajax({
						url:"userManagement/update.action",
				        type: "POST",
				        dataType:"JSON",
				        data:{
				        	yhId:row.yhId,
				        	state:0
				        },
				        success: function(data) {
				        	if(data.code=="0000"){
				        		console.log(data);
				        		toastr.success(data.message);
				        	}else{
				        		toastr.error(data.message);
				        	}
				        	if(yhId==row.yhId){
				        		$("#yhPassword,#yhUserName,#yhName").val("");
				        	}
				        	showTable();
				        },
				        error: function(request) {
				        	console.log(request);
				        }
					});
				}
			});
		}
}
/**
 * 调用显示table接口
 */
showTable();

/**
 * 
 * @method
 * @desc  显示用户管理列表
 * @author gj
 * @date 2018年10月14日
 */

function showTable() {
	$('#table').bootstrapTable('destroy').bootstrapTable({
		url : "userManagement/search.action", //请求后台的URL（*）  
		queryParams : function(param){
			 return{
				 limit:param.limit,
				 offset:param.offset
			 }
		 },// 传递参数（*）
		sidePagination : "server", // 分页方式：client客户端分页，server服务端分页（*）
		striped : false, // 是否显示行间隔色
		pagination : true, // 是否显示分页（*）
		sortable : false, // 是否启用排序
		sortOrder : "asc", // 排序方式
        toolbar:"#toolbar",
		pageNumber : 1, // 初始化加载第一页，默认第一页
		pageSize : 10, // 每页的记录行数（*）
		pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
		strictSearch : true,
		clickToSelect : true, // 是否启用点击选中行
		height : 412, // 行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		columns : [ 
       {
		field : 'yhUsername',
		title : '用户名',
		align:"center"
	   }, 
		{
			field : 'yhName',
			title : '姓名',
			align:"center",
		},
	   {
			field : '',
			title : '操作',
			align:"center",
			formatter :operate,
			events : operateEvents
		}
		],
		onLoadSuccess : function(data) {
		}		
		
	});
};



