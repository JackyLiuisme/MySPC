package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.PoorDefinitionControlChartInfomationRelationship;

public interface PoorDefinitionControlChartInfomationRelationshipMapper {
    int delete(Integer bldykztxxglId);

    int insert(PoorDefinitionControlChartInfomationRelationship record);

    PoorDefinitionControlChartInfomationRelationship findById(Integer bldykztxxglId);
    
    int update(PoorDefinitionControlChartInfomationRelationship record);
    
    List<PoorDefinitionControlChartInfomationRelationship> findByCondition(Map<String,Object> map);
    
    int count(Map<String,Object> map);
}