package com.nbst.model;

public class ControlChartTypeProperty {
	private Integer kztsxId;
	// 属性名称
	private String kztsxName;
	// 控制图类型id
	private Integer kztsxTypeId;

	private String kztsxExtend1;

	private String kztsxExtend2;

	private String kztsxExtend3;

	private String kztsxExtend4;

	private String kztsxExtend5;

	public Integer getKztsxId() {
		return kztsxId;
	}

	public void setKztsxId(Integer kztsxId) {
		this.kztsxId = kztsxId;
	}

	public String getKztsxName() {
		return kztsxName;
	}

	public void setKztsxName(String kztsxName) {
		this.kztsxName = kztsxName == null ? null : kztsxName.trim();
	}

	public Integer getKztsxTypeId() {
		return kztsxTypeId;
	}

	public void setKztsxTypeId(Integer kztsxTypeId) {
		this.kztsxTypeId = kztsxTypeId;
	}

	public String getKztsxExtend1() {
		return kztsxExtend1;
	}

	public void setKztsxExtend1(String kztsxExtend1) {
		this.kztsxExtend1 = kztsxExtend1 == null ? null : kztsxExtend1.trim();
	}

	public String getKztsxExtend2() {
		return kztsxExtend2;
	}

	public void setKztsxExtend2(String kztsxExtend2) {
		this.kztsxExtend2 = kztsxExtend2 == null ? null : kztsxExtend2.trim();
	}

	public String getKztsxExtend3() {
		return kztsxExtend3;
	}

	public void setKztsxExtend3(String kztsxExtend3) {
		this.kztsxExtend3 = kztsxExtend3 == null ? null : kztsxExtend3.trim();
	}

	public String getKztsxExtend4() {
		return kztsxExtend4;
	}

	public void setKztsxExtend4(String kztsxExtend4) {
		this.kztsxExtend4 = kztsxExtend4 == null ? null : kztsxExtend4.trim();
	}

	public String getKztsxExtend5() {
		return kztsxExtend5;
	}

	public void setKztsxExtend5(String kztsxExtend5) {
		this.kztsxExtend5 = kztsxExtend5 == null ? null : kztsxExtend5.trim();
	}

	@Override
	public String toString() {
		return "ControlChartTypeProperty [kztsxId=" + kztsxId + ", kztsxName=" + kztsxName + ", kztsxTypeId="
				+ kztsxTypeId + ", kztsxExtend1=" + kztsxExtend1 + ", kztsxExtend2=" + kztsxExtend2 + ", kztsxExtend3="
				+ kztsxExtend3 + ", kztsxExtend4=" + kztsxExtend4 + ", kztsxExtend5=" + kztsxExtend5 + "]";
	}

}