package com.nbst.model;

public class Roles {
    private Integer jsId;

    private Integer jsGsId; //公司ID

    private String jsName; //角色名称

    private Integer jsType; //角色类型，1为普通用户角色，2为平台管理员角色

    private Long jsCreateTime; //创建时间

    private Integer jsState=1; //状态，1为正常，2为已删除

    private Long jsUpdateTime; //修改时间

    private Long jsDeleteTime; //删除时间

    private String jsExtend1; 

    private String jsExtend2;

    private String jsExtend3;

    private String jsExtend4;

    private String jsExtend5;

    public Integer getJsId() {
        return jsId;
    }

    public void setJsId(Integer jsId) {
        this.jsId = jsId;
    }

    public Integer getJsGsId() {
        return jsGsId;
    }

    public void setJsGsId(Integer jsGsId) {
        this.jsGsId = jsGsId;
    }

    public String getJsName() {
        return jsName;
    }

    public void setJsName(String jsName) {
        this.jsName = jsName == null ? null : jsName.trim();
    }

    public Integer getJsType() {
        return jsType;
    }

    public void setJsType(Integer jsType) {
        this.jsType = jsType;
    }

    public Long getJsCreateTime() {
        return jsCreateTime;
    }

    public void setJsCreateTime(Long jsCreateTime) {
        this.jsCreateTime = jsCreateTime;
    }

    public Integer getJsState() {
        return jsState;
    }

    public void setJsState(Integer jsState) {
        this.jsState = jsState;
    }

    public Long getJsUpdateTime() {
        return jsUpdateTime;
    }

    public void setJsUpdateTime(Long jsUpdateTime) {
        this.jsUpdateTime = jsUpdateTime;
    }

    public Long getJsDeleteTime() {
        return jsDeleteTime;
    }

    public void setJsDeleteTime(Long jsDeleteTime) {
        this.jsDeleteTime = jsDeleteTime;
    }

    public String getJsExtend1() {
        return jsExtend1;
    }

    public void setJsExtend1(String jsExtend1) {
        this.jsExtend1 = jsExtend1 == null ? null : jsExtend1.trim();
    }

    public String getJsExtend2() {
        return jsExtend2;
    }

    public void setJsExtend2(String jsExtend2) {
        this.jsExtend2 = jsExtend2 == null ? null : jsExtend2.trim();
    }

    public String getJsExtend3() {
        return jsExtend3;
    }

    public void setJsExtend3(String jsExtend3) {
        this.jsExtend3 = jsExtend3 == null ? null : jsExtend3.trim();
    }

    public String getJsExtend4() {
        return jsExtend4;
    }

    public void setJsExtend4(String jsExtend4) {
        this.jsExtend4 = jsExtend4 == null ? null : jsExtend4.trim();
    }

    public String getJsExtend5() {
        return jsExtend5;
    }

    public void setJsExtend5(String jsExtend5) {
        this.jsExtend5 = jsExtend5 == null ? null : jsExtend5.trim();
    }

	@Override
	public String toString() {
		return "Roles [jsId=" + jsId + ", jsGsId=" + jsGsId + ", jsName=" + jsName + ", jsType=" + jsType
				+ ", jsCreateTime=" + jsCreateTime + ", jsState=" + jsState + ", jsUpdateTime=" + jsUpdateTime
				+ ", jsDeleteTime=" + jsDeleteTime + ", jsExtend1=" + jsExtend1 + ", jsExtend2=" + jsExtend2
				+ ", jsExtend3=" + jsExtend3 + ", jsExtend4=" + jsExtend4 + ", jsExtend5=" + jsExtend5 + "]";
	}
}