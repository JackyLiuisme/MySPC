package com.nbst.dao.datasource;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

import lombok.extern.slf4j.Slf4j;
/**
 * 动态数据源，继承spring提供的AbstractRoutingDataSource并重写determineCurrentLookupKey方法
 *
 */
@Slf4j
public class DynamicDataSource extends AbstractRoutingDataSource {
     @Override
     protected Object determineCurrentLookupKey() {
         // 从自定义的位置获取数据源标识
         return DynamicDataSourceHolder.getDataSource();
     }
 
 }
