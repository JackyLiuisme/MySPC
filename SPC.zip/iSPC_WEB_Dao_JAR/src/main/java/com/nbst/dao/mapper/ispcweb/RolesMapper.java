package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.Roles;

public interface RolesMapper {
    int delete(Integer jsId);

    int insert(Roles record);

    Roles findById(Integer jsId);

    int update(Roles record);

    int count(Map<String, Object> map);

	List<Roles> findByCondition(Map map);
}