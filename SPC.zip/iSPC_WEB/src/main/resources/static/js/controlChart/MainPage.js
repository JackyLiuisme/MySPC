var flagx=1;//控制控制图层次信息和数据点层次信息
var checkkztValue=new Array();
var checksjdValue=new Array();
var selectData="";//用于存放控制图层次信息和数据点层次信息的勾选值
var dataStr="";//用于拼接存放控制图层次信息和数据点层次信息的勾选值
function setting_ypgz_add(){
	$("#ypgzModal").modal('show');
}

/********************************控制图展示****************************/

function operateState(value, row, index) {
	var str = "";
	 str += "<button class='btn btn-danger btn-sm error' >失控</button>"
	return str;
}
/**
 * 操作点击事件
 */
window.operateStateEvents = {
		'click .error' : function(e, value, row, index) {
			$("#errorModal").modal('show');
			showLsjyList();
		}
};



showDataList();
function showDataList() {
	$('#dataList').bootstrapTable('destroy').bootstrapTable({
//		url : subURL('equipmentCapacity/search.action'), //请求后台的URL（*）  
		dataType:'jsonp',
		striped : false, // 是否显示行间隔色
		pagination : true, // 是否显示分页（*）
		sortable : false, // 是否启用排序
		sortOrder : "asc", // 排序方式
        toolbar:"#toolbar",
		pageNumber : 1, // 初始化加载第一页，默认第一页
		pageSize : 10, // 每页的记录行数（*）
		pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
		strictSearch : true,
		clickToSelect : true, // 是否启用点击选中行
		height : 312, // 行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		columns : [ 
       {field : 'xh',title : '序号',align:"center",},	
       {field : 'cjsj',title : '抽检时间',align:"center"},
       {field : 'lrsj',title : '录入时间',align:"center"}, 
       {field : 'sb',title : '设备',align:"center"}, 
       {field : 'yb1',title : '样本1',align:"center"}, 
       {field : 'yb2',title : '样本2',align:"center"}, 
       {field : 'yb3',title : '样本3',align:"center"}, 
       {field : 'yb4',title : '样本4',align:"center"}, 
       {field : 'yb5',title : '样本5',align:"center"}, 
       {field : 'state',title : '状态',align:"center",formatter : operateState,events : operateStateEvents},		
       {field : 'pjz',title : '平均值',align:"center"}, 
       {field : 'jcz',title : '极差值',align:"center"}, 
       {field : 'bzc',title : '标准差',align:"center"}, 
       {field : 'zdz',title : '最大值',align:"center"}, 
       {field : 'zxz',title : '最小值',align:"center"}, 
       {field : 'lryh',title : '录入用户',align:"center"}, 
		],
		onLoadSuccess : function(data) {
		}
	});
	var data=[
			{
				"xh":"1",
				"cjsj":"2009-11-30 19:00:00",
				"lrsj":"2009-11-30 19:00:00",
				"sb":"",
				"yb1":"0.235",
				"yb2":"0.254",
				"yb3":"0.159",
				"yb4":"0.154",
				"yb5":"0.258",
				"state":"失控",
				"pjz":"0.987",
				"jcz":"0.951",
				"bzc":"0.369",
				"zdz":"0.369",
				"zxz":"0.258",
				"lryh":"admin",

			}

		]
	$('#dataList').bootstrapTable('load',data);
};


function showEcharts(){
	var myChart1 = echarts.init(document.getElementById('echarts1'));
	var option1 = {
	//  title: {
	//      text: '折线图堆叠'
	//  },
	    tooltip: {
	        trigger: 'axis'
	    },
	    grid: {
	        left: '3%',
	        right: '4%',
	        bottom: '6%',
	        top:"6%",
	        containLabel: true
	    },
	    xAxis: {
	        type: 'category',
	        boundaryGap: false,
	        data: ['1','2','3','4','5']
	    },
	    yAxis: {
	        type: 'value'
	    },
	    series: [
	        {
	            name:'',
	            type:'line',
	            stack: '总量',
	            data:[120, 132, 101, 134, 90]
	        }
	    ]
	};
	myChart1.setOption(option1, true);
	
	
	
	var myChart2 = echarts.init(document.getElementById('echarts2'));
	var option2 = {
	//  title: {
	//      text: '折线图堆叠'
	//  },
	    tooltip: {
	        trigger: 'axis'
	    },
	    grid: {
	        left: '3%',
	        right: '4%',
	        bottom: '6%',
	        top:"6%",
	        containLabel: true
	    },
	    xAxis: {
	        type: 'category',
	        boundaryGap: false,
	        data: ['1','2','3','4','5']
	    },
	    yAxis: {
	        type: 'value'
	    },
	    series: [
	        {
	            name:'',
	            type:'line',
	            stack: '总量',
	            data:[120, 132, 101, 134, 90]
	        }
	    ]
	};
	myChart2.setOption(option2, true);
}
/**************************************弹出框*********************************/

function formatTableUnit(value,row) {
	var color="#999";
	return {
		css: {
			"color": color
		}
	}
}

function setting_kztccxx_add(){
	$("#kztccxxModal .modal-title").html('控制图层次信息');
	$("#kztccxxModal").modal("show");
	flagx=1;
	showBXZ();
	for(var i=0;i<9;i++){
		if(checksjdValue[i]){//如果数据点勾选了，则控制图显示为只读
			//只读，没选中
		}
	}
}
function setting_sjdccxx_add(){
	$("#kztccxxModal .modal-title").html('数据点层次信息');
	$("#kztccxxModal").modal("show");
	flagx=2;
	showBXZ();
	for(var i=0;i<9;i++){
		if(checkkztValue[i]){//如果控制图勾选了，则数据点显示为只读
			//只读，没选中
		}
	}
}

function save_ccsj(){
	var str="";
	if(flagx==1){
		for(var i=0;i<9;i++){
			if($("#cb"+(i+1)).is(':checked')==true){//勾选框是否被选中
//				console.log($("#level"+(i+1)).html());
				if(i==0){
					str=$("#cc"+(i+1)).html()+"="+$("#level"+(i+1)+" option:selected").text()+str;//获取值
				}else{
					str=$("#cc"+(i+1)).html()+"="+$("#level"+(i+1)+" option:selected").text()+","+str;//获取值
				}
				switch(i){
					case 0:
						dataStr="kztxxccglTypeLevelOneId="+$("#level"+(i+1)).val()+"&"+"kztxxccglTypeLevelOneState="+flagx+"&";
//						console.log(dataStr);
						break;
					case 1:
						dataStr="kztxxccglTypeLevelTwoId="+$("#level"+(i+1)).val()+"&"+"kztxxccglTypeLevelTwoState="+flagx+"&";
					  break;
					case 2:
						dataStr="kztxxccglTypeLevelThreeId="+$("#level"+(i+1)).val()+"&"+"kztxxccglTypeLevelThreeState="+flagx+"&";
					  break;
					case 3:
						dataStr="kztxxccglTypeLevelFourId="+$("#level"+(i+1)).val()+"&"+"kztxxccglTypeLevelFourState="+flagx+"&";
					  break;
					case 4:
						dataStr="kztxxccglTypeLevelFiveId="+$("#level"+(i+1)).val()+"&"+"kztxxccglTypeLevelFiveState="+flagx+"&";
					  break;
					case 5:
						dataStr="kztxxccglTypeLevelSixId="+$("#level"+(i+1)).val()+"&"+"kztxxccglTypeLevelSixState="+flagx+"&";
					  break;
					case 6:
						dataStr="kztxxccglTypeLevelSevenId="+$("#level"+(i+1)).val()+"&"+"kztxxccglTypeLevelSevenState="+flagx+"&";
					  break;
					case 7:
						dataStr="kztxxccglTypeLevelEightId="+$("#level"+(i+1)).val()+"&"+"kztxxccglTypeLevelEightState="+flagx+"&";
					  break;
					case 8:
						dataStr="kztxxccglTypeLevelNineId="+$("#level"+(i+1)).val()+"&"+"kztxxccglTypeLevelNineState="+flagx+"&";
					  break;
 				}
				selectData=dataStr+selectData;				
			}	
			checkkztValue[i]=$("#cb"+(i+1)).is(':checked');//勾选情况 true false		
		}
//		console.log(checkkztValue);
		selectData="kztxxccglControlChartId="+kztList_id+"&"+selectData;
		console.log(selectData);
		$.ajax({
			url:"controlChartHierarchicalInformationRelationship/update.action",
	        type: "POST",
	        dataType:"JSON",
	        data:selectData,	        
	        success: function(data) {
	        	if(data.success == "0000"){
	        		console.log(data);
	        		toastr.success(data.message);
	        	}else{
	        		toastr.error(data.message);
	        	}
	        },
	        error: function(data) {
	        	toastr.error(data.message);
	        },
		});
		selectData="";
		$("#kztccxx").val(str);
	}else if(flagx==2){
		for(var i=0;i<9;i++){
			if($("#cb"+(i+1)).is(':checked')==true){
				if(i==0){
					str=$("#cc"+(i+1)).html()+"="+$("#level"+(i+1)+" option:selected").text()+str;
				}else{
					str=$("#cc"+(i+1)).html()+"="+$("#level"+(i+1)+" option:selected").text()+","+str;
				}
				switch(i){
				case 0:
					dataStr="kztxxccglTypeLevelOneId="+$("#level"+(i+1)).val()+"&"+"kztxxccglTypeLevelOneState="+flagx+"&";
//					console.log(dataStr);
					break;
				case 1:
					dataStr="kztxxccglTypeLevelTwoId="+$("#level"+(i+1)).val()+"&"+"kztxxccglTypeLevelTwoState="+flagx+"&";
				  break;
				case 2:
					dataStr="kztxxccglTypeLevelThreeId="+$("#level"+(i+1)).val()+"&"+"kztxxccglTypeLevelThreeState="+flagx+"&";
				  break;
				case 3:
					dataStr="kztxxccglTypeLevelFourId="+$("#level"+(i+1)).val()+"&"+"kztxxccglTypeLevelFourState="+flagx+"&";
				  break;
				case 4:
					dataStr="kztxxccglTypeLevelFiveId="+$("#level"+(i+1)).val()+"&"+"kztxxccglTypeLevelFiveState="+flagx+"&";
				  break;
				case 5:
					dataStr="kztxxccglTypeLevelSixId="+$("#level"+(i+1)).val()+"&"+"kztxxccglTypeLevelSixState="+flagx+"&";
				  break;
				case 6:
					dataStr="kztxxccglTypeLevelSevenId="+$("#level"+(i+1)).val()+"&"+"kztxxccglTypeLevelSevenState="+flagx+"&";
				  break;
				case 7:
					dataStr="kztxxccglTypeLevelEightId="+$("#level"+(i+1)).val()+"&"+"kztxxccglTypeLevelEightState="+flagx+"&";
				  break;
				case 8:
					dataStr="kztxxccglTypeLevelNineId="+$("#level"+(i+1)).val()+"&"+"kztxxccglTypeLevelNineState="+flagx+"&";
				  break;
				}
			selectData=dataStr+selectData;
			}
			checksjdValue[i]=$("#cb"+(i+1)).is(':checked');
		}
		console.log(selectData);
		selectData="kztxxccglControlChartId="+kztList_id+"&"+selectData;		
//		var stttr="kztxxccglId=21&kztxxccglControlChartId=2&kztxxccglTypeLevelThreeId=2&kztxxccglTypeLevelThreeState=1";
//		$.ajax({
//			url:"controlChartHierarchicalInformationRelationship/update.action",
//	        type: "POST",
//	        dataType:"JSON",
//	        data:stttr,	        
//	        success: function(data) {
//	        	console.log(data);
////	        	if(data.success == "0000"){
////	        		console.log(data);
////	        		toastr.success(data.message);
////	        	}else{
////	        		toastr.error(data.message);
////	        	}
//	        },
//	        error: function(data) {
//	        	toastr.error(data.message);
//	        },
//		});
		selectData="";
		$("#sjdccxx").val(str);
	}
	$("#kztccxxModal").modal('hide');
}


function showYpgzList() {
	$('#ypgzList').bootstrapTable('destroy').bootstrapTable({
//		url : subURL('equipmentCapacity/search.action'), //请求后台的URL（*）  
		dataType:'jsonp',
		striped : false, // 是否显示行间隔色
		pagination : true, // 是否显示分页（*）
		sortable : false, // 是否启用排序
		sortOrder : "asc", // 排序方式
        toolbar:"#toolbar",
		pageNumber : 1, // 初始化加载第一页，默认第一页
		pageSize : 10, // 每页的记录行数（*）
		pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
		strictSearch : true,
		clickToSelect : true, // 是否启用点击选中行
		height : 412, // 行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		columns : [ 
		{checkbox:true,},
       {field : 'bh',title : '规则编号',align:"center",},	
       {field : 'gz',title : '现行规则',align:"center"},
       {field : 'yj',title : '规则依据',align:"center",cellStyle: formatTableUnit}, 
		],
		onLoadSuccess : function(data) {

		}
	});
	var data=[
			{"bh":"R0","gz":"超出规格限","yj":"超出规格限"},
			{"bh":"R1","gz":"1个点落在3倍sigma区外","yj":"[n]个点落在[m]倍sigma区外"},
			{"bh":"R2","gz":"连续9点落在中心线同一侧","yj":"连续[n]点落在中心线同一侧"},
			{"bh":"R3","gz":"连续6点递增或递减","yj":"连续[n]点递增或递减"},
			{"bh":"R4","gz":"连续14点中相邻点交替上下","yj":"连续[n]点中相邻点交替上下"},
			{"bh":"R5","gz":"连续3点中有2点落在中心线同一侧的2倍sigma区以外","yj":"连续[n]点中有[m]点落在中心线同一侧的[k]倍sigma区以外"},
			{"bh":"R6","gz":"连续5点中有4点落在中心线同一侧的1倍sigma区以外","yj":"连续[n]点中有[m]点落在中心线同一侧的[k]倍sigma区以外"},
			{"bh":"R7","gz":"连续15点落在中心线两侧的1倍sigma区内","yj":"连续[n]点落在中心线两侧的[m]倍sigma区内"},
			{"bh":"R8","gz":"连续8点落在中心线两侧且无一在1倍sigma区内","yj":"连续[n]点落在中心线两侧且无一在[m]倍sigma区内"},

		]
	$('#ypgzList').bootstrapTable('load',data);
};


function showLsjyList() {
	$('#lsjyList').bootstrapTable('destroy').bootstrapTable({
//		url : subURL('equipmentCapacity/search.action'), //请求后台的URL（*）  
		dataType:'jsonp',
		striped : false, // 是否显示行间隔色
		pagination : true, // 是否显示分页（*）
		sortable : false, // 是否启用排序
		sortOrder : "asc", // 排序方式
        toolbar:"#toolbar",
		pageNumber : 1, // 初始化加载第一页，默认第一页
		pageSize : 10, // 每页的记录行数（*）
		pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
		strictSearch : true,
		clickToSelect : true, // 是否启用点击选中行
		height : 412, // 行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		columns : [ 
		{checkbox:true,},
       {field : 'skyy',title : '失控原因',align:"center",valign:'middle'},	
       {field : 'clcs',title : '处理措施',align:"center",valign:'middle'},
		],
		onLoadSuccess : function(data) {

		}
	});
	var data=[
			{"skyy":"工具的磨损,或操作者的疲劳等系统性原因造成的.","clcs":"加强教育训练及在人事行政上做出合理的工作时间安排"},
			{"skyy":"加工工具突然磨损.","clcs":"更换磨损工具"},
			{"skyy":"测量工具有误差。","clcs":"检查测量工具。"},
			{"skyy":"直方图为偏向型特点是有两个高峰.这是由于数据来自不同的总体造成的.如把来自两个工人或两批原材料或两台设备或两个厂家生产的产品混在一起作直方图造成的.","clcs":"采用正确的分层方法"},
			{"skyy":"加工习惯造成的对孔的加工,特性值往往偏小,易出现左偏型;对轴的加工特性值往往偏大,易出现右偏型","clcs":"纠正加工习惯问题"},

		]
	$('#lsjyList').bootstrapTable('load',data);
};



function showDisposeList() {
	$('#disposeList').bootstrapTable('destroy').bootstrapTable({
//		url : subURL('equipmentCapacity/search.action'), //请求后台的URL（*）  
		dataType:'jsonp',
		striped : false, // 是否显示行间隔色
		pagination : true, // 是否显示分页（*）
		sortable : false, // 是否启用排序
		sortOrder : "asc", // 排序方式
        toolbar:"#toolbar",
		pageNumber : 1, // 初始化加载第一页，默认第一页
		pageSize : 10, // 每页的记录行数（*）
		pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
		strictSearch : true,
		clickToSelect : true, // 是否启用点击选中行
		height : 412, // 行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		columns : [ 
       {field : 'state',title : '状态',align:"center",valign:'middle'},	
       {field : 'code',title : '编号',align:"center",valign:'middle'},
       {field : 'jcxm',title : '检测项目',align:"center",valign:'middle'},
       {field : 'tl',title : '图类',align:"center",valign:'middle'},
       {field : 'xh',title : '序号',align:"center",valign:'middle'},
		],
		onLoadSuccess : function(data) {

		}
	});
	var data=[
			{"state":"未审核.","code":"123456","jcxm":"参数B2","tl":"XS","xh":5},
			{"state":"未审核.","code":"123456","jcxm":"参数B2","tl":"XS","xh":3},

		]
	$('#disposeList').bootstrapTable('load',data);
};