package com.nbst.model;

public class TypeLevelNine {
	// ID
	private Integer cclxnineId;
	// 层次类型名称
	private String cclxnineName;
	//状态
	private String cclxnineExtend1;

	private String cclxnineExtend2;

	private String cclxnineExtend3;

	private String cclxnineExtend4;

	private String cclxnineExtend5;

	public Integer getCclxnineId() {
		return cclxnineId;
	}

	public void setCclxnineId(Integer cclxnineId) {
		this.cclxnineId = cclxnineId;
	}

	public String getCclxnineName() {
		return cclxnineName;
	}

	public void setCclxnineName(String cclxnineName) {
		this.cclxnineName = cclxnineName == null ? null : cclxnineName.trim();
	}

	public String getCclxnineExtend1() {
		return cclxnineExtend1;
	}

	public void setCclxnineExtend1(String cclxnineExtend1) {
		this.cclxnineExtend1 = cclxnineExtend1 == null ? null : cclxnineExtend1.trim();
	}

	public String getCclxnineExtend2() {
		return cclxnineExtend2;
	}

	public void setCclxnineExtend2(String cclxnineExtend2) {
		this.cclxnineExtend2 = cclxnineExtend2 == null ? null : cclxnineExtend2.trim();
	}

	public String getCclxnineExtend3() {
		return cclxnineExtend3;
	}

	public void setCclxnineExtend3(String cclxnineExtend3) {
		this.cclxnineExtend3 = cclxnineExtend3 == null ? null : cclxnineExtend3.trim();
	}

	public String getCclxnineExtend4() {
		return cclxnineExtend4;
	}

	public void setCclxnineExtend4(String cclxnineExtend4) {
		this.cclxnineExtend4 = cclxnineExtend4 == null ? null : cclxnineExtend4.trim();
	}

	public String getCclxnineExtend5() {
		return cclxnineExtend5;
	}

	public void setCclxnineExtend5(String cclxnineExtend5) {
		this.cclxnineExtend5 = cclxnineExtend5 == null ? null : cclxnineExtend5.trim();
	}

	@Override
	public String toString() {
		return "TypeLevelNine [cclxnineId=" + cclxnineId + ", cclxnineName=" + cclxnineName + ", cclxnineExtend1="
				+ cclxnineExtend1 + ", cclxnineExtend2=" + cclxnineExtend2 + ", cclxnineExtend3=" + cclxnineExtend3
				+ ", cclxnineExtend4=" + cclxnineExtend4 + ", cclxnineExtend5=" + cclxnineExtend5 + "]";
	}
}