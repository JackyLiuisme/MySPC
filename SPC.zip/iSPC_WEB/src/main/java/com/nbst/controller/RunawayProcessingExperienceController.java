package com.nbst.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nbst.comnutil.AppUtil;
import com.nbst.model.RunawayProcessingExperience;
import com.nbst.service.IRunawayProcessingExperienceService;

import groovy.util.logging.Slf4j;

@Controller
@RequestMapping("/runawayProcessingExperience")
@Slf4j
@CrossOrigin
public class RunawayProcessingExperienceController {
	@Autowired
	private IRunawayProcessingExperienceService experienceService;
	/**
	 * 新增一条历史经验
	 * @param reason
	 * @param step
	 * @return
	 */
	@RequestMapping(value = "/add.action", method = RequestMethod.POST)
	@ResponseBody
	public Object add(RunawayProcessingExperience rpe) {
		return AppUtil.conversionJsonp(experienceService.add(rpe));
	}
	
	/**
	 * 修改或删除一条历史经验
	 * @param experienceId
	 * @return
	 */
	@RequestMapping(value = "/update.action", method = RequestMethod.POST)
	@ResponseBody
	public Object update(RunawayProcessingExperience rpe,Integer state) {
		return AppUtil.conversionJsonp(experienceService.update(rpe,state));
	}
	/**
	 * 查询并返回历史经验，返回结果最多为limit条，从满足条件的第offset条开始返回
	 * @return
	 */
	@RequestMapping(value = "/search.action", method = RequestMethod.POST)
	@ResponseBody
	public Object search(Integer limit,Integer offset) {
		return AppUtil.conversionJsonp(experienceService.search(limit,offset));
	}
}
