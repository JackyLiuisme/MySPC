package com.nbst.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nbst.comnutil.AppUtil;
import com.nbst.service.IControlChartCalculationInformationService;

import groovy.util.logging.Slf4j;

@Controller
@RequestMapping("/calculationinformation")
@Slf4j
@CrossOrigin

public class ControlChartCalculationInformationConrtoller {
	@Autowired
	private IControlChartCalculationInformationService controlChartCalculationInformationService;

	/**
	 * 控制图计算信息接口实现
	 * 
	 * @param controlChartInfomation 控制字符信息
	 * @author lijiajun
	 * @return
	 */

	public Object addControlChartData(Integer jcsjControlChartId,
			String kztxxSpecificationUpperLimit, Integer kzttjSampleSize, String kztxxTargetValue,
			Integer kztxxSampleCapacity, Integer kztxxDecimalNumber,double SeiGaMa) {
		return AppUtil.conversionJsonp(
				controlChartCalculationInformationService.controlChartCalculationInformation(jcsjControlChartId, kztxxSpecificationUpperLimit, kzttjSampleSize, kztxxTargetValue, kztxxSampleCapacity, kztxxDecimalNumber, SeiGaMa));
	}
}
