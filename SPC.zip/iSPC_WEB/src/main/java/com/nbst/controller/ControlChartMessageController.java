package com.nbst.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nbst.comnutil.AppUtil;
import com.nbst.model.ControlChartInfomation;
import com.nbst.service.IControlChartMessageService;

@Controller
@CrossOrigin
@RequestMapping("/controlChartMessage")
public class ControlChartMessageController {

	@Autowired
	private IControlChartMessageService controlChartMessageService;

	/**
	 * 查询层次类型名称
	 * 
	 * @author huangh
	 * @return Object
	 */
	@RequestMapping(value = "/searchTypeLevelName.action", method = RequestMethod.GET)
	@ResponseBody
	public Object getTypeLevelName() {
		return AppUtil.conversionJsonp(controlChartMessageService.getTypeLevelName());
	}

	/**
	 * 控制图信息查询
	 * 
	 * @param groupId
	 *            分组id
	 * @param limit
	 * @param offset
	 * @author huangh
	 * @return Object
	 */
	@RequestMapping(value = "/search.action", method = RequestMethod.GET)
	@ResponseBody
	public Object getControlChartMessage(Integer groupId, Integer limit, Integer offset) {
		return AppUtil.conversionJsonp(controlChartMessageService.getControlChartMessage(groupId, limit, offset));
	}

	/**
	 * 控制图信息设置查询
	 * 
	 * @param id
	 *            控制图信息id
	 * @author huangh
	 * @return Object
	 */
	@RequestMapping(value = "/searchSet.action", method = RequestMethod.GET)
	@ResponseBody
	public Object getControlChartSet(Integer id) {
		return AppUtil.conversionJsonp(controlChartMessageService.getControlChartSet(id));
	}

	/**
	 * 控制图信息新增
	 * 
	 * @param ControlChartInfomation
	 *            新增时需保存的数据
	 * @author huangh
	 * @return Object
	 */
	@RequestMapping(value = "/add.action", method = RequestMethod.POST)
	@ResponseBody
	public Object addControlChartMessage(ControlChartInfomation controlChartInfomation) {
		return AppUtil.conversionJsonp(controlChartMessageService.addControlChartMessage(controlChartInfomation));
	}

	/**
	 * 控制图信息修改/删除
	 * 
	 * @param ControlChartInfomation
	 *            修改时传所有数据，删除只传id
	 * @param state
	 *            状态 0：修改；1：删除
	 * @author huangh
	 * @return Object
	 */
	@RequestMapping(value = "/update.action", method = RequestMethod.POST)
	@ResponseBody
	public Object updateControlChartMessage(ControlChartInfomation controlChartInfomation, Integer state) {
		return AppUtil
				.conversionJsonp(controlChartMessageService.updateControlChartMessage(controlChartInfomation, state));
	}

}
