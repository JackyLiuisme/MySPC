package com.nbst.service.Impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nbst.dao.mapper.ispcweb.DetectionDataMapper;
import com.nbst.model.DetectionData;
import com.nbst.service.IControlChartCalculationInformationService;

import groovy.util.logging.Slf4j;

@Slf4j
@Service
@Transactional
public class ControlChartCalculationInformationServiceImpl implements IControlChartCalculationInformationService {
	@Autowired
	private DetectionDataMapper detectionDataMapper;

	/**
	 * 计算控制图统计信息
	 * @param jcsjControlChartId
	 * @param kztxxSpecificationUpperLimit
	 * kzttjSampleSize
	 * kztxxTargetValue
	 * @author lijiajun
	 *
	 */
	@Override
	public Map<String, Object> controlChartCalculationInformation(Integer jcsjControlChartId,
			String kztxxSpecificationUpperLimit, Integer kzttjSampleSize, String kztxxTargetValue,
			Integer kztxxSampleCapacity, Integer kztxxDecimalNumber, double SeiGaMa) {
		Map<String, Object> conditionmap1 = new HashMap<>();
		Map<String, Object> returnmap = new HashMap<>();
		// 根据传入的控制图id找到相应的控制图
		conditionmap1.put("jcsjControlChartId", jcsjControlChartId);
		List<DetectionData> list2 = detectionDataMapper.findByCondition(conditionmap1);
		List<Double> list = new ArrayList<>();
		List<Double> list1 = new ArrayList<>();
		// 计数组数Group
		Integer Group = 0;
		for (DetectionData detectionData : list2) {
			String[] Array = detectionData.getJcsjControlChartData().split(",");
			// 将平均值存入list
			list.add(Double.valueOf(Array[0]));
			// 将极差值存入list1
			list1.add(Double.valueOf(Array[1]));
			Group++;
		}
		//返回总数Total
		double Total = kzttjSampleSize * Group;
		returnmap.put("Total", Total);
		// 求出分布中心groupMean
		double sum1 = 0;
		double[] Mean = new double[100];
		int i = 0;
		for (double num : list) {
			Mean[i] = num;
			sum1 = num + sum1;
			i++;
		}
		double groupMean = sum1 / kzttjSampleSize;
		//求出极差平均值DistMean
		double sum2 = 0;
		i = 0;
		double[] R = new double[100];
		for (double num : list1) {
			R[i] = num;
			sum2 = num + sum2;
			i++;
		}
		double DistMean = sum2 / kzttjSampleSize;
		//返回SA
		return null;
	}

}
