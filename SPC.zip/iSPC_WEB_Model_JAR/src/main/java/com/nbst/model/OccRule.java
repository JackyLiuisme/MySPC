package com.nbst.model;

public class OccRule {
	private Integer pygzRuleId;
	// 规则描述
	private String pygzRuleDescribe;
	// 规则变量
	private String pygzVariate;
	// 规则编号
	private String pygzRuleExtend1;
	// 规则类型
	private String pygzRuleExtend2;

	private String pygzRuleExtend3;

	private String pygzRuleExtend4;

	private String pygzRuleExtend5;

	public Integer getPygzRuleId() {
		return pygzRuleId;
	}

	public void setPygzRuleId(Integer pygzRuleId) {
		this.pygzRuleId = pygzRuleId;
	}

	public String getPygzRuleDescribe() {
		return pygzRuleDescribe;
	}

	public void setPygzRuleDescribe(String pygzRuleDescribe) {
		this.pygzRuleDescribe = pygzRuleDescribe == null ? null : pygzRuleDescribe.trim();
	}

	public String getPygzVariate() {
		return pygzVariate;
	}

	public void setPygzVariate(String pygzVariate) {
		this.pygzVariate = pygzVariate == null ? null : pygzVariate.trim();
	}

	public String getPygzRuleExtend1() {
		return pygzRuleExtend1;
	}

	public void setPygzRuleExtend1(String pygzRuleExtend1) {
		this.pygzRuleExtend1 = pygzRuleExtend1 == null ? null : pygzRuleExtend1.trim();
	}

	public String getPygzRuleExtend2() {
		return pygzRuleExtend2;
	}

	public void setPygzRuleExtend2(String pygzRuleExtend2) {
		this.pygzRuleExtend2 = pygzRuleExtend2 == null ? null : pygzRuleExtend2.trim();
	}

	public String getPygzRuleExtend3() {
		return pygzRuleExtend3;
	}

	public void setPygzRuleExtend3(String pygzRuleExtend3) {
		this.pygzRuleExtend3 = pygzRuleExtend3 == null ? null : pygzRuleExtend3.trim();
	}

	public String getPygzRuleExtend4() {
		return pygzRuleExtend4;
	}

	public void setPygzRuleExtend4(String pygzRuleExtend4) {
		this.pygzRuleExtend4 = pygzRuleExtend4 == null ? null : pygzRuleExtend4.trim();
	}

	public String getPygzRuleExtend5() {
		return pygzRuleExtend5;
	}

	public void setPygzRuleExtend5(String pygzRuleExtend5) {
		this.pygzRuleExtend5 = pygzRuleExtend5 == null ? null : pygzRuleExtend5.trim();
	}

	@Override
	public String toString() {
		return "OccRule [pygzRuleId=" + pygzRuleId + ", pygzRuleDescribe=" + pygzRuleDescribe + ", pygzVariate="
				+ pygzVariate + ", pygzRuleExtend1=" + pygzRuleExtend1 + ", pygzRuleExtend2=" + pygzRuleExtend2
				+ ", pygzRuleExtend3=" + pygzRuleExtend3 + ", pygzRuleExtend4=" + pygzRuleExtend4 + ", pygzRuleExtend5="
				+ pygzRuleExtend5 + "]";
	}

}