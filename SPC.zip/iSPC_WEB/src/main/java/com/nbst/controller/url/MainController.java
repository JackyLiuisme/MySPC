package com.nbst.controller.url;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class MainController {

	@RequestMapping(value = "/")
	public String index() {
		return "/index";
	}
	@RequestMapping(value = "/login.action")
	public String login() {
		return "/login";
	}
	@RequestMapping(value = "/home.action")
	public String home() {
		return "home/home";
	}
	@RequestMapping(value = "/test.action")
	public String test() {
		return "basis/test";
	}
	@RequestMapping(value = "/HierarchicalType.action")
	public String HierarchicalType() {
		return "basis/HierarchicalType";
	}
	//检测项
	@RequestMapping(value = "/DetectionItem.action")
	public String DetectionItem() {
		return "basis/DetectionItem";
	}
	@RequestMapping(value = "/MainPage.action")
	public String MainPage() {
		return "controlChart/MainPage";
	}
	@RequestMapping(value = "/ProcessCapability.action")
	public String ProcessCapability() {
		return "reportForms/ProcessCapability";
	}
	@RequestMapping(value = "/GoodYield.action")
	public String GoodYield() {
		return "reportForms/GoodYield";
	}
	//用户管理
	@RequestMapping(value = "/UserManagement.action")
	public String UserManagement() {
		return "basis/UserManagement";
	}
	//设备检测管理
	@RequestMapping(value = "/EquipmentDetection.action")
	public String EquipmentDetection() {
		return "basis/EquipmentDetection";
	}
}
