package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.TypeLevelThree;

public interface TypeLevelThreeMapper {
	int delete(Integer cclxthreeId);

	int insert(TypeLevelThree record);

	TypeLevelThree findById(Integer cclxthreeId);

	int update(TypeLevelThree record);

	List<TypeLevelThree> findByCondition(Map<String, Object> map);

	int count(Map<String, Object> map);
}