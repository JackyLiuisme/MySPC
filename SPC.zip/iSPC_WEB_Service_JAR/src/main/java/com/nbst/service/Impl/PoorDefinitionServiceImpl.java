package com.nbst.service.Impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nbst.dao.mapper.ispcweb.PoorDefinitionMapper;
import com.nbst.model.PoorDefinition;
import com.nbst.service.IPoorDefinitionService;

import groovy.util.logging.Slf4j;

/**
 * @author hjx
 * @注释  实现不良定义的增删查改的服务层实现类
 * @date 2018年10月19日
 */
@Slf4j
@Service
@Transactional
public class PoorDefinitionServiceImpl implements IPoorDefinitionService{
	@Autowired
	private PoorDefinitionMapper poorDefMapper;
	
	private final static String EXIST_STATE = "1";	//记录存在
	private final static String DELETE_STATE = "0";	//记录删除
	
	@Override
	public Map<String, Object> addPoorDefinition(PoorDefinition pd) {
		String code = pd.getBldyCode();
		Map<String,Object> resultMap = new HashMap<>();
		Map<String,Object> conditionmap = new HashMap<>();
		conditionmap.put("bldyCode", code);
		conditionmap.put("bldyExtend1", EXIST_STATE);
		List<PoorDefinition> list = poorDefMapper.findByCondition(conditionmap);
		if(!list.isEmpty()) {
			resultMap.put("message", "代码重复，新增失败");
			resultMap.put("code","9999");
			return resultMap;
		}
		//代号无重复，新增不良定义
		pd.setBldyExtend1(EXIST_STATE);//设置该记录状态为正常
		int flag = poorDefMapper.insert(pd);
		if(flag!=0) {
			resultMap.put("message", "新增成功");
			resultMap.put("code", "0000");
			resultMap.put("id",pd.getBldyId());
		}
		else {
			resultMap.put("message", "新增失败");
			resultMap.put("code", "9998");
		}
		
		return resultMap;
	}

	/**
	 * 对不良定义进行修改或删除
	 * @param pd
	 * @param state,state为1时是修改，state为0时是删除
	 * @return
	 */
	@Override
	public Map<String, Object> updatePoorDefinition(PoorDefinition pd,Integer state) {
		Map<String,Object> resultMap = new HashMap<>();
		Map<String,Object> conditionmap = new HashMap<>();
		//state为1时是进行修改
		if(state != 0) {
			//如果修改的记录代号与其他记录代号重复，则修改失败
			conditionmap.put("bldyCode", pd.getBldyCode());
			conditionmap.put("bldyExtend1", EXIST_STATE);
			List<PoorDefinition> list = poorDefMapper.findByCondition(conditionmap);
			for(PoorDefinition pDef:list) {
				if(!pDef.getBldyId().equals(pd.getBldyId())) {
					resultMap.put("message", "代号不能重复，修改失败");
					resultMap.put("code", "9997");
					return resultMap;
				}
			}
			//没有代号重复的情况
			PoorDefinition targetPd = poorDefMapper.findById(pd.getBldyId());
			if(targetPd == null || targetPd.getBldyExtend1().equals(DELETE_STATE)) {
				//如果找不到对应id的记录或者找到但其状态不是正常，则无法修改
				resultMap.put("message", "找不到对应不良定义，修改失败");
				resultMap.put("code", "9998");
			}
			else {
				//能够找到这样的记录，则用pd去更新
				pd.setBldyExtend1(EXIST_STATE);
				int flag = poorDefMapper.update(pd);
				if(flag!=0) {
					resultMap.put("message", "修改成功");
					resultMap.put("code", "0000");
				} else {
					resultMap.put("message", "修改失败");
					resultMap.put("code", "9999");
				}
			}
			return resultMap;
		}
		else {
			PoorDefinition targetPd = poorDefMapper.findById(pd.getBldyId());
			if(targetPd == null || targetPd.getBldyExtend1().equals(DELETE_STATE)) {
				resultMap.put("message", "没有对应不良定义，删除失败");
				resultMap.put("code", "9999");
			}
			else {
				//能够找到这样的记录，将bldyExtend1设为2（已删除）
				targetPd.setBldyExtend1(DELETE_STATE);
				int flag = poorDefMapper.update(targetPd);
				if(flag!=0) {
					resultMap.put("message", "删除成功");
					resultMap.put("code", "0000");
				}
				else {
					resultMap.put("message", "删除失败");
					resultMap.put("code", "0000");
				}
			}
			
			return resultMap;
		}
	}

	@Override
	public Map<String, Object> searchPoorDefinition(Integer limit, Integer offset) {
		Map<String,Object> resultMap = new HashMap<>();
		Map<String,Object> conditionmap = new HashMap<>();
		List<Map<String,Object>> rows = new ArrayList<>();	//存储返回结果
		conditionmap.put("bldyExtend1", EXIST_STATE);
		conditionmap.put("limit", limit);
		conditionmap.put("offset", offset);
		List<PoorDefinition> list = poorDefMapper.findByCondition(conditionmap);
		int total = list.size();
		for(PoorDefinition pd:list) {
			Map<String,Object> map = new HashMap<>();
			map.put("bldyId", pd.getBldyId());
			map.put("bldyCode", pd.getBldyCode());
			map.put("bldyName", pd.getBldyName());
			map.put("bldyDecribe", pd.getBldyDecribe());
			rows.add(map);
		}
		//组装返回数据
		resultMap.put("message","查询成功");
		resultMap.put("code","0000");
		resultMap.put("total", total);
		resultMap.put("rows", rows);
		return resultMap;
	}
	
}
