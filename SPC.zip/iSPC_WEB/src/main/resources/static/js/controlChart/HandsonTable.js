function des(){
	hot.destroy();
}
/****************************************handsontable********************************************/
	//jeDate与插件冲突，请换更换日期插件
//	$("#rqxz_in").jeDate({
//		//:true,
//		format: "YYYY-MM-DD hh:mm:ss",
//		okfun:function (elem,value) {
//	    }
//	});
//		
	var hot;
	var clickNo = 0	//点击次数
	var yNo = -1 //当前点击单元格列
	var xNo = -1 //当前点击单元格行
	var clickTime = new Date().getTime(); //点击时间
	var public_rowData;  //存储行数据
	var ybArr=[ {yb:"1,2,3,4,5,6,7,8,9,10",yc:3},
				{yb:"1,2,3,4,5,6,7,8,9,10"},
				{yb:"17,2,3,4,5,6,7,8,9,10"},
				{yb:"1,2,3,4,5,6,7,8,9,10"},
				{yb:"1,2,3,4,5,6,7,8,9,10"},
				{yb:"1,2,3,4,5,6,7,8,9,10"},
				{yb:"1,2,3,4,5,6,7,8,9,10"},
				{yb:"1,2,3,4,5,6,7,8,9,10"},
				{yb:"1,2,3,4,5,6,7,8,9,10"},
				{yb:"144,2,3,4,5,6,7,8,9,10"},
				{yb:"122,2,3,4,5,6,7,8,9,10"}];//样本假数据

	//	data: 'level',//参数字段
//    type: 'numeric',//数字类型
//    numericFormat: {//数字格式化
//      pattern: '0.00'
//    }
	
	
//	  {
//		    id: 1,
//		    flag: 'EUR',
//		    currencyCode: 'EUR',
//		    currency: 'Euro',
//		    level: 0.9033,
//		    units: 'EUR / USD',
//		    asOf: '08/19/2018',
//		    onedChng: 0.0026,
//		    yc:1,
//		    xlxz:"a"
	
	/**
	 * 粘贴插件需要用的代码
	 */
	var clipboardCache = '';
	var sheetclip = new SheetClip();
	/*
	 * 根据值显示不同的单元格颜色
	 */
	var ycFormatter = function (instance, td, row, col, prop, value, cellProperties) {
		
		//循环清除td
		while (td.firstChild) {
		    td.removeChild(td.firstChild);
		}
		
		//根据值显示不同背景颜色的逻辑
		if(value==1){
			td.style.backgroundColor = 'red';	
		}else if(value==2){
			td.style.backgroundColor = 'yellow';
		}else if(value==3){
			td.style.backgroundColor = '#5cb85c';	
		}
		td.setAttribute('class','htCenter htMiddle');
		td.innerHTML=value;
	};

	/*
	 * 根据值显示不同的按钮
	 */
	var ycFormatter2 = function (instance, td, row, col, prop, value, cellProperties) {
		
		//循环清除td
		while (td.firstChild) {
		    td.removeChild(td.firstChild);
		}
		
		//根据值显示不同按钮的逻辑
		var flagElement = document.createElement('button');
		if(value==1){
			flagElement.innerHTML="失控"
			flagElement.setAttribute('class','btn btn-danger btn-xs')
			$(flagElement).click(function(){
	 			alert("我失控啦"+JSON.stringify(instance.getSourceDataAtRow(row)));//获取行数据
		 	})
		 	$(td).parent().css("background","red");
		    td.appendChild(flagElement);
		}else if(value==2){
			flagElement.innerHTML="已处理"	
			flagElement.setAttribute('class','btn btn-success btn-xs')
			$(flagElement).click(function(){
	 			alert("我已经处理啦"+JSON.stringify(instance.getSourceDataAtRow(row)));//获取行数据
		 	})
		 	$(td).parent().css("background","yellow");
		    td.appendChild(flagElement);		
		}else if(value==3){
			td.style.backgroundColor = '#5cb85c';	
			td.innerHTML="正常";
		}
		td.setAttribute('class','htCenter htMiddle');
	};

	/*
	 * 根据数据值的大小显示不同背景
	 */
	var ycFormatter3 = function (instance, td, row, col, prop, value, cellProperties) {
		
		//循环清除td
		while (td.firstChild) {
		    td.removeChild(td.firstChild);
		}
		
		//根据数据值的大小显示不同背景的逻辑
		if(value<0){
		 	td.style.backgroundColor = 'yellow';	
		}
		td.setAttribute('class','htCenter htMiddle');
		td.innerHTML=value;
	};

	
	
	//表格数据
	var dataObject = [
  {
    id: 1,
    flag: 'EUR',
    currencyCode: 'EUR',
    currency: 'Euro',
    level: 0.9033,
    units: 'EUR / USD',
    asOf: '08/19/2018',
    onedChng: 0.0026,
    yc:1,
    xlxz:"a"
  },
  {
    id: 2,
    flag: 'JPY',
    currencyCode: 'JPY',
    currency: 'Japanese Yen',
    level: 124.3870,
    units: 'JPY / USD',
    asOf: '08/19/2018',
    onedChng: 0.0001,
    yc:2
  },
  {
    id: 3,
    flag: 'GBP',
    currencyCode: 'GBP',
    currency: 'Pound Sterling',
    level: 0.6396,
    units: 'GBP / USD',
    asOf: '08/19/2018',
    onedChng: 0.00,
    yc:3,
    xlxz:"b"
  },
  {
    id: 4,
    flag: 'CHF',
    currencyCode: 'CHF',
    currency: 'Swiss Franc',
    level: 0.9775,
    units: 'CHF / USD',
    asOf: '08/19/2018',
    onedChng: 0.0008,
    yc:1
  },
  {
    id: 5,
    flag: 'CAD',
    currencyCode: 'CAD',
    currency: 'Canadian Dollar',
    level: 1.3097,
    units: 'CAD / USD',
    asOf: '08/19/2018',
    onedChng: -0.0005,
    yc:2,
    xlxz:"c"
  },
  {
    id: 6,
    flag: 'AUD',
    currencyCode: 'AUD',
    currency: 'Australian Dollar',
    level: 1.3589,
    units: 'AUD / USD',
    asOf: '08/19/2018',
    onedChng: 0.0020,
    yc:3
  },
  {
    id: 7,
    flag: 'NZD',
    currencyCode: 'NZD',
    currency: 'New Zealand Dollar',
    level: 1.5218,
    units: 'NZD / USD',
    asOf: '08/19/2018',
    onedChng: -0.0036,
    yc:1
  },
  {
    id: 8,
    flag: 'SEK',
    currencyCode: 'SEK',
    currency: 'Swedish Krona',
    level: 8.5280,
    units: 'SEK / USD',
    asOf: '08/19/2018',
    onedChng: 0.0016,
    yc:2,
    xlxz:"d"
  },
  {
    id: 9,
    flag: 'NOK',
    currencyCode: 'NOK',
    currency: 'Norwegian Krone',
    level: 8.2433,
    units: 'NOK / USD',
    asOf: '08/19/2018',
    onedChng: 0.0008,
    yc:3
  }
];

// hansontable 设置
var hotElement = document.querySelector('#hot');
var hotSettings;
function initHandsonTable(ColHeaders,headArr,newData){
	hotSettings = {
			  data: newData,
			  columns: headArr,
			  stretchH: 'none',//拉伸模式  all 均匀拉伸   、  none 不拉伸
			  width: 1286,//容器宽度
			  autoWrapRow: true,
			  height: 487,//容器高度
			//  maxRows: 22,//容器最大行数
			  manualRowResize: true,//行拉伸
			  manualColumnResize: true,//列拉伸
			  mergeCells:true,//合并单元格
			  copyPaste: true,//复制粘贴
			  rowHeaders: true,//左侧序号列
			  colHeaders: ColHeaders,//表头字段名称
			  manualRowMove: false,//行拖动
			  manualColumnMove: false,//列拖动
			  className: "htCenter htMiddle",//居中样式
			  contextMenu: [
			  'row_above', //前插入行
			  'row_below', //后插入行
			  '---------',//分隔符
			  'remove_row',//删除行
			  '---------',
			  'undo',//撤销
			  'redo',//重做
			  '---------',
			  'make_read_only',//只读
			  '---------',
			  'alignment',//排序方式
			  'mergeCells',//合并单元格
			  'copy',//复制
			  'cut',//剪切
			  {
			    key: 'paste',
			    name: '粘贴',
			    disabled: function() {
			      return clipboardCache.length === 0;
			    },
			    callback: function() {
			      var plugin = this.getPlugin('copyPaste');

			      this.listen();
			      plugin.paste(clipboardCache);
			    }
			  }
			  ],
			  filters: true,
			  dropdownMenu: true,//下拉菜单
			  afterSelectionEnd: function(x1, y1, x2, y2){// 点击显示选中事件
//						console.log("xx",[x1,y1,x2,y2]);
//						selection = [x1,y1,x2,y2];
					//双击事件
					if(y1==4){
						if(x1!=xNo || clickNo==0){
							clickNo=1;
							xNo=x1;
							yNo=y1;
							clickTime = new Date().getTime();
						}else{
							if(clickNo==1 ){
								var a =  new Date().getTime();
								if(a - clickTime <= 1500){
									clickNo=0;
									$("#myModal").modal("show");
									public_rowData=hot.getSourceDataAtRow(x1);
									
									$("#save_rqxz").unbind().click(function(){
//										public_rowData.rqxz = new Date().getTime();
										public_rowData.rqxz = $("#rqxz_in").val();
										hot.render();
										$("#myModal").modal("hide");
									})
								}
								xNo=x1;
								yNo=y1;
							}
						}
					}
//					selection = [x1,y1,x2,y2];
//				var cellNo = -1 //当前点击单元格列
//				var rowNo = -1 //当前点击单元格行
//				var clickTime = new Date().getTime(); //点击时间
			  },
			  afterCopy: function(changes) {
			  	 clipboardCache = sheetclip.stringify(changes);
			  },
			  afterCut: function(changes) {
			  	 clipboardCache = sheetclip.stringify(changes);
			  },
			  afterPaste: function(changes) {
			    // we want to be sure that our cache is up to date, even if someone pastes data from another source than our tables.
			    clipboardCache = sheetclip.stringify(changes);
			  },
			  afterChange: function(changes, source){
			  	//单元格修改后事件
			    if(source !== 'loadData'){
			    	if(changes[0][1]== 'szyz'){
			    		if(isNaN(changes[0][3])){
			    			alert("输入非数字");
			    			var rowData=hot.getSourceDataAtRow(changes[0][0]);
			    			if(changes[0][2]==null){
			    				rowData.szyz="";
			    			}else{
			    				rowData.szyz=changes[0][2];
			    			}
			    			hot.render();
			    		}
			    	}
			    }
			  }
			};	
}



function searchHandsonTableBt(row){	
	var ColHeaders=['抽检时间','录入时间','状态',"平均值","极差值","标准差","最大值","最小值","录入用户"];	
    var headArr=[{
	    data: 'level',//参数字段
	    type: 'numeric',//数字类型
	    numericFormat: {//数字格式化
	      pattern: '0.00'
	    }
	},
	{
        data: 'level',//参数字段
        type: 'numeric',//数字类型
        numericFormat: {//数字格式化
          pattern: '0.00'
        }
    },
    {
        data: 'yc',
        readOnly: true,
        type: 'text',
  	  renderer: ycFormatter2
    },
    {
        data: 'level',//参数字段
        type: 'numeric',//数字类型
        numericFormat: {//数字格式化
          pattern: '0.00'
        }
    },
    {
        data: 'level',//参数字段
        type: 'numeric',//数字类型
        numericFormat: {//数字格式化
          pattern: '0.00'
        }
    },
    {
        data: 'level',//参数字段
        type: 'numeric',//数字类型
        numericFormat: {//数字格式化
          pattern: '0.00'
        }
    },
    {
        data: 'level',//参数字段
        type: 'numeric',//数字类型
        numericFormat: {//数字格式化
          pattern: '0.00'
        }
    },
    {
        data: 'level',//参数字段
        type: 'numeric',//数字类型
        numericFormat: {//数字格式化
          pattern: '0.00'
        }
    },
    {
        data: 'level',//参数字段
        type: 'numeric',//数字类型
        numericFormat: {//数字格式化
          pattern: '0.00'
        }
    }	            
  ];

	console.log(row.cclx);
	for(var i=0;i<9;i++){
		console.log($("#cc"+(i+1)).html());
			var headSjd={
					data:$("#cc"+(i+1)).html(),
					type: 'numeric',//数字类型
				    numericFormat: {//数字格式化
				      pattern: '0.00'
				    }			
			}
		
		
//		console.log(headSjd);
			
			headArr.splice(2+i,0,headSjd);
			//		$("#level"+(i+1)+" option:selected").text();
	}
//数据放入再处理
	for(var i=0;i<row.ybrl;i++){
		var headYb={
				data:'yb' + (i+1),
				type:'numeric',
				numericFormat: {//数字格式化
			      pattern: '0.00'
			    },
			};
		headArr.splice(2+i,0,headYb);
		ColHeaders.splice(2+i,0,headYb.data);
	}	

	initHandsonTable(ColHeaders,headArr,ybArr);
	showHandsonTable();
}

function showHandsonTable(){
	//生成handsontable实例
	hot = new Handsontable(hotElement, hotSettings);
	$(".cornerHeader").html('序号');
}

for(var i=0;i<ybArr.length;i++){//将样本数据数组解析成JSON格式数组
	var arr=ybArr[i].yb.split(",");//用逗号分割
	var ybJSON={};
	for(var j=0 ; j<arr.length ; j++){
		var str = j+1;
		var msg;
		msg = "yb"+str;
		var strJSON="ybJSON."+msg+"="+arr[j];
		eval(strJSON);
	}	
	ybArr[i]=ybJSON;
}



