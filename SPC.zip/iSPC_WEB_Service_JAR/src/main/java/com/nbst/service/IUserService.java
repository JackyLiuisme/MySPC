package com.nbst.service;

import com.nbst.model.User;

/**
 * @author yangl
 *
 */
public interface IUserService {
		// 用户新增
		Object addUser(User user);

		// 用户修改/删除
		Object alterUser(User user,Integer state);

		// 用户查询
		Object searchUser(Integer limit, Integer offset);

}