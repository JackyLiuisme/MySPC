package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.CpkAnalyzeData;

public interface CpkAnalyzeDataMapper {
    int delete(Integer cpkfxsjCpkAnalyzeDiagramId);

    int insert(CpkAnalyzeData record);

    CpkAnalyzeData findById(Integer cpkfxsjCpkAnalyzeDiagramId);

    int update(CpkAnalyzeData record);

    List<CpkAnalyzeData> findByCondition(Map<String,Object> map);
    
    int count(Map<String,Object> map);
}