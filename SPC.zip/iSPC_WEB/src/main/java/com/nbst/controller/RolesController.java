package com.nbst.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nbst.comnutil.AppUtil;
import com.nbst.model.Roles;
import com.nbst.model.User;
import com.nbst.service.IRolesService;

import groovy.util.logging.Slf4j;

/**
 * @author yangl
 *
 */
@Controller
@RequestMapping("/roles")
@Slf4j
@CrossOrigin
public class RolesController {
	@Autowired
	IRolesService service;

	/**
	 * 角色新增
	 * 
	 * @param role
	 * @return
	 */
	@RequestMapping(value = "/add.action", method = RequestMethod.POST)
	@ResponseBody
	public Object addUser(Roles role) {
		return AppUtil.conversionJsonp(service.add(role));
	}

	/**
	 * 角色修改/删除
	 * 
	 * @param role
	 * @param state
	 * @return
	 */
	@RequestMapping(value = "/update.action", method = RequestMethod.POST)
	@ResponseBody
	public Object update(Roles role, Integer state) {
		return AppUtil.conversionJsonp(service.alter(role, state));
	}

	/**
	 * 角色查询
	 * 
	 * @param limit
	 * @param offset
	 * @return
	 */
	@RequestMapping(value = "/search.action", method = RequestMethod.GET)
	@ResponseBody
	public Object search(Integer limit, Integer offset) {
		return AppUtil.conversionJsonp(service.search(limit, offset));
	}
}
