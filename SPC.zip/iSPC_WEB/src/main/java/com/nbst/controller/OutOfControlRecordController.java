package com.nbst.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nbst.comnutil.AppUtil;
import com.nbst.model.OutOfControlRecord;
import com.nbst.service.IOutOfControlRecordService;

import groovy.util.logging.Slf4j;

/**
 * @author huangjx
 *
 */
@Controller
@RequestMapping("/outOfControlRecord")
@Slf4j
@CrossOrigin
public class OutOfControlRecordController {
	@Autowired
	private IOutOfControlRecordService outOfControlRecordService;

	/**
	 * 
	 * @param controlChartId
	 * @param detectionDataId
	 * @param reason
	 * @param step
	 * @param managerPersonId
	 * @param state
	 * @return
	 */
	@RequestMapping(value = "/process.action", method = RequestMethod.POST)
	@ResponseBody
	public Object process(Integer controlChartId,Integer detectionDataId,String reason,String step,Integer managerPersonId,Integer state) {
		return AppUtil.conversionJsonp(outOfControlRecordService.alterOutOfControl(controlChartId, detectionDataId, reason, step, managerPersonId, state));
	}
	
	/**
	 * @param detectionDataId
	 * @return
	 */
	@RequestMapping(value = "/search.action", method = RequestMethod.GET)
	@ResponseBody
	public Object search(Integer detectionDataId) {
		return AppUtil.conversionJsonp(outOfControlRecordService.searchOutOfControl(detectionDataId));
	}
	
	/**
	 * @param detectionDataId
	 * @param auditResult
	 * @param auditDiscription
	 * @param auditorId
	 * @return
	 */
	public Object audit(Integer detectionDataId,Integer auditResult,String auditDiscription,Integer auditorId) {
		return AppUtil.conversionJsonp(outOfControlRecordService.updateAudit(detectionDataId, auditResult, auditDiscription, auditorId));
	}
	
	/**
	 * @param detectionDataId
	 * @param auditResult
	 * @param auditDiscription
	 * @param auditorId
	 * @return
	 */
	public Object searchList(Integer state,Integer controlChartId) {
		return AppUtil.conversionJsonp(outOfControlRecordService.searchList(state, controlChartId));
	}
}
