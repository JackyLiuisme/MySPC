package com.nbst.service;

import com.nbst.model.DetectionItem;

/**
 * @author yangl
 *
 */
public interface IDetectionItemService {
	// 检测项新增
	Object addDetectionItem(DetectionItem detectionItem);

	// 检测项修改/删除
	Object alterDetectionItem(DetectionItem detectionItem, Integer state);

	// 检测项查询
	Object searchDetectionItem(Integer limit, Integer offset);

}
