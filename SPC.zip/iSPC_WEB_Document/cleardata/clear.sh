source ./config

echo -e "deviceCode="${deviceCode}
echo -e "clearDate="${clearDate}
echo -e "mysqlHost="${mysqlHost}
echo -e "mysqlDatabase="${mysqlDatabase}
echo -e "mysqlUsername="${mysqlUsername}
echo -e "mysqlPassword="${mysqlPassword}
echo -e "mongodbHost="${mongodbHost}
echo -e "mongodbDatabase="${mongodbDatabase}
echo -e "mongodbUsername="${mongodbUsername}
echo -e "mongodbPassword="${mongodbPassword}
echo -e "mongodbAuthenticationDatabase="${mongodbAuthenticationDatabase}
echo -e "read config finished\n"

clearDate=`date -d $clearDate +%s`
zero=000
clearDate=$clearDate$zero
echo -e "deviceCode="$deviceCode" clearDate="$clearDate

echo -e "creating clear.sql..."
sed "s/deviceCode/${deviceCode}/g" template.sql > clear.sql
sed -i "s/clearDate/${clearDate}/g" clear.sql
echo -e "created clear.sql"
mysql -h ${mysqlHost} -u ${mysqlUsername} -p${mysqlPassword} -D${mysqlDatabase} <clear.sql
echo -e "clear mysql data finished\n"

echo -e "creating clear.js..."
sed "s/deviceCode/${deviceCode}/g" template.js > clear.js
sed -i "s/clearDate/${clearDate}/g" clear.js
echo -e "created clear.js"
mongo -u ${mongodbUsername} -p ${mongodbPassword} --authenticationDatabase ${mongodbAuthenticationDatabase} --host ${mongodbHost} --port 27017 ${mongodbDatabase} clear.js
echo -e "clear mongodb data finished\n"