package com.nbst.service;

import java.util.Map;

import com.nbst.model.ControlChartInfomation;

public interface IControlChartMessageService {

	/**
	 * 查询层次类型名称
	 * 
	 * @author huangh
	 * @return Map<String, Object>
	 */
	Map<String, Object> getTypeLevelName();

	/**
	 * 控制图信息查询
	 * 
	 * @param groupId
	 *            分组id
	 * @param limit
	 * @param offset
	 * @author huangh
	 * @return Map<String, Object>
	 */
	Map<String, Object> getControlChartMessage(Integer groupId, Integer limit, Integer offset);

	/**
	 * 控制图信息设置查询
	 * 
	 * @param id
	 *            控制图信息id
	 * @author huangh
	 * @return Map<String, Object>
	 */
	Map<String, Object> getControlChartSet(Integer id);

	/**
	 * 控制图信息新增
	 * 
	 * @param ControlChartInfomation
	 *            新增时需保存的数据
	 * @author huangh
	 * @return Map<String, Object>
	 */
	Map<String, Object> addControlChartMessage(ControlChartInfomation controlChartInfomation);

	/**
	 * 控制图信息修改/删除
	 * 
	 * @param ControlChartInfomation
	 *            修改时传需要修改的数据，删除只传id
	 * @param state
	 *            状态 0：修改；1：删除
	 * @author huangh
	 * @return Map<String, Object>
	 */
	Map<String, Object> updateControlChartMessage(ControlChartInfomation controlChartInfomation, Integer state);
}
