package com.nbst.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nbst.comnutil.AppUtil;
import com.nbst.model.DetectionDevice;
import com.nbst.service.IDetectionDeviceService;

import groovy.util.logging.Slf4j;

/**
 * @author yangl
 *
 */
@Controller
@RequestMapping("/DetectionDevice")
@Slf4j
@CrossOrigin
public class DetectionDeviceController {
	@Autowired
	private IDetectionDeviceService detectionDeviceService;

	/**
	 * 检测设备新增
	 * 
	 * @param detectionDevice
	 * @return
	 */
	@RequestMapping(value = "/add.action", method = RequestMethod.POST)
	@ResponseBody
	public Object addDetectionDevice(DetectionDevice detectionDevice) {
		return AppUtil.conversionJsonp(detectionDeviceService.addDetectionDevice(detectionDevice));
	}

	/**
	 * 检测设备修改/删除
	 * 
	 * @param detectionDevice
	 * @param state
	 * @return
	 */
	@RequestMapping(value = "/update.action", method = RequestMethod.POST)
	@ResponseBody
	public Object update(DetectionDevice detectionDevice, Integer state) {
		return AppUtil.conversionJsonp(detectionDeviceService.alterDetectionDevice(detectionDevice, state));
	}

	/**
	 * 检测设备查询
	 * 
	 * @param limit
	 * @param offset
	 * @return
	 */
	@RequestMapping(value = "/search.action", method = RequestMethod.GET)
	@ResponseBody
	public Object search(Integer limit, Integer offset) {
		return AppUtil.conversionJsonp(detectionDeviceService.searchDetectionDevice(limit, offset));
	}
}
