var flag1 = 0;

/*
 * @Description: 预加载
 * @param :
 */
$(function(){
	fnResize();
	fnTabButton();
	fnShowImage();
	
	setTimeout(function() {//延迟加载
		$("#tab1").removeClass('hd').addClass('sh');
	}, 150);
});

/*
 * @Description: 浏览器窗口大小改变后：
 * 				 class为container-fluid，row，divClassLeft，divClassRight的高度随之改变，
 * 				 divClassLeft的最大高度和最小高度随之改变
 * @param :
 */
function fnResize() {
	var height = $(window).height();//获取浏览器窗口大小
	document.getElementsByClassName("container-fluid")[0].style.height = height +"px";
	document.getElementsByClassName("row")[0].style.height = height +"px";
	document.getElementsByClassName("divClassLeft")[0].style.height = (height - 16) +"px";
	document.getElementsByClassName("divClassRight")[0].style.height = (height - 16) +"px";
	document.getElementsByClassName("divClassLeft")[0].style.maxHeight = (height - 16) +"px";
	document.getElementsByClassName("divClassLeft")[0].style.minHeight = (height - 16) +"px";
}

/*
 * @Description: 点击左边a标签
 * @param :
 */
function fnTabButton() {
	$(".divClassLeft a").click(function() {
		if (flag1 == 0) {
			flag1 == 1;
			$(this).addClass('activeA').siblings().removeClass('activeA');
			var flag = $(this).attr('pk');
			$("#tab" + flag).removeClass('hd').addClass('sh').siblings().removeClass('sh').addClass('hd');
			flag1 = 0;
		} else {
			return false;
		}
	});
}

/*
 * @Description: 图片显示
 * @param :
 */
function fnShowImage() {
	$(".divClassRight img").click(function() {
		$("#showImage").attr({ "src" : $(this).attr('src')});
		$("#alterModal2").modal('show');
	});
}

/*
 * @Description: 浏览器窗口大小自适应
 * @param :
 */
$(window).resize(function() {
	window.setTimeout(function() {
		fnResize();
	}, 200);
});