package com.nbst.enums;

import lombok.Getter;

/**
 * @author huangh
 *
 */
@Getter
public enum HeaderEnum {

    DEVICE_TYPE_BIG_CLASS(0, "设备大类"),
    DEVICE_TYPE_SHOW(1, "普通设备，会显示"),
    DEVICE_TYPE_NOT_SHOW(2, "特殊设备，不会显示");
    
    private Integer code;
    private String desc;
    
    HeaderEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }
}
