package com.nbst.model;

public class ControlChartStatistics {
	private Integer kzttjId;
	// 所属控制图信息id
	private Integer kzttjControlChartId;
	// Total
	private String kzttjTotal;
	// SampleSize
	private String kzttjSampleSize;
	// Group
	private String kzttjGroup;
	// Max
	private String kzttjMax;
	// Min
	private String kzttjMin;
	// Mean
	private String kzttjMean;
	// Dev
	private String kzttjDev;
	// CPK
	private String kzttjCpk;
	// PPK
	private String kzttjPpk;
	// Ca
	private String kzttjCa;
	// Cp
	private String kzttjCp;
	// Pp
	private String kzttjPp;

	private String kzttjExtend1;

	private String kzttjExtend2;

	private String kzttjExtend3;

	private String kzttjExtend4;

	private String kzttjExtend5;

	public Integer getKzttjId() {
		return kzttjId;
	}

	public void setKzttjId(Integer kzttjId) {
		this.kzttjId = kzttjId;
	}

	public Integer getKzttjControlChartId() {
		return kzttjControlChartId;
	}

	public void setKzttjControlChartId(Integer kzttjControlChartId) {
		this.kzttjControlChartId = kzttjControlChartId;
	}

	public String getKzttjTotal() {
		return kzttjTotal;
	}

	public void setKzttjTotal(String kzttjTotal) {
		this.kzttjTotal = kzttjTotal == null ? null : kzttjTotal.trim();
	}

	public String getKzttjSampleSize() {
		return kzttjSampleSize;
	}

	public void setKzttjSampleSize(String kzttjSampleSize) {
		this.kzttjSampleSize = kzttjSampleSize == null ? null : kzttjSampleSize.trim();
	}

	public String getKzttjGroup() {
		return kzttjGroup;
	}

	public void setKzttjGroup(String kzttjGroup) {
		this.kzttjGroup = kzttjGroup == null ? null : kzttjGroup.trim();
	}

	public String getKzttjMax() {
		return kzttjMax;
	}

	public void setKzttjMax(String kzttjMax) {
		this.kzttjMax = kzttjMax == null ? null : kzttjMax.trim();
	}

	public String getKzttjMin() {
		return kzttjMin;
	}

	public void setKzttjMin(String kzttjMin) {
		this.kzttjMin = kzttjMin == null ? null : kzttjMin.trim();
	}

	public String getKzttjMean() {
		return kzttjMean;
	}

	public void setKzttjMean(String kzttjMean) {
		this.kzttjMean = kzttjMean == null ? null : kzttjMean.trim();
	}

	public String getKzttjDev() {
		return kzttjDev;
	}

	public void setKzttjDev(String kzttjDev) {
		this.kzttjDev = kzttjDev == null ? null : kzttjDev.trim();
	}

	public String getKzttjCpk() {
		return kzttjCpk;
	}

	public void setKzttjCpk(String kzttjCpk) {
		this.kzttjCpk = kzttjCpk == null ? null : kzttjCpk.trim();
	}

	public String getKzttjPpk() {
		return kzttjPpk;
	}

	public void setKzttjPpk(String kzttjPpk) {
		this.kzttjPpk = kzttjPpk == null ? null : kzttjPpk.trim();
	}

	public String getKzttjCa() {
		return kzttjCa;
	}

	public void setKzttjCa(String kzttjCa) {
		this.kzttjCa = kzttjCa == null ? null : kzttjCa.trim();
	}

	public String getKzttjCp() {
		return kzttjCp;
	}

	public void setKzttjCp(String kzttjCp) {
		this.kzttjCp = kzttjCp == null ? null : kzttjCp.trim();
	}

	public String getKzttjPp() {
		return kzttjPp;
	}

	public void setKzttjPp(String kzttjPp) {
		this.kzttjPp = kzttjPp == null ? null : kzttjPp.trim();
	}

	public String getKzttjExtend1() {
		return kzttjExtend1;
	}

	public void setKzttjExtend1(String kzttjExtend1) {
		this.kzttjExtend1 = kzttjExtend1 == null ? null : kzttjExtend1.trim();
	}

	public String getKzttjExtend2() {
		return kzttjExtend2;
	}

	public void setKzttjExtend2(String kzttjExtend2) {
		this.kzttjExtend2 = kzttjExtend2 == null ? null : kzttjExtend2.trim();
	}

	public String getKzttjExtend3() {
		return kzttjExtend3;
	}

	public void setKzttjExtend3(String kzttjExtend3) {
		this.kzttjExtend3 = kzttjExtend3 == null ? null : kzttjExtend3.trim();
	}

	public String getKzttjExtend4() {
		return kzttjExtend4;
	}

	public void setKzttjExtend4(String kzttjExtend4) {
		this.kzttjExtend4 = kzttjExtend4 == null ? null : kzttjExtend4.trim();
	}

	public String getKzttjExtend5() {
		return kzttjExtend5;
	}

	public void setKzttjExtend5(String kzttjExtend5) {
		this.kzttjExtend5 = kzttjExtend5 == null ? null : kzttjExtend5.trim();
	}

	@Override
	public String toString() {
		return "ControlChartStatistics [kzttjId=" + kzttjId + ", kzttjControlChartId=" + kzttjControlChartId
				+ ", kzttjTotal=" + kzttjTotal + ", kzttjSampleSize=" + kzttjSampleSize + ", kzttjGroup=" + kzttjGroup
				+ ", kzttjMax=" + kzttjMax + ", kzttjMin=" + kzttjMin + ", kzttjMean=" + kzttjMean + ", kzttjDev="
				+ kzttjDev + ", kzttjCpk=" + kzttjCpk + ", kzttjPpk=" + kzttjPpk + ", kzttjCa=" + kzttjCa + ", kzttjCp="
				+ kzttjCp + ", kzttjPp=" + kzttjPp + ", kzttjExtend1=" + kzttjExtend1 + ", kzttjExtend2=" + kzttjExtend2
				+ ", kzttjExtend3=" + kzttjExtend3 + ", kzttjExtend4=" + kzttjExtend4 + ", kzttjExtend5=" + kzttjExtend5
				+ "]";
	}
	
}