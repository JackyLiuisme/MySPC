package com.nbst.model;

public class TypeLevelSeven {
	// ID
	private Integer cclxsevenId;
	// 层次类型名称
	private String cclxsevenName;
	//状态
	private String cclxsevenExtend1;

	private String cclxsevenExtend2;

	private String cclxsevenExtend3;

	private String cclxsevenExtend4;

	private String cclxsevenExtend5;

	public Integer getCclxsevenId() {
		return cclxsevenId;
	}

	public void setCclxsevenId(Integer cclxsevenId) {
		this.cclxsevenId = cclxsevenId;
	}

	public String getCclxsevenName() {
		return cclxsevenName;
	}

	public void setCclxsevenName(String cclxsevenName) {
		this.cclxsevenName = cclxsevenName == null ? null : cclxsevenName.trim();
	}

	public String getCclxsevenExtend1() {
		return cclxsevenExtend1;
	}

	public void setCclxsevenExtend1(String cclxsevenExtend1) {
		this.cclxsevenExtend1 = cclxsevenExtend1 == null ? null : cclxsevenExtend1.trim();
	}

	public String getCclxsevenExtend2() {
		return cclxsevenExtend2;
	}

	public void setCclxsevenExtend2(String cclxsevenExtend2) {
		this.cclxsevenExtend2 = cclxsevenExtend2 == null ? null : cclxsevenExtend2.trim();
	}

	public String getCclxsevenExtend3() {
		return cclxsevenExtend3;
	}

	public void setCclxsevenExtend3(String cclxsevenExtend3) {
		this.cclxsevenExtend3 = cclxsevenExtend3 == null ? null : cclxsevenExtend3.trim();
	}

	public String getCclxsevenExtend4() {
		return cclxsevenExtend4;
	}

	public void setCclxsevenExtend4(String cclxsevenExtend4) {
		this.cclxsevenExtend4 = cclxsevenExtend4 == null ? null : cclxsevenExtend4.trim();
	}

	public String getCclxsevenExtend5() {
		return cclxsevenExtend5;
	}

	public void setCclxsevenExtend5(String cclxsevenExtend5) {
		this.cclxsevenExtend5 = cclxsevenExtend5 == null ? null : cclxsevenExtend5.trim();
	}

	@Override
	public String toString() {
		return "TypeLevelSeven [cclxsevenId=" + cclxsevenId + ", cclxsevenName=" + cclxsevenName + ", cclxsevenExtend1="
				+ cclxsevenExtend1 + ", cclxsevenExtend2=" + cclxsevenExtend2 + ", cclxsevenExtend3=" + cclxsevenExtend3
				+ ", cclxsevenExtend4=" + cclxsevenExtend4 + ", cclxsevenExtend5=" + cclxsevenExtend5 + "]";
	}
}