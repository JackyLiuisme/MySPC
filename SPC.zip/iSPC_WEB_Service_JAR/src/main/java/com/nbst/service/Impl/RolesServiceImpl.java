package com.nbst.service.Impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nbst.dao.mapper.ispcweb.RolesMapper;
import com.nbst.model.Roles;
import com.nbst.model.User;
import com.nbst.service.IRolesService;

import groovy.util.logging.Slf4j;

/**
 * @author yangl
 *
 */
@Slf4j
@Service
@Transactional
public class RolesServiceImpl implements IRolesService{
	@Autowired
	RolesMapper mapper;
	
	/**
	 * 用户管理新增，如果用户名重复则插入失败
	 * 
	 * @param role
	 * @return
	 */
	@Override
	public Object add(Roles role) {
		Map<String, Object> resultMap = new HashMap<>();
		// 判断name是否重复
		Map<String, Object> conditionMap = new HashMap<>();
		conditionMap.put("jsName", role.getJsName());
		conditionMap.put("jsState", 1);
		List<Roles> names = mapper.findByCondition(conditionMap);
		if (!names.isEmpty()) {
			resultMap.put("message", "名称重复，新增失败");
			resultMap.put("code", "9999");
			return resultMap;
		}

		// 若name无重复则插入
		int flag = mapper.insert(role);
		if (flag != 0) {
			resultMap.put("message", "新增成功");
			resultMap.put("code", "0000");
		} else {
			resultMap.put("message", "新增失败");
			resultMap.put("code", "9997");
			return resultMap;
		}

		return resultMap;
	}

	/**
	 * 角色修改/删除,state=0：删除,state=1:修改
	 * 
	 * @param role
	 * @return
	 */
	@Override
	public Object alter(Roles role, Integer state) {
		Map<String, Object> resultMap = new HashMap<>();
		// 删除
		if (state == 0) {
			Roles u=mapper.findById(role.getJsId());
			u.setJsState(2);
			int flag = mapper.update(u);
			if (flag > 0) {
				resultMap.put("message", "删除成功");
				resultMap.put("code", "0000");
			} else {
				resultMap.put("message", "删除失败");
				resultMap.put("code", "9996");
			}
			return resultMap;
		}
		// 修改
		// 判断name是否重复
		Map<String, Object> conditionMap = new HashMap<>();
		conditionMap.put("jsName", role.getJsName());
		List<Roles> names = mapper.findByCondition(conditionMap);
		for (Roles u : names) {
			if (!u.getJsId().equals(role.getJsId())) {
				resultMap.put("message", "名称重复，修改失败");
				resultMap.put("code", "9995");
				return resultMap;
			}
		}
		// name不重复则更新
		int flag = mapper.update(role);
		if (flag > 0) {
			resultMap.put("message", "修改成功");
			resultMap.put("code", "0000");
		} else {
			resultMap.put("message", "修改失败");
			resultMap.put("code", "9994");
		}
		return resultMap;
	}

	/**
	 * 角色查询
	 * 
	 * @param limit
	 * @param offset
	 * @return
	 */
	@Override
	public Object search(Integer limit, Integer offset) {
		Map<String, Object> resultMap = new HashMap<>();
		Map<String, Object> conditionMap = new HashMap<>();
		conditionMap.put("jsState", 1);
		int count = mapper.count(conditionMap);
		conditionMap.put("limit", limit);
		conditionMap.put("offset", offset);

		resultMap.put("total", count);
		resultMap.put("code", "0000");
		resultMap.put("message", "查找成功");
		resultMap.put("rows", mapper.findByCondition(conditionMap));
		return resultMap;
	}
	
}
