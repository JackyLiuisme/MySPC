/**
 * 
 */
package com.nbst.comnutil;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;

import lombok.extern.slf4j.Slf4j;

/**
 * @author hellozjf
 *
 */
@Slf4j
public class SessionUtils {

    public static Session getSession() {
        return SecurityUtils.getSubject().getSession();
    }
    
    public static Object get(Object key) {
        return getSession().getAttribute(key);
    }
    
    public static void set(Object key, Object value) {
        getSession().setAttribute(key, value);
    }
}
