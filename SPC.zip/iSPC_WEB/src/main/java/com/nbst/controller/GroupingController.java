package com.nbst.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nbst.comnutil.AppUtil;
import com.nbst.model.Grouping;
import com.nbst.service.IGroupingService;

import groovy.util.logging.Slf4j;

/**
 * @author yangl
 *
 */
@Controller
@RequestMapping("/group")
@Slf4j
@CrossOrigin
public class GroupingController {
	@Autowired
	private IGroupingService groupService;

	/**
	 * 分组新增
	 * 
	 * @param group
	 * @return
	 */
	@RequestMapping(value = "/add.action", method = RequestMethod.POST)
	@ResponseBody
	public Object addGroup(Grouping group) {
		return AppUtil.conversionJsonp(groupService.addGroup(group));
	}

	/**
	 * 分组修改/删除
	 * 
	 * @param group
	 * @param state
	 * @return
	 */
	@RequestMapping(value = "/update.action", method = RequestMethod.POST)
	@ResponseBody
	public Object update(Grouping group) {
		return AppUtil.conversionJsonp(groupService.alterGroup(group));
	}

	/**
	 * 分组查询
	 * 
	 * @param limit
	 * @param offset
	 * @return
	 */
	@RequestMapping(value = "/searchTree.action", method = RequestMethod.GET)
	@ResponseBody
	public Object search(Integer limit, Integer offset) {
		return AppUtil.conversionJsonp(groupService.searchGroup(limit, offset));
	}
}