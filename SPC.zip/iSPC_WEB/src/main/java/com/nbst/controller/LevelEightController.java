package com.nbst.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nbst.comnutil.AppUtil;
import com.nbst.service.IQueryService;

import groovy.util.logging.Slf4j;

@Controller
@RequestMapping("/batch")
@Slf4j
@CrossOrigin
public class LevelEightController {
	@Autowired
	private IQueryService queryService;

	/**
	 * 层次2增加
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	@RequestMapping(value = "/add.action", method = RequestMethod.POST)
	@ResponseBody
	public Object addLevelEightItems(String name) {
		return AppUtil.conversionJsonp(queryService.addLevelEightItems(name));
	}
	
	/**
	 * 层次2删除和修改
	 * 
	 * @param id
	 * @param state
	 * @author lijiajun
	 * @return
	 */
	
	@RequestMapping(value = "/update.action", method = RequestMethod.POST)
	@ResponseBody
	public Object updatLevelEightItems(Integer id,String name, Integer state) {
		return AppUtil.conversionJsonp(queryService.updateLevelEightItems(id,name, state));
	}
	
	/**
	 * 层次2查詢
	 * 
	 * @param limit
	 * @param offset
	 * @author lijiajun
	 * @return
	 */
	@RequestMapping(value = "/search.action", method = RequestMethod.GET)
	@ResponseBody
	public Object searchEightItems(Integer limit, Integer offset) {
		return AppUtil.conversionJsonp(queryService.searchLevelEightItems(limit, offset));
	}
	
}
