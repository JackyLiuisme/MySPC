package com.nbst.model;

public class TypeLevelFour {
	// ID
	private Integer cclxfourId;
	// 层次类型名称
	private String cclxfourName;
	// 状态
	private String cclxfourExtend1;

	private String cclxfourExtend2;

	private String cclxfourExtend3;

	private String cclxfourExtend4;

	private String cclxfourExtend5;

	public Integer getCclxfourId() {
		return cclxfourId;
	}

	public void setCclxfourId(Integer cclxfourId) {
		this.cclxfourId = cclxfourId;
	}

	public String getCclxfourName() {
		return cclxfourName;
	}

	public void setCclxfourName(String cclxfourName) {
		this.cclxfourName = cclxfourName == null ? null : cclxfourName.trim();
	}

	public String getCclxfourExtend1() {
		return cclxfourExtend1;
	}

	public void setCclxfourExtend1(String cclxfourExtend1) {
		this.cclxfourExtend1 = cclxfourExtend1 == null ? null : cclxfourExtend1.trim();
	}

	public String getCclxfourExtend2() {
		return cclxfourExtend2;
	}

	public void setCclxfourExtend2(String cclxfourExtend2) {
		this.cclxfourExtend2 = cclxfourExtend2 == null ? null : cclxfourExtend2.trim();
	}

	public String getCclxfourExtend3() {
		return cclxfourExtend3;
	}

	public void setCclxfourExtend3(String cclxfourExtend3) {
		this.cclxfourExtend3 = cclxfourExtend3 == null ? null : cclxfourExtend3.trim();
	}

	public String getCclxfourExtend4() {
		return cclxfourExtend4;
	}

	public void setCclxfourExtend4(String cclxfourExtend4) {
		this.cclxfourExtend4 = cclxfourExtend4 == null ? null : cclxfourExtend4.trim();
	}

	public String getCclxfourExtend5() {
		return cclxfourExtend5;
	}

	public void setCclxfourExtend5(String cclxfourExtend5) {
		this.cclxfourExtend5 = cclxfourExtend5 == null ? null : cclxfourExtend5.trim();
	}

	@Override
	public String toString() {
		return "TypeLevelFour [cclxfourId=" + cclxfourId + ", cclxfourName=" + cclxfourName + ", cclxfourExtend1="
				+ cclxfourExtend1 + ", cclxfourExtend2=" + cclxfourExtend2 + ", cclxfourExtend3=" + cclxfourExtend3
				+ ", cclxfourExtend4=" + cclxfourExtend4 + ", cclxfourExtend5=" + cclxfourExtend5 + "]";
	}
}