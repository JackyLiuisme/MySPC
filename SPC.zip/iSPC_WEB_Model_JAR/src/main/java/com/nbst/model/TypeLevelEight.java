package com.nbst.model;

public class TypeLevelEight {
	// ID
	private Integer cclxeightId;
	// 层次类型名称
	private String cclxeightName;
	// 状态
	private String cclxeightExtend1;

	private String cclxeightExtend2;

	private String cclxeightExtend3;

	private String cclxeightExtend4;

	private String cclxeightExtend5;

	public Integer getCclxeightId() {
		return cclxeightId;
	}

	public void setCclxeightId(Integer cclxeightId) {
		this.cclxeightId = cclxeightId;
	}

	public String getCclxeightName() {
		return cclxeightName;
	}

	public void setCclxeightName(String cclxeightName) {
		this.cclxeightName = cclxeightName == null ? null : cclxeightName.trim();
	}

	public String getCclxeightExtend1() {
		return cclxeightExtend1;
	}

	public void setCclxeightExtend1(String cclxeightExtend1) {
		this.cclxeightExtend1 = cclxeightExtend1 == null ? null : cclxeightExtend1.trim();
	}

	public String getCclxeightExtend2() {
		return cclxeightExtend2;
	}

	public void setCclxeightExtend2(String cclxeightExtend2) {
		this.cclxeightExtend2 = cclxeightExtend2 == null ? null : cclxeightExtend2.trim();
	}

	public String getCclxeightExtend3() {
		return cclxeightExtend3;
	}

	public void setCclxeightExtend3(String cclxeightExtend3) {
		this.cclxeightExtend3 = cclxeightExtend3 == null ? null : cclxeightExtend3.trim();
	}

	public String getCclxeightExtend4() {
		return cclxeightExtend4;
	}

	public void setCclxeightExtend4(String cclxeightExtend4) {
		this.cclxeightExtend4 = cclxeightExtend4 == null ? null : cclxeightExtend4.trim();
	}

	public String getCclxeightExtend5() {
		return cclxeightExtend5;
	}

	public void setCclxeightExtend5(String cclxeightExtend5) {
		this.cclxeightExtend5 = cclxeightExtend5 == null ? null : cclxeightExtend5.trim();
	}

	@Override
	public String toString() {
		return "TypeLevelEight [cclxeightId=" + cclxeightId + ", cclxeightName=" + cclxeightName + ", cclxeightExtend1="
				+ cclxeightExtend1 + ", cclxeightExtend2=" + cclxeightExtend2 + ", cclxeightExtend3=" + cclxeightExtend3
				+ ", cclxeightExtend4=" + cclxeightExtend4 + ", cclxeightExtend5=" + cclxeightExtend5 + "]";
	}
}