package com.nbst.service.Impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nbst.dao.mapper.ispcweb.OccRuleInstanceMapper;
import com.nbst.dao.mapper.ispcweb.OccRuleMapper;
import com.nbst.model.OccRule;
import com.nbst.model.OccRuleInstance;
import com.nbst.service.IOCCRuleService;

@Service
@Transactional
public class OCCRuleServiceImpl implements IOCCRuleService {

	@Autowired
	private OccRuleInstanceMapper occRuleInstanceMapper;

	@Autowired
	private OccRuleMapper occRuleMapper;

	// 操作成功编号
	private final static String successCode = "0000";
	// 修改成功
	private final static String updateSuccess = "修改成功";
	// 查询成功
	private final static String searchSuccess = "查询成功";
	
	/**
	 * 判异规则查询
	 * 
	 * @param id 控制图信息id
	 * @author huangh
	 * @return Map<String, Object>
	 */
	@Override
	public Map<String, Object> getOCCRule(Integer id) {
		Map<String, Object> result = new HashMap<>();
		Map<String, Object> param = new HashMap<>();
		Map<String, Object> map2 = new HashMap<>();
		List<Map<String, Object>> rows = new ArrayList<>();

		// 根据控制图id查询关联的判异规则的id
		List<Map<String, String>> list = occRuleInstanceMapper.findOOCRuleByControlChartId(id);
		for (Map<String, String> map : list) {
			map2 = new HashMap<>();
			map2.put("id", map.get("occRuleId"));
			map2.put("ruleCode", map.get("occRuleCode"));
			map2.put("describe", map.get("occRuleDescribe"));
			param = new HashMap<>();
			param.put("pygzslOocRuleId", map.get("occRuleId"));
			param.put("pygzslControlChartId", id);
			List<OccRuleInstance> occRuleInstances = occRuleInstanceMapper.findByCondition(param);
			for (OccRuleInstance occRuleInstance : occRuleInstances) {
				map2.put(occRuleInstance.getPygzslName(), occRuleInstance.getPygzslValue());
			}
			rows.add(map2);
		}

		result.put("success", successCode);
		result.put("message", searchSuccess);
		result.put("rows", rows);
		return result;
	}

	/**
	 * 修改判异规则
	 * 
	 * @param id 控制图信息id
	 * @param str 关联的判异规则id以及变量名和值
	 * @author huangh
	 * @return Map<String, Object>
	 */
	@Override
	public Map<String, Object> updateOCCRule(Integer id, String str) {
		Map<String, Object> result = new HashMap<>();
		Map<String, Object> param = new HashMap<>();

		// 将数组以;为标准拆分，一个字段代表一个实例
		String[] arr = str.split(";");
		for (String a : arr) {
			// 将实例拆分为id和数值
			String[] b = a.split(",");
			// 获取到id的值
			String pygzId = b[0];
			OccRule occRule = occRuleMapper.findById(Integer.valueOf(pygzId));
			// 根据判异规则id查询原判异规则实例
			param = new HashMap<>();
			param.put("pygzslOocRuleId", pygzId);
			param.put("pygzslControlChartId", id);
			List<OccRuleInstance> occRuleInstances = occRuleInstanceMapper.findByCondition(param);
			for (OccRuleInstance occRuleInstance : occRuleInstances) {
				occRuleInstanceMapper.delete(occRuleInstance.getPygzslId());
			}
			// 获取实例的名称
			String c = occRule.getPygzVariate();
			// 拆分实例名称
			String[] d = c.split(",");
			for (int i = 1; i < b.length && i <= d.length; i++) {
				String value = b[i];
				String name = d[i - 1];
				OccRuleInstance occRuleInstance = new OccRuleInstance();
				occRuleInstance.setPygzslName(name);
				occRuleInstance.setPygzslValue(Integer.valueOf(value));
				occRuleInstance.setPygzslOocRuleId(Integer.valueOf(pygzId));
				occRuleInstance.setPygzslControlChartId(id);
				occRuleInstanceMapper.insert(occRuleInstance);
			}
		}

		result.put("success", successCode);
		result.put("message", updateSuccess);
		return result;
	}
}
