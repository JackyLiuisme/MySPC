package com.nbst.model;

public class TypeLevelFive {
	// ID
	private Integer cclxfiveId;
	// 层次类型名称
	private String cclxfiveName;
	// 状态
	private String cclxfiveExtend1;

	private String cclxfiveExtend2;

	private String cclxfiveExtend3;

	private String cclxfiveExtend4;

	private String cclxfiveExtend5;

	public Integer getCclxfiveId() {
		return cclxfiveId;
	}

	public void setCclxfiveId(Integer cclxfiveId) {
		this.cclxfiveId = cclxfiveId;
	}

	public String getCclxfiveName() {
		return cclxfiveName;
	}

	public void setCclxfiveName(String cclxfiveName) {
		this.cclxfiveName = cclxfiveName == null ? null : cclxfiveName.trim();
	}

	public String getCclxfiveExtend1() {
		return cclxfiveExtend1;
	}

	public void setCclxfiveExtend1(String cclxfiveExtend1) {
		this.cclxfiveExtend1 = cclxfiveExtend1 == null ? null : cclxfiveExtend1.trim();
	}

	public String getCclxfiveExtend2() {
		return cclxfiveExtend2;
	}

	public void setCclxfiveExtend2(String cclxfiveExtend2) {
		this.cclxfiveExtend2 = cclxfiveExtend2 == null ? null : cclxfiveExtend2.trim();
	}

	public String getCclxfiveExtend3() {
		return cclxfiveExtend3;
	}

	public void setCclxfiveExtend3(String cclxfiveExtend3) {
		this.cclxfiveExtend3 = cclxfiveExtend3 == null ? null : cclxfiveExtend3.trim();
	}

	public String getCclxfiveExtend4() {
		return cclxfiveExtend4;
	}

	public void setCclxfiveExtend4(String cclxfiveExtend4) {
		this.cclxfiveExtend4 = cclxfiveExtend4 == null ? null : cclxfiveExtend4.trim();
	}

	public String getCclxfiveExtend5() {
		return cclxfiveExtend5;
	}

	public void setCclxfiveExtend5(String cclxfiveExtend5) {
		this.cclxfiveExtend5 = cclxfiveExtend5 == null ? null : cclxfiveExtend5.trim();
	}

	@Override
	public String toString() {
		return "TypeLevelFive [cclxfiveId=" + cclxfiveId + ", cclxfiveName=" + cclxfiveName + ", cclxfiveExtend1="
				+ cclxfiveExtend1 + ", cclxfiveExtend2=" + cclxfiveExtend2 + ", cclxfiveExtend3=" + cclxfiveExtend3
				+ ", cclxfiveExtend4=" + cclxfiveExtend4 + ", cclxfiveExtend5=" + cclxfiveExtend5 + "]";
	}
}