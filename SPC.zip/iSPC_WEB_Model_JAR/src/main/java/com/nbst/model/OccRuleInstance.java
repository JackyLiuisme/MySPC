package com.nbst.model;

public class OccRuleInstance {
	private Integer pygzslId;
	// 实例名称
	private String pygzslName;
	// 实例值
	private Integer pygzslValue;
	// 判异规则id
	private Integer pygzslOocRuleId;
	// 所属的控制图信息id
	private Integer pygzslControlChartId;

	private String pygzslExtend1;

	private String pygzslExtend2;

	private String pygzslExtend3;

	private String pygzslExtend4;

	private String pygzslExtend5;

	public Integer getPygzslId() {
		return pygzslId;
	}

	public void setPygzslId(Integer pygzslId) {
		this.pygzslId = pygzslId;
	}

	public String getPygzslName() {
		return pygzslName;
	}

	public void setPygzslName(String pygzslName) {
		this.pygzslName = pygzslName == null ? null : pygzslName.trim();
	}

	public Integer getPygzslValue() {
		return pygzslValue;
	}

	public void setPygzslValue(Integer pygzslValue) {
		this.pygzslValue = pygzslValue;
	}

	public Integer getPygzslOocRuleId() {
		return pygzslOocRuleId;
	}

	public void setPygzslOocRuleId(Integer pygzslOocRuleId) {
		this.pygzslOocRuleId = pygzslOocRuleId;
	}

	public Integer getPygzslControlChartId() {
		return pygzslControlChartId;
	}

	public void setPygzslControlChartId(Integer pygzslControlChartId) {
		this.pygzslControlChartId = pygzslControlChartId;
	}

	public String getPygzslExtend1() {
		return pygzslExtend1;
	}

	public void setPygzslExtend1(String pygzslExtend1) {
		this.pygzslExtend1 = pygzslExtend1 == null ? null : pygzslExtend1.trim();
	}

	public String getPygzslExtend2() {
		return pygzslExtend2;
	}

	public void setPygzslExtend2(String pygzslExtend2) {
		this.pygzslExtend2 = pygzslExtend2 == null ? null : pygzslExtend2.trim();
	}

	public String getPygzslExtend3() {
		return pygzslExtend3;
	}

	public void setPygzslExtend3(String pygzslExtend3) {
		this.pygzslExtend3 = pygzslExtend3 == null ? null : pygzslExtend3.trim();
	}

	public String getPygzslExtend4() {
		return pygzslExtend4;
	}

	public void setPygzslExtend4(String pygzslExtend4) {
		this.pygzslExtend4 = pygzslExtend4 == null ? null : pygzslExtend4.trim();
	}

	public String getPygzslExtend5() {
		return pygzslExtend5;
	}

	public void setPygzslExtend5(String pygzslExtend5) {
		this.pygzslExtend5 = pygzslExtend5 == null ? null : pygzslExtend5.trim();
	}

	@Override
	public String toString() {
		return "OccRuleInstance [pygzslId=" + pygzslId + ", pygzslName=" + pygzslName + ", pygzslValue=" + pygzslValue
				+ ", pygzslOocRuleId=" + pygzslOocRuleId + ", pygzslControlChartId=" + pygzslControlChartId
				+ ", pygzslExtend1=" + pygzslExtend1 + ", pygzslExtend2=" + pygzslExtend2 + ", pygzslExtend3="
				+ pygzslExtend3 + ", pygzslExtend4=" + pygzslExtend4 + ", pygzslExtend5=" + pygzslExtend5 + "]";
	}

}