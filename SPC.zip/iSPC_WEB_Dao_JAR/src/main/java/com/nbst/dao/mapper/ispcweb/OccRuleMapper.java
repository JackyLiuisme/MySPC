package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.OccRule;

public interface OccRuleMapper {
    int delete(Integer pygzRuleId);

    int insert(OccRule record);

    OccRule findById(Integer pygzRuleId);

    int update(OccRule record);

    List<OccRule> findByCondition(Map<String,Object> map);
    
    int count(Map<String,Object> map);
}