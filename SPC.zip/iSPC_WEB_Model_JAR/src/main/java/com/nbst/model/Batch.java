package com.nbst.model;

public class Batch {
	// 批次ID
	private Integer pcId;
	// 批次名称
	private String pcName;

	private String pcExtend1;

	private String pcExtend2;

	private String pcExtend3;

	private String pcExtend4;

	private String pcExtend5;

	public Integer getPcId() {
		return pcId;
	}

	public void setPcId(Integer pcId) {
		this.pcId = pcId;
	}

	public String getPcName() {
		return pcName;
	}

	public void setPcName(String pcName) {
		this.pcName = pcName == null ? null : pcName.trim();
	}

	public String getPcExtend1() {
		return pcExtend1;
	}

	public void setPcExtend1(String pcExtend1) {
		this.pcExtend1 = pcExtend1 == null ? null : pcExtend1.trim();
	}

	public String getPcExtend2() {
		return pcExtend2;
	}

	public void setPcExtend2(String pcExtend2) {
		this.pcExtend2 = pcExtend2 == null ? null : pcExtend2.trim();
	}

	public String getPcExtend3() {
		return pcExtend3;
	}

	public void setPcExtend3(String pcExtend3) {
		this.pcExtend3 = pcExtend3 == null ? null : pcExtend3.trim();
	}

	public String getPcExtend4() {
		return pcExtend4;
	}

	public void setPcExtend4(String pcExtend4) {
		this.pcExtend4 = pcExtend4 == null ? null : pcExtend4.trim();
	}

	public String getPcExtend5() {
		return pcExtend5;
	}

	public void setPcExtend5(String pcExtend5) {
		this.pcExtend5 = pcExtend5 == null ? null : pcExtend5.trim();
	}

	@Override
	public String toString() {
		return "Batch [pcId=" + pcId + ", pcName=" + pcName + ", pcExtend1=" + pcExtend1 + ", pcExtend2=" + pcExtend2
				+ ", pcExtend3=" + pcExtend3 + ", pcExtend4=" + pcExtend4 + ", pcExtend5=" + pcExtend5 + "]";
	}

}