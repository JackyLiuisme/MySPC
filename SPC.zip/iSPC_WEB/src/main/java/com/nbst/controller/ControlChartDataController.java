package com.nbst.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nbst.comnutil.AppUtil;
import com.nbst.model.DetectionData;
import com.nbst.service.IControIChartDataService;
import groovy.util.logging.Slf4j;

@Controller
@RequestMapping("/controlChartData")
@Slf4j
@CrossOrigin
public class ControlChartDataController {
	private IControIChartDataService controIChartDataService;

	/**
	 * 表内数据增加
	 * 
	 * @param detectionData 检测数据项
	 * @return
	 */
	@RequestMapping(value = "/add.action", method = RequestMethod.POST)
	@ResponseBody
	public Object addControlChartData(DetectionData detectionData) {
		return AppUtil.conversionJsonp(controIChartDataService.addControlChartData(detectionData));
	}

	/**
	 * 表内数据修改
	 * 
	 * @param detectionData 检测数据项
	 * @author lijiajun
	 * @return
	 */
	@ResponseBody
	public Object updateControlChartData(DetectionData detectionData) {
		return AppUtil.conversionJsonp(controIChartDataService.updateControlChartData(detectionData));
	}

	/**
	 * 表内数据删除
	 * 
	 * @param jcsjId 数据id
	 * @author lijiajun
	 * @return
	 */
	@RequestMapping(value = "/delet.action", method = RequestMethod.POST)
	@ResponseBody
	public Object deletControlChartData(Integer jcsjId) {
		return AppUtil.conversionJsonp(controIChartDataService.deletControlChartData(jcsjId));
	}

	/**
	 * 表内数据查找
	 * 
	 * @param jcsjControlChartId 控制图id
	 * @param jcsjRecordTime     录入时间
	 * @param jcsjExtractTime    抽取时间
	 * @author lijiajun
	 * @return
	 */
	@RequestMapping(value = "/search.action", method = RequestMethod.GET)
	@ResponseBody
	public Object searchControlChartData(Integer jcsjControlChartId, Long jcsjRecordTime, Long jcsjExtractTime) {
		return AppUtil.conversionJsonp(
				controIChartDataService.searchControlChartData(jcsjControlChartId, jcsjRecordTime, jcsjExtractTime));
	}

}
