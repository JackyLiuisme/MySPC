package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.ControlChartType;

public interface ControlChartTypeMapper {
    int delete(Integer kztlxId);

    int insert(ControlChartType record);

    ControlChartType findById(Integer kztlxId);

    int update(ControlChartType record);

    List<ControlChartType> findByCondition(Map<String,Object> map);
    
    int count(Map<String,Object> map);
}