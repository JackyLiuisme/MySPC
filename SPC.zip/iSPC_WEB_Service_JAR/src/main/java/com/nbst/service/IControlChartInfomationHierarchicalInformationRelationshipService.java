package com.nbst.service;

import com.nbst.model.ControlChartInfomationHierarchicalInformationRelationship;

/**
 * @author yangl
 *
 */
public interface IControlChartInfomationHierarchicalInformationRelationshipService {

	// 控制图层次信息关联修改
	Object alterRelationship(ControlChartInfomationHierarchicalInformationRelationship relationship);

	// 控制图层次信息关联查询
	Object searchRelationship(Integer controlChartId);

}