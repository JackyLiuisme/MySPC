package com.nbst.service;

import java.util.Map;

/**
 * 控制图计算信息接口
 * 
 * @param controlChartInfomation 控制字符信息
 * @author lijiajun
 *
 */
public interface IControlChartCalculationInformationService {
	Map<String, Object> controlChartCalculationInformation(Integer jcsjControlChartId,
			String kztxxSpecificationUpperLimit, Integer kzttjSampleSize, String kztxxTargetValue,
			Integer kztxxSampleCapacity, Integer kztxxDecimalNumber, double SeiGaMa);
}
