package com.nbst.enums;

import lombok.Getter;

/**
 * @author huangh
 *
 */
@Getter
public enum OperationType {

	UPDATE(0, "修改操作"),
    DELETE(1, "删除操作"),
    ;
    
	OperationType(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }
    
    private Integer code;
    private String desc;
}
