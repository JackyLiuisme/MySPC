var flag=0;//判断保存时是新增还是删除
var cId;//保存id，用于修改

/**
 * @method 
 * @desc  显示新增窗口
 * @author gj
 * @date 2018年10月14日
 */

var setting = {
		view: {
			showIcon: showIconForTree
		},
		data: {
			simpleData: {
				enable: true
			}
		}
	};

	var zNodes =[
		{ id:1, pId:0, name:"父节点1 - 展开", open:true},
		{ id:11, pId:1, name:"父节点11 - 折叠"},
		{ id:111, pId:11, name:"叶子节点111"},
		{ id:112, pId:11, name:"叶子节点112"},
		{ id:113, pId:11, name:"叶子节点113"},
		{ id:114, pId:11, name:"叶子节点114"},
		{ id:12, pId:1, name:"父节点12 - 折叠"},
		{ id:121, pId:12, name:"叶子节点121"},
		{ id:122, pId:12, name:"叶子节点122"},
		{ id:123, pId:12, name:"叶子节点123"},
		{ id:124, pId:12, name:"叶子节点124"},
		{ id:13, pId:1, name:"父节点13 - 没有子节点", isParent:true},
		{ id:2, pId:0, name:"父节点2 - 折叠"},
		{ id:21, pId:2, name:"父节点21 - 展开", open:true},
		{ id:211, pId:21, name:"叶子节点211"},
		{ id:212, pId:21, name:"叶子节点212"},
		{ id:213, pId:21, name:"叶子节点213"},
		{ id:214, pId:21, name:"叶子节点214"},
		{ id:22, pId:2, name:"父节点22 - 折叠"},
		{ id:221, pId:22, name:"叶子节点221"},
		{ id:222, pId:22, name:"叶子节点222"},
		{ id:223, pId:22, name:"叶子节点223"},
		{ id:224, pId:22, name:"叶子节点224"},
		{ id:23, pId:2, name:"父节点23 - 折叠"},
		{ id:231, pId:23, name:"叶子节点231"},
		{ id:232, pId:23, name:"叶子节点232"},
		{ id:233, pId:23, name:"叶子节点233"},
		{ id:234, pId:23, name:"叶子节点234"},
		{ id:3, pId:0, name:"父节点3 - 没有子节点", isParent:true}
	];

	function showIconForTree(treeId, treeNode) {
		return !treeNode.isParent;
	};

	$(document).ready(function(){
		$.fn.zTree.init($("#treeDemo"), setting, zNodes);
	});


function showAdd(){
	$("#N100,#N110").val("");
	flag=1;
	$("#myModal").modal('show');
	$("#myModalLabel").html("添加");
	
}


/**
 * 提交新增和修改
 */
function save(){  //新增，修改	
	   if(flag==1){    //新增
		if($("#N100").val()==""){
			toastr.warning("设备编号不得为空!");
			return false;
		}
		if($("#N110").val()==""){
			toastr.warning("设备名称不得为空!");
			return false;
		}
//		$.ajax({
//			url:"EquipmentDetection/add.action",
//	        type: "POST",
//	        dataType:"JSON",
//	        data:{
//	        	jcxmName:$("#name").val(),
//	        	jcxmCode:$("#code").val()
//	        },
//	        success: function(data) {
//	        	if(data.code=="0000"){
//	        		toastr.success(data.message);
//	        		$("#myModal").modal('hide');
//		        	showTable();
//	        	}else{
//	        		toastr.error(data.message);
//	        	}
//	        	
//	        },
//	        error: function(request) {
//	        	console.log(request);
//	        }
//		});
		var row={
				"jcsbCode":$("#N100").val(),
				"jcsbName":$("#N110").val()
		}
		$('#table').bootstrapTable('append', row);
		$("#myModal").modal('hide');
     	
		
	}else if(flag==2){    //修改
		if($("#N100").val()==""){
			toastr.warning("设备编号不得为空!");
			return false;
		}
		if($("#N110").val()==""){
			toastr.warning("设备名称不得为空!");
			return false;
		}
		var row={
				"jcsbCode":$("#N100").val(),
				"jcsbName":$("#N110").val()
		}
		$('#table').bootstrapTable('updateRow', {index: 1, row: row});
		$("#myModal").modal('hide');
//		$.ajax({
//			url:"EquipmentDetection/update.action",
//	        type: "POST",
//	        dataType:"JSON",
//	        data:{
//	        	jcxmId:cId,
//	        	jcxmName:$("#name").val(),
//	        	jcxmCode:$("#code").val(),
//	        	state:1
//	        },
//	        success: function(data) {
//	        	if(data.code=="0000"){
//	        		toastr.success(data.message);
//	        		$("#myModal").modal('hide');
//		        	showTable();
//	        	}else{
//	        		toastr.error(data.message);
//	        	}
//	        },
//	        error: function(request) {
//	        	console.log(request);
//	        }
//		});
	}
}

/**
 *新增和修改格式化
*/

function operate(value, row, index) {
	var str = "";
    str += '<a class="btn btn-warning btn-xs update" style="background-color: #f5b834;border-color: #f5b834">修改</a>&nbsp';
    str += '<a class="btn btn-danger btn-xs delete" style="background-color: #f23333;border-color: #f23333">删除</a>&nbsp';
	return str;
}
/**
 * 操作点击事件
 */
window.operateEvents = {
		'click .update' : function(e, value, row, index) {
			$("#N100").val(row.jcsbCode);
			$("#N110").val(row.jcsbName);
			$("#myModalLabel").html("修改");
			$("#myModal").modal('show');
			flag=2;
			cId=row.jcsbId;
		},
		'click .delete' : function(e, value, row, index) {
			Showbo.Msg.confirm('是否确认删除？'
//			function(btn){
//				if(btn == "yes"){
//					$.ajax({
//						url:"EquipmentDetection/update.action",
//				        type: "POST",
//				        dataType:"JSON",
//				        data:{
//				        	jcxmId:row.jcxmId,
//				        	state:0
//				        },
//				        success: function(data) {
//				        	if(data.code=="0000"){
//				        		toastr.success(data.message);
//				        	}else{
//				        		toastr.error(data.message);
//				        	}
//				        	showTable();
//				        },
//				        error: function(request) {
//				        	console.log(request);
//				        }
//					});
//				}
//			}
			)
			var row={
				"jcsbCode":$("#N100").val(),
				"jcsbName":$("#N110").val()
		}
			$table.bootstrapTable('remove', {field: 'row', values:row});
		}
}

/**
 * 调用显示table接口
 */
//showTable();

/**
 * 
 * @method
 * @desc  显示检测项列表
 * @author gj
 * @date 2018年10月14日
 */
function showTable() {
	$('#table').bootstrapTable('destroy').bootstrapTable({
//		url : 'EquipmentDetection/search.action', //请求后台的URL（*）  
//		queryParams : function(param){
//			 return{
//				 limit:param.limit,
//				 offset:param.offset
//			 }
//		 },// 传递参数（*）
//		sidePagination : "server", // 分页方式：client客户端分页，server服务端分页（*）
		striped : false, // 是否显示行间隔色
		pagination : true, // 是否显示分页（*）
		sortable : false, // 是否启用排序
		sortOrder : "asc", // 排序方式
        toolbar:"#toolbar",
        uniqueId:"jcsbid",
		pageNumber : 1, // 初始化加载第一页，默认第一页
		pageSize : 10, // 每页的记录行数（*）
		pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
		strictSearch : true,
		clickToSelect : true, // 是否启用点击选中行
		height : 412, // 行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		columns : [ 
	   {
			field : 'jcsbCode',
			title : '设备编号',
			align:"center"
		   }, 
       {
			field : 'jcsbName',
			title : '设备名称',
			align:"center"
		   }, 
		 {
			field : '',
			title : '操作',
			align:"center",
			formatter : operate,
			events : operateEvents
		}
		],
		 onLoadSuccess : function(data) {

			}
	});
	var data=[
				{"jcsbCode":1,"jcsbName":"产品型号"},
				{"jcsbCode":2,"jcsbName":"产品名称"},
				{"jcsbCode":3,"jcsbName":"产线"},
				{"jcsbCode":4,"jcsbName":"班次"},
				{"jcsbCode":5,"jcsbName":"设备"},
				{"jcsbCode":6,"jcsbName":"供应商"},
				{"jcsbCode":7,"jcsbName":"客户"}
			]
		$('#table').bootstrapTable('load',data);
	
};



