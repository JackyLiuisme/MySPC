package com.nbst.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nbst.comnutil.AppUtil;
import com.nbst.model.ControlChartStatistics;
import com.nbst.service.ICalculationService;
import com.nbst.service.IControlChartSampleCalculationService;

import groovy.util.logging.Slf4j;

@Controller
@RequestMapping("/Sample")
@Slf4j
@CrossOrigin
public class ControlChartSampleCalculation {
	@Autowired
	private IControlChartSampleCalculationService controlChartSampleCalculationService;

	/**
	 * 样本数据计算
	 * 
	 * @param relation
	 * @author lijiajun
	 * @return
	 */
	@RequestMapping(value = "/calculation.action", method = RequestMethod.GET)
	@ResponseBody
	public Object calculationChartInfomation(String jcsjDataSample) {
		return AppUtil.conversionJsonp(controlChartSampleCalculationService.controlChartSampleCalculation(jcsjDataSample));
	}
}
