package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.ControlChartStatistics;

public interface ControlChartStatisticsMapper {
    int delete(Integer kzttjId);

    int insert(ControlChartStatistics record);

    ControlChartStatistics findById(Integer kzttjId);

    int update(ControlChartStatistics record);

    List<ControlChartStatistics> findByCondition(Map<String,Object> map);
    
    int count(Map<String,Object> map);
}