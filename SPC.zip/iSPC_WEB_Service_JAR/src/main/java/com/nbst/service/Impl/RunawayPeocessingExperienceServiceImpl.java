package com.nbst.service.Impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nbst.dao.mapper.ispcweb.RunawayProcessingExperienceMapper;
import com.nbst.model.PoorDefinition;
import com.nbst.model.RunawayProcessingExperience;
import com.nbst.service.IRunawayProcessingExperienceService;

import groovy.util.logging.Slf4j;

@Service
@Transactional
@Slf4j
public class RunawayPeocessingExperienceServiceImpl implements IRunawayProcessingExperienceService {
	
	@Autowired
	private RunawayProcessingExperienceMapper runawayPEMapper;
	
	private final static String EXIST_STATE = "1";
	private final static String DELETE_STATE = "0";
	@Override
	public Map<String, Object> add(RunawayProcessingExperience rpe) {
		//允许历史经验的失控原因和失控处理重复
		Map<String,Object> resultMap = new HashMap<>();
		rpe.setSkcljyExtend1(EXIST_STATE);	//将表的skcljyExtend1字段作为存在("1")和已删除("0")的标志
		int flag = runawayPEMapper.insert(rpe);
		if(flag!=0) {
			resultMap.put("message", "新增成功");
			resultMap.put("code", "0000");
			resultMap.put("id",rpe.getSkcljyId());
		}
		else {
			resultMap.put("message", "新增失败");
			resultMap.put("code", "9998");
		}
		
		return resultMap;
	}

	@Override
	public Map<String, Object> update(RunawayProcessingExperience rpe, Integer state) {
		Map<String,Object> resultMap = new HashMap<>();
		//state为1时进行修改
		if(state != 0) {
			RunawayProcessingExperience targerRPE = runawayPEMapper.findById(rpe.getSkcljyId());
			if(targerRPE == null || targerRPE.getSkcljyExtend1().equals(DELETE_STATE)) {
				resultMap.put("message", "找不到对应失控处理经验，修改失败");
				resultMap.put("code", "9998");
			}
			else {
				rpe.setSkcljyExtend1(EXIST_STATE); 	//将rpe的skcljyExtend1的状态字段
				int flag = runawayPEMapper.update(rpe);
				if(flag!=0) {
					resultMap.put("message", "修改成功");
					resultMap.put("code", "0000");
				} else {
					resultMap.put("message", "修改失败");
					resultMap.put("code", "9999");
				}
			}
			
			return resultMap;
		}
		else {//state为0时进行删除
			RunawayProcessingExperience targetRPE = runawayPEMapper.findById(rpe.getSkcljyId());
			if(targetRPE == null || targetRPE.getSkcljyExtend1().equals(DELETE_STATE)) {
				resultMap.put("message", "找不到对应失控处理经验，修改失败");
				resultMap.put("code", "9998");
			}
			else {
				targetRPE.setSkcljyExtend1(DELETE_STATE);
				int flag = runawayPEMapper.update(targetRPE);
				if(flag != 0) {
					resultMap.put("message", "删除成功");
					resultMap.put("code", "0000");
				} else {
					resultMap.put("message", "删除失败");
					resultMap.put("code", "9999");
				}
			}
			
			return resultMap;
		}
	}

	@Override
	public Map<String, Object> search(Integer limit, Integer offset) {
		Map<String,Object> resultMap = new HashMap<>();
		Map<String,Object> conditionmap = new HashMap<>();
		List<Map<String,Object>> rows = new ArrayList<>();	//存储返回结果
		conditionmap.put("skcljyId", EXIST_STATE);
		conditionmap.put("limit", limit);
		conditionmap.put("offset", offset);
		List<RunawayProcessingExperience> list = runawayPEMapper.findByCondition(conditionmap);
		int total = list.size();
		for(RunawayProcessingExperience rpe:list) {
			Map<String,Object> map = new HashMap<>();
			
		}
		
	}
	
}
