package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.TypeLevelFive;

public interface TypeLevelFiveMapper {
	int delete(Integer cclxfiveId);

	int insert(TypeLevelFive record);

	TypeLevelFive findById(Integer cclxfiveId);

	int update(TypeLevelFive record);

	List<TypeLevelFive> findByCondition(Map<String, Object> map);

	int count(Map<String, Object> map);
}