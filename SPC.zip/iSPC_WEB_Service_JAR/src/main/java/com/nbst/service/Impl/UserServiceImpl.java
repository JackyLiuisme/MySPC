package com.nbst.service.Impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nbst.dao.mapper.ispcweb.UserMapper;
import com.nbst.model.User;
import com.nbst.service.IUserService;

import groovy.util.logging.Slf4j;

/**
 * @author yangl
 *
 */
@Slf4j
@Service
@Transactional
public class UserServiceImpl implements IUserService {
	@Autowired
	private UserMapper userMapper;

	/**
	 * 用户管理新增，如果用户名重复则插入失败
	 * 
	 * @param user
	 * @return
	 */
	@Override
	public Object addUser(User user) {
		Map<String, Object> resultMap = new HashMap<>();
		// 判断name是否重复
		Map<String, Object> conditionMap = new HashMap<>();
		conditionMap.put("yhUsername", user.getYhUsername());
		conditionMap.put("yhState", 1);
		List<User> names = userMapper.findByCondition(conditionMap);
		if (!names.isEmpty()) {
			resultMap.put("message", "名称重复，新增失败");
			resultMap.put("code", "9999");
			return resultMap;
		}

		// 若name无重复则插入
		int flag = userMapper.insert(user);
		if (flag != 0) {
			resultMap.put("message", "新增成功");
			resultMap.put("code", "0000");
		} else {
			resultMap.put("message", "新增失败");
			resultMap.put("code", "9997");
			return resultMap;
		}

		return resultMap;
	}

	/**
	 * 用户管理修改/删除,state=0：删除,state=1:修改
	 * 
	 * @param user
	 * @return
	 */
	@Override
	public Object alterUser(User user, Integer state) {
		Map<String, Object> resultMap = new HashMap<>();
		// 删除
		if (state == 0) {
			User u=userMapper.findById(user.getYhId());
			u.setYhState(2);
			int flag = userMapper.update(u);
			if (flag > 0) {
				resultMap.put("message", "删除成功");
				resultMap.put("code", "0000");
			} else {
				resultMap.put("message", "删除失败");
				resultMap.put("code", "9996");
			}
			return resultMap;
		}
		// 修改
		// 判断name是否重复
		Map<String, Object> conditionMap = new HashMap<>();
		conditionMap.put("yhUsername", user.getYhUsername());
		List<User> names = userMapper.findByCondition(conditionMap);
		for (User u : names) {
			if (!u.getYhId().equals(user.getYhId())) {
				resultMap.put("message", "名称重复，修改失败");
				resultMap.put("code", "9995");
				return resultMap;
			}
		}
		// name不重复则更新
		int flag = userMapper.update(user);
		if (flag > 0) {
			resultMap.put("message", "修改成功");
			resultMap.put("code", "0000");
		} else {
			resultMap.put("message", "修改失败");
			resultMap.put("code", "9994");
		}
		return resultMap;
	}

	/**
	 * 用户管理查询
	 * 
	 * @param limit
	 * @param offset
	 * @return
	 */
	@Override
	public Object searchUser(Integer limit, Integer offset) {
		Map<String, Object> resultMap = new HashMap<>();
		Map<String, Object> conditionMap = new HashMap<>();
		conditionMap.put("yhState", 1);
		int count = userMapper.count(conditionMap);
		conditionMap.put("limit", limit);
		conditionMap.put("offset", offset);

		resultMap.put("total", count);
		resultMap.put("code", "0000");
		resultMap.put("message", "查找成功");
		resultMap.put("rows", userMapper.findByCondition(conditionMap));
		return resultMap;
	}
}