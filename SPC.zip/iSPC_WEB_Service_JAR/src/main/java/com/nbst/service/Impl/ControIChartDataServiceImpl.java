package com.nbst.service.Impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nbst.dao.mapper.ispcweb.DetectionDataMapper;
import com.nbst.model.DetectionData;
import com.nbst.service.IControIChartDataService;

import groovy.util.logging.Slf4j;

@Slf4j
@Service
@Transactional
public class ControIChartDataServiceImpl implements IControIChartDataService {
	@Autowired
	private DetectionDataMapper detectionDataMapper;

	/**
	 * 表内数据增加
	 * 
	 * @param detectionData 检测数据项
	 * @author lijiajun
	 */
	@Override
	public Map<String, Object> addControlChartData(DetectionData detectionData) {
		Map<String, Object> returnmap = new HashMap<>();
		detectionDataMapper.insert(detectionData);
		returnmap.put("jhid", detectionData.getJcsjUserId());
		returnmap.put("jcsb", detectionData);
		return returnmap;
	}

	/**
	 * 表内数据查找
	 * 
	 * @param jcsjControlChartId 控制图id
	 * @param jcsjRecordTime     录入时间
	 * @param jcsjExtractTime    抽取时间
	 * @author lijiajun
	 */
	@Override
	public Map<String, Object> searchControlChartData(Integer jcsjControlChartId, Long jcsjRecordTime,
			Long jcsjExtractTime) {
		Map<String, Object> returnmap = new HashMap<>();
		Map<String, Object> conditionmap = new HashMap<>();
		conditionmap.put("jcsjControlChartId", jcsjControlChartId);
		conditionmap.put("jcsjRecordTime", jcsjRecordTime);
		conditionmap.put("jcsjExtractTime", jcsjExtractTime);
		List<DetectionData> list = detectionDataMapper.findByCondition(conditionmap);
		returnmap.put("rows", list);
		return returnmap;
	}

	/**
	 * 表内数据修改
	 * 
	 * @param detectionData 检测数据项
	 * @author lijiajun
	 */
	@Override
	public Map<String, Object> updateControlChartData(DetectionData detectionData) {
		Map<String, Object> returnmap = new HashMap<>();
		detectionDataMapper.findById(detectionData.getJcsjId());
		detectionDataMapper.update(detectionData);
		returnmap.put("yhId", detectionData.getJcsjUserId());
		returnmap.put("jcsb", detectionData);
		return returnmap;
	}

	/**
	 * 表内数据删除
	 * 
	 * Integer jcsjId 数据id
	 * 
	 * @author lijiajun
	 */
	@Override
	public Map<String, Object> deletControlChartData(Integer jcsjId) {
		Map<String, Object> returnmap = new HashMap<>();
		detectionDataMapper.delete(jcsjId);
		return returnmap;
	}

}
