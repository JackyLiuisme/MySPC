package com.nbst.service;

import java.util.Map;

public interface IControlChartSampleCalculationService {
	/**
	 * @author lijiajun
	 * @param jcsjDataSample 样本数据
	 * @return returnmap
	 */
	Map<String, Object> controlChartSampleCalculation(String jcsjDataSample);
}
