package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.TypeLevelName;

public interface TypeLevelNameMapper {
    int delete(Integer ccmcId);

	int insert(TypeLevelName record);

	TypeLevelName findById(Integer cclxoneId);

	int update(TypeLevelName record);

	List<TypeLevelName> findByCondition(Map<String, Object> map);

	int count(Map<String, Object> map);
}