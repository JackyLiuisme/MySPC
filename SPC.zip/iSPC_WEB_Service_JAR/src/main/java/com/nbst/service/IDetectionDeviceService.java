package com.nbst.service;

import com.nbst.model.DetectionDevice;
/**
 * @author yangl
 *
 */
public interface IDetectionDeviceService {
	// 检测项新增
	Object addDetectionDevice(DetectionDevice detectionDevice);

	// 检测项修改/删除
	Object alterDetectionDevice(DetectionDevice detectionDevice, Integer state);

	// 检测项查询
	Object searchDetectionDevice(Integer limit, Integer offset);
}
