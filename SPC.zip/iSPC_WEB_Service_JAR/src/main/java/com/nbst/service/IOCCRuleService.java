package com.nbst.service;

import java.util.Map;

public interface IOCCRuleService {

	/**
	 * 判异规则查询
	 * 
	 * @param id 控制图信息id
	 * @author huangh
	 * @return Map<String, Object>
	 */
	Map<String, Object> getOCCRule(Integer id);

	/**
	 * 修改判异规则
	 * 
	 * @param id 控制图信息id
	 * @param str 关联的判异规则id以及变量名和值
	 * @author huangh
	 * @return Map<String, Object>
	 */
	Map<String, Object> updateOCCRule(Integer id, String str);
}
