package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.OutOfControlRecord;

public interface OutOfControlRecordMapper {
    int delete(Integer skjlId);

    int insert(OutOfControlRecord record);

    OutOfControlRecord findById(Integer skjlId);

    int update(OutOfControlRecord record);

    List<OutOfControlRecord> findByCondition(Map<String,Object> map);
    
    int count(Map<String,Object> map);
}