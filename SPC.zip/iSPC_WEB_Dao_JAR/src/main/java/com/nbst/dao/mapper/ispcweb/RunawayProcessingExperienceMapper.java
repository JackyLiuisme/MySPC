package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.RunawayProcessingExperience;

public interface RunawayProcessingExperienceMapper {
    int delete(Integer skcljyId);

    int insert(RunawayProcessingExperience record);

    RunawayProcessingExperience findById(Integer skcljyId);

    int update(RunawayProcessingExperience record);

    List<RunawayProcessingExperience> findByCondition(Map<String,Object> map);
    
    int count(Map<String,Object> map);
}