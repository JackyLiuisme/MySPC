package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.TypeLevelSix;

public interface TypeLevelSixMapper {
	int delete(Integer cclxsixId);

	int insert(TypeLevelSix record);

	TypeLevelSix findById(Integer cclxsixId);

	int update(TypeLevelSix record);

	List<TypeLevelSix> findByCondition(Map<String, Object> map);

	int count(Map<String, Object> map);
}