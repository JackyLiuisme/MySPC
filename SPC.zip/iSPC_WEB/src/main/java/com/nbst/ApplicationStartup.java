package com.nbst;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import com.nbst.comnutil.serverConf;

import lombok.extern.slf4j.Slf4j;

/**
 * @ClassName: ApplicationStartup
 * @Description:打印相关输出类
 * @author ZFM
 * @date 2017-11-24
 */
@Slf4j
public class ApplicationStartup implements ApplicationListener<ContextRefreshedEvent> {

	// private List<RegService> servers = Lists.newArrayList();
	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		// LogOut logout = event.getApplicationContext().getBean(LogOut.class); //日志配置
		serverConf conf = event.getApplicationContext().getBean(serverConf.class); // 服务系统配置

	}
}
