package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.TypeLevelEight;

public interface TypeLevelEightMapper {
	int delete(Integer cclxeightId);

	int insert(TypeLevelEight record);

	TypeLevelEight findById(Integer cclxeightId);

	int update(TypeLevelEight record);

	List<TypeLevelEight> findByCondition(Map<String, Object> map);

	int count(Map<String, Object> map);
}