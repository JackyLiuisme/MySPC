package com.nbst.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nbst.comnutil.AppUtil;
import com.nbst.service.ICalculationService;
import groovy.util.logging.Slf4j;

@Controller
@RequestMapping("/kzt")
@Slf4j
@CrossOrigin
public class ControlChartDataCalculationController {
	@Autowired
	private ICalculationService calculationService;

	/**
	 * 计算接口实现
	 * 
	 * @param jcsjControlChartId 控制图id
	 * @param kztxxTypeId        控制图类型id
	 * @param kzttjSampleSize    样本容量
	 * @author lijiajun
	 * @return
	 */
	@RequestMapping(value = "/calculation.action", method = RequestMethod.GET)
	@ResponseBody
	public Object calculationChartInfomation(Integer jcsjControlChartId, Integer kztxxTypeId, Integer kzttjSampleSize) {
		return AppUtil.conversionJsonp(
				calculationService.calculationChartInfomation(jcsjControlChartId, kztxxTypeId, kzttjSampleSize));
	}
}
