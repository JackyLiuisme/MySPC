package com.nbst.service.Impl;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nbst.dao.mapper.ispcweb.DetectionDataMapper;
import com.nbst.model.DetectionData;
import com.nbst.service.ICalculationService;
import groovy.util.logging.Slf4j;
@Slf4j
@Service
@Transactional
public class CalculationServiceImpl implements ICalculationService {
	@Autowired
	private DetectionDataMapper detectionDataMapper;
	// 调用参数的值
	public static double[] A2 = new double[] { 0, 0, 1.880, 1.023, 0.729, 0.577, 0.483, 0.419, 0.373, 0.337, 0.308,
			0.285, 0.266, 0.249, 0.235, 0.223, 0.212, 0.203, 0.194, 0.187, 0.180, 0.173, 0.167, 0.162, 0.157, 0.153 };
	public static double[] D2 = { 1.0, 1.0, 1.128, 1.169, 2.059, 2.326, 2.543, 2.704, 2.847, 2.970, 3.078, 3.173, 3.258,
			3.336, 3.407, 3.472, 3.532, 3.588, 3.640, 3.689, 3.735, 3.778, 3.819, 3.858, 3.895, 3.931 };
	public static double[] D3 = new double[] { 0, 0, 0, 0, 0, 0, 0, 0.076, 0.136, 0.184, 0.223, 0.256, 0.283, 0.307,
			0.328, 0.347, 0.363, 0.378, 0.391, 0.403, 0.415, 0.425, 0.434, 0.443, 0.451, 0.459 };
	public static double[] D4 = new double[] { 0, 0, 3.267, 2.571, 2.282, 2.115, 2.004, 1.924, 1.864, 1.816, 1.777,
			1.717, 1.693, 1.672, 1.653, 1.637, 1.622, 1.608, 1.597, 1.585, 1.575, 1.566, 1.557, 1.548, 1.541 };
	public static double[] A3 = new double[] { 0, 0, 2.659, 1.954, 1.628, 1.427, 1.287, 1.182, 1.099, 1.032, 0.975,
			0.927, 0.886, 0.850, 0.817, 0.789, 0.763, 0.739, 0.718, 0.698, 0.680, 0.663, 0.647, 0.633, 0.619, 0.606 };
	// n 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 20 25
	public static double[] C4 = new double[] { 0, 0, 0.7979, 0.8862, 0.9213, 0.9400, 0.9515, 0.9594, 0.9650, 0.9693,
			0.9727, 0.9754, 0.9776, 0.9794, 0.9810, 0.9823, 0.9835, 0.9854, 0.9854, 0.9862, 0.9869, 0.9876, 0.9882,
			0.9887, 0.9892, 0.9896 }; // ,0.9869,0.9896};
	public static double[] B3 = new double[] { 0, 0, 0, 0, 0, 0, 0.030, 0.118, 0.185, 0.239, 0.284, 0.321, 0.354, 0.382,
			0.406, 0.428, 0.448, 0.446, 0.482, 0.497, 0.510, 0.523, 0.534, 0.545, 0.555, 0.565 }; // , 0.510, 0.565};
	public static double[] B4 = new double[] { 0, 0, 3.276, 2.568, 2.266, 2.089, 1.970, 1.882, 1.815, 1.761, 1.716,
			1.679, 1.640, 1.618, 1.594, 1.572, 1.552, 1.534, 1.518, 1.503, 1.490, 1.477, 1.466, 1.455, 1.445, 1.435 }; // ,
																														// 1.490,
																														// 1.435};
	// public static double[] B5 = new double[]{0,0, 0, 0, 0, 0, 0.029, 0.113,
	// 0.179, 0.232, 0.276, 0.313, 0.346, 0.374, 0.399, 0.421}; //, 0.504, 0.559};
	// public static double[] B6 = new double[]{0,0, 2.606, 2.276, 2.088, 1.964,
	// 1.874, 1.806, 1.751, 1.707, 1.669, 1.637, 1.610, 1.585, 1.563, 1.544}; //,
	// 1.470, 1.420};
	/**
	 * @param jcsjControlChartId 控制图id
	 * @param kztxxTypeId 控制图类型id
	 * @param kzttjSampleSize 样本容量
	 * @author lijiajun
	 *
	 */

	@Override
	public Map<String, Object> calculationChartInfomation(Integer jcsjControlChartId,Integer kztxxTypeId,Integer kzttjSampleSize) {
		Map<String, Object> returnmap = new HashMap<>();

		double UCLX = 0;
		double UCLR = 0;
		double LCLR = 0;
		double LCLX = 0;
		double CLR = 0;
		double CLX = 0;

		Map<String, Object> conditionmap1 = new HashMap<>();
		//通过控制图ID从数据库中找到对用控制图
		conditionmap1.put("jcsjControlChartId", jcsjControlChartId);
		List<DetectionData> list2 = detectionDataMapper.findByCondition(conditionmap1);
		List<Double> list = new ArrayList<>();
		List<Double> list1 = new ArrayList<>();
		Integer count = 0;
		for (DetectionData detectionData : list2) {
			String[] Array = detectionData.getJcsjControlChartData().split(",");
			//将平均值存入list
			list.add(Double.valueOf(Array[0]));
			//将极差值存入list1
			list1.add(Double.valueOf(Array[1]));
			count++;
		}
		//求出分布中心groupMean
		double sum1 = 0;
		double[] Mean = new double[100];
		int i = 0;
		for (double num : list) {
			Mean[i] = num;
			sum1 = num +sum1;
			i++;
		}
		double groupMean = sum1/count;
		//求出平均极差DistMean
		double sum2 = 0;
		 i = 0;
		double[] R = new double[100];
		for (double num : list1) {
			R[i] = num;
			sum2 = num +sum2;
			i++;
		}
		double DistMean = sum2/count;
		switch (kztxxTypeId) {

		case 1:// X-R控制图计算
			//计算UCL
			UCLX = groupMean + A2[count] * DistMean;
			UCLR = D4[count] * DistMean;

			// 计算LCL
			LCLX = Math.abs(groupMean - A2[count] * DistMean);
			LCLR = D3[count] * DistMean;
			// 计算CL
			CLX = (UCLX + LCLX) / 2;
			CLR = (UCLR + LCLR) / 2;
			//计算seigama
			double SeuGaMa = DistMean/ kzttjSampleSize;
			// 返回值
			returnmap.put("SeuGaMa", SeuGaMa);
			returnmap.put("UCLX", UCLX);
			returnmap.put("LCLR", LCLR);
			returnmap.put("UCLR", UCLR);
			returnmap.put("LCLX", LCLX);
			returnmap.put("CLX", CLX);
			returnmap.put("CLR", CLR);
			break;
		case 2:// X-S控制图计算
			double S1 = 0;
			for (DetectionData detectionData : list2) {
				String[] Array = detectionData.getJcsjDataSample().split(",");
				
				i = 0;
				for (String double1 : Array) {
					S1= Math.sqrt((Double.valueOf(double1)-Mean[i])*(Double.valueOf(double1)-Mean[i])/(kzttjSampleSize-1)) + S1;
				}
			}
			double S = S1/count;
			// 计算UCL
			UCLX = groupMean + A3[count] * S;
			UCLR = 0;
			// 计算CL
			CLX = (UCLX + LCLX) / 2;
			CLR = 0;
			// 计算LCL
			LCLX = groupMean - A2[count] * S;
			LCLR = 0;
			
			
			// 返回值
			returnmap.put("UCLX", UCLX);
			returnmap.put("LCLR", LCLR);
			returnmap.put("UCLR", UCLR);
			returnmap.put("LCLX", LCLX);
			returnmap.put("CLX", CLX);
			returnmap.put("CLR", CLR);
			
			break;

		case 3:// I-Rm控制图计算
			double MR = 0;
			for (DetectionData detectionData : list2) {
				 MR = Double.valueOf(detectionData.getJcsjDataSample());
			}
			UCLR = D4[1] * MR;
			UCLX = 0;
			// 计算CL
			CLX = 0;
			CLR = (UCLR + LCLR) / 2;
			// 计算LCL
			LCLX = 0;
			LCLR = D3[1] * MR;
			returnmap.put("UCLX", UCLX);
			returnmap.put("LCLR", LCLR);
			returnmap.put("UCLR", UCLR);
			returnmap.put("LCLX", LCLX);
			returnmap.put("CLX", CLX);
			returnmap.put("CLR", CLR);
			break;

		case 4:// 计算P不良管制图
			double P =0;
			UCLX = Math.min(P + 3 * Math.sqrt(P * (1 - P) / count), 1);
			LCLX = Math.max(P - 3 * Math.sqrt(P * (1 - P) / count), 0);
			UCLR = 0;

			// 计算CL
			CLX = 0;
			CLR = (UCLX + LCLX) / 2;
			// 计算LCL
			LCLR = 0;
			returnmap.put("UCLX", UCLX);
			returnmap.put("LCLR", LCLR);
			returnmap.put("UCLR", UCLR);
			returnmap.put("LCLX", LCLX);
			returnmap.put("CLX", CLX);
			returnmap.put("CLR", CLR);
			break;

		case 5:// 计算不良数管制图Pn
			double Pn = 0;
			double P1 = 0;
			UCLX = Pn + 3 * Math.sqrt(Pn * (1 - P1) / count);
			LCLX = Math.abs(Pn - 3 * Math.sqrt(Pn* (1 - P1) / count));
			UCLR = 0;

			// 计算CL
			CLX = 0;
			CLR = (UCLX + LCLX) / 2;
			// 计算LCL
			LCLR = 0;
			returnmap.put("UCLX", UCLX);
			returnmap.put("LCLR", LCLR);
			returnmap.put("UCLR", UCLR);
			returnmap.put("LCLX", LCLX);
			returnmap.put("CLX", CLX);
			returnmap.put("CLR", CLR);
			break;

		case 6://计算缺点管制图 C
			double C = 0;
			UCLX = C+ 3 * Math.sqrt(C);
			LCLX = Math.abs(C- 3 * Math.sqrt(C));
			UCLR = 0;

			// 计算CL
			CLX = 0;
			CLR = (UCLX + LCLX) / 2;
			// 计算LCL
			LCLR = 0;
			returnmap.put("UCLX", UCLX);
			returnmap.put("LCLR", LCLR);
			returnmap.put("UCLR", UCLR);
			returnmap.put("LCLX", LCLX);
			returnmap.put("CLX", CLX);
			returnmap.put("CLR", CLR);
			break;

		case 7://单位缺点管制图
			double u = 0;
			UCLX = u+ 3 * Math.sqrt(u/count);
			LCLX = Math.abs(u- 3 * Math.sqrt(u/count));
			UCLR = 0;

			// 计算CL
			CLX = 0;
			CLR = (UCLX + LCLX) / 2;
			// 计算LCL
			LCLR = 0;
			returnmap.put("UCLX", UCLX);
			returnmap.put("LCLR", LCLR);
			returnmap.put("UCLR", UCLR);
			returnmap.put("LCLX", LCLX);
			returnmap.put("CLX", CLX);
			returnmap.put("CLR", CLR);
			break;

		default:
			break;
		}
		return returnmap;
	}

}
