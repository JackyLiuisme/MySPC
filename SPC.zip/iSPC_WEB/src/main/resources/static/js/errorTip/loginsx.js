/*
 * @Description: 预加载
 * @param :
 */
$(function() {
	var c = 4;
//	var ts1 = '登陆已失效，请重新登陆。页面将于';
//	var ts2 = '秒后自动<a href="'+pathUrl('')+'" target="_top">跳转</a>登录页面';
	var ts1 = '秒后返回登录页';
	setInterval(function() {
	    $("#ts").html((c--)+ts1);
	    if(c==-1){
	    	window.top.location.href=pathUrl('');
	    }
	}, 1000);
});

/*
 * @Description: 返回登录页面按钮点击事件
 * @param :
 */
$("#goBack").click(function(){
	window.top.location.href=pathUrl('');
});