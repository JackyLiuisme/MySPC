package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.TypeLevelTwo;

public interface TypeLevelTwoMapper {
	int delete(Integer cclxtwoId);

	int insert(TypeLevelTwo record);

	TypeLevelTwo findById(Integer cclxtwoId);

	int update(TypeLevelTwo record);

	List<TypeLevelTwo> findByCondition(Map<String, Object> map);

	int count(Map<String, Object> map);
}