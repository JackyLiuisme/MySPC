package com.nbst.service;

import java.util.Map;

import com.nbst.model.PoorDefinition;

public interface IPoorDefinitionService {

	/**
	 * 增加不良定义
	 * @param pd
	 * @return
	 */
	Map<String,Object> addPoorDefinition(PoorDefinition pd);
	
	/**
	 * 当state为0时删除不良定义，当state为1时修改不良定义
	 * @param pd
	 * @param state
	 * @return
	 */
	Map<String,Object> updatePoorDefinition(PoorDefinition pd,Integer state);

	/**
	 * 从第offset条开始，搜索limit条数据
	 * @param limit
	 * @param offset
	 * @return
	 */
	Map<String,Object> searchPoorDefinition(Integer limit,Integer offset);
}
