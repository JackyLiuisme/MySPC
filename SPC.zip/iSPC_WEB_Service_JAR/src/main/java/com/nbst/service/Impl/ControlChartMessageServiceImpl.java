package com.nbst.service.Impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nbst.comnutil.Times;
import com.nbst.dao.mapper.ispcweb.ControlChartInfomationHierarchicalInformationRelationshipMapper;
import com.nbst.dao.mapper.ispcweb.ControlChartInfomationMapper;
import com.nbst.dao.mapper.ispcweb.ControlChartTypeMapper;
import com.nbst.dao.mapper.ispcweb.DetectionDataMapper;
import com.nbst.dao.mapper.ispcweb.DetectionItemMapper;
import com.nbst.dao.mapper.ispcweb.OccRuleInstanceMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelEightMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelFiveMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelFourMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelNameMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelNineMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelOneMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelSevenMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelSixMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelThreeMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelTwoMapper;
import com.nbst.dao.mapper.ispcweb.UserMapper;
import com.nbst.enums.OperationType;
import com.nbst.model.ControlChartInfomation;
import com.nbst.model.ControlChartInfomationHierarchicalInformationRelationship;
import com.nbst.model.ControlChartType;
import com.nbst.model.DetectionData;
import com.nbst.model.DetectionItem;
import com.nbst.model.TypeLevelName;
import com.nbst.model.User;
import com.nbst.service.IControlChartMessageService;

@Service
@Transactional
public class ControlChartMessageServiceImpl implements IControlChartMessageService {

	@Autowired
	private ControlChartInfomationMapper controlChartInfomationMapper;

	@Autowired
	private TypeLevelNameMapper typeLevelNameMapper;

	@Autowired
	private DetectionDataMapper detectionDataMapper;

	@Autowired
	private DetectionItemMapper detectionItemMapper;

	@Autowired
	private ControlChartTypeMapper controlChartTypeMapper;

	@Autowired
	private OccRuleInstanceMapper occRuleInstanceMapper;

	@Autowired
	private UserMapper userMapper;

	@Autowired
	private TypeLevelOneMapper typeLevelOneMapper;

	@Autowired
	private TypeLevelTwoMapper typeLevelTwoMapper;

	@Autowired
	private TypeLevelThreeMapper typeLevelThreeMapper;

	@Autowired
	private TypeLevelFourMapper typeLevelFourMapper;

	@Autowired
	private TypeLevelFiveMapper typeLevelFiveMapper;

	@Autowired
	private TypeLevelSixMapper typeLevelSixMapper;

	@Autowired
	private TypeLevelSevenMapper typeLevelSevenMapper;

	@Autowired
	private TypeLevelEightMapper typeLevelEightMapper;

	@Autowired
	private TypeLevelNineMapper typeLevelNineMapper;

	@Autowired
	private ControlChartInfomationHierarchicalInformationRelationshipMapper controlChartRelationshipMapper;

	// 操作成功编号
	private final static String SUCCESS_CODE = "0000";
	// 数据正常状态
	private final static String NORMAL_STATE = "1";
	// 数据软删状态
	private final static String DELETE_STATE = "2";
	// 数据点层次标识
	private final static Integer TYPE_LEVEL_STATE = 2;
	// 新增成功
	private final static String INSERT_SUCCESS = "新增成功";
	// 修改成功
	private final static String UPDATE_SUCCESS = "修改成功";
	// 查询成功
	private final static String SEARCH_SUCCESS = "查询成功";
	// 删除成功
	private final static String DELETE_SUCCESS = "删除成功";

	/**
	 * 查询层次类型名称
	 * 
	 * @author huangh
	 * @return Map<String, Object>
	 */
	@Override
	public Map<String, Object> getTypeLevelName() {
		Map<String, Object> result = new HashMap<>();
		Map<String, Object> param = new HashMap<>();

		int count = typeLevelNameMapper.count(param);
		List<TypeLevelName> typeLevelNames = typeLevelNameMapper.findByCondition(param);

		result.put("success", SUCCESS_CODE);
		result.put("message", SEARCH_SUCCESS);
		result.put("total", count);
		result.put("rows", typeLevelNames);
		return result;
	}

	/**
	 * 控制图信息查询
	 * 
	 * @param groupId 分组id
	 * @param limit
	 * @param offset
	 * @author huangh
	 * @return Map<String, Object>
	 */
	@Override
	public Map<String, Object> getControlChartMessage(Integer groupId, Integer limit, Integer offset) {
		Map<String, Object> result = new HashMap<>();
		Map<String, Object> param = new HashMap<>();
		Map<String, Object> map = new HashMap<>();
		List<Map<String, Object>> rows = new ArrayList<>();

		param.put("kztxxGroupId", groupId);
		param.put("kztxxExtend1", NORMAL_STATE);
		int count = controlChartInfomationMapper.count(param);
		param.put("limit", limit);
		param.put("offset", offset);
		// 根据分组id查询关联的控制图
		List<ControlChartInfomation> controlChartInfomations = controlChartInfomationMapper.findByCondition(param);
		for (ControlChartInfomation controlChartInfomation : controlChartInfomations) {
			param = new HashMap<>();
			param.put("kztxxccglControlChartId", controlChartInfomation.getKztxxId());
			// 根据控制图id查询关联的层次信息
			ControlChartInfomationHierarchicalInformationRelationship ccxxMessage = controlChartRelationshipMapper
					.findByCondition(param).get(0);
			// 查询出各层次的名称
			String cc1 = null;
			String cc2 = null;
			String cc3 = null;
			String cc4 = null;
			String cc5 = null;
			String cc6 = null;
			String cc7 = null;
			String cc8 = null;
			String cc9 = null;
			if (ccxxMessage.getKztxxccglTypeLevelOneId() != null && ccxxMessage.getKztxxccglTypeLevelOneState() != TYPE_LEVEL_STATE) {
				cc1 = typeLevelOneMapper.findById(ccxxMessage.getKztxxccglTypeLevelOneId()).getCclxoneName();
			}
			if (ccxxMessage.getKztxxccglTypeLevelTwoId() != null && ccxxMessage.getKztxxccglTypeLevelTwoState() != TYPE_LEVEL_STATE) {
				cc2 = typeLevelTwoMapper.findById(ccxxMessage.getKztxxccglTypeLevelTwoId()).getCclxtwoName();
			}
			if (ccxxMessage.getKztxxccglTypeLevelThreeId() != null && ccxxMessage.getKztxxccglTypeLevelThreeState() != TYPE_LEVEL_STATE) {
				cc3 = typeLevelThreeMapper.findById(ccxxMessage.getKztxxccglTypeLevelThreeId()).getCclxthreeName();
			}
			if (ccxxMessage.getKztxxccglTypeLevelFourId() != null && ccxxMessage.getKztxxccglTypeLevelFourState() != TYPE_LEVEL_STATE) {
				cc4 = typeLevelFourMapper.findById(ccxxMessage.getKztxxccglTypeLevelFourId()).getCclxfourName();
			}
			if (ccxxMessage.getKztxxccglTypeLevelFiveId() != null && ccxxMessage.getKztxxccglTypeLevelFiveState() != TYPE_LEVEL_STATE) {
				cc5 = typeLevelFiveMapper.findById(ccxxMessage.getKztxxccglTypeLevelFiveId()).getCclxfiveName();
			}
			if (ccxxMessage.getKztxxccglTypeLevelSixId() != null && ccxxMessage.getKztxxccglTypeLevelSixState() != TYPE_LEVEL_STATE) {
				cc6 = typeLevelSixMapper.findById(ccxxMessage.getKztxxccglTypeLevelSixId()).getCclxsixName();
			}
			if (ccxxMessage.getKztxxccglTypeLevelSevenId() != null && ccxxMessage.getKztxxccglTypeLevelSevenState() != TYPE_LEVEL_STATE) {
				cc7 = typeLevelSevenMapper.findById(ccxxMessage.getKztxxccglTypeLevelSevenId()).getCclxsevenName();
			}
			if (ccxxMessage.getKztxxccglTypeLevelEightId() != null && ccxxMessage.getKztxxccglTypeLevelEightState() != TYPE_LEVEL_STATE) {
				cc8 = typeLevelEightMapper.findById(ccxxMessage.getKztxxccglTypeLevelEightId()).getCclxeightName();
			}
			if (ccxxMessage.getKztxxccglTypeLevelNineId() != null && ccxxMessage.getKztxxccglTypeLevelNineState() != TYPE_LEVEL_STATE) {
				cc9 = typeLevelNineMapper.findById(ccxxMessage.getKztxxccglTypeLevelNineId()).getCclxnineName();
			}

			// 根据检测项id查询检测项名称
			DetectionItem detectionItem = detectionItemMapper
					.findById(controlChartInfomation.getKztxxDetectionItemId());
			// 根据控制图类型id查询类型名称
			ControlChartType controlChartType = controlChartTypeMapper
					.findById(controlChartInfomation.getKztxxTypeId());
			// 根据用户id查询用户名称
			Integer userId = Integer.valueOf(controlChartInfomation.getKztxxExtend3());
			User user = userMapper.findById(userId);
			// 根据控制图id查询判异规则id以及编号
			List<Map<String, String>> list = occRuleInstanceMapper
					.findOOCRuleByControlChartId(controlChartInfomation.getKztxxId());
			String str = null;
			for (Map<String, String> map2 : list) {
				param = new HashMap<>();
				param.put("pygzslControlChartId", controlChartInfomation.getKztxxId());
				param.put("pygzslOocRuleId", map2.get("occRuleId"));
				List<Integer> list2 = occRuleInstanceMapper.findOOCRuleInstanceByControlChartIdOccRuleId(param);
				str = map2.get("occRuleCode").toString();
				for (Integer i : list2) {
					if (i != null) {
						str = str + "-" + i.toString();
					}
				}
				str = str + ";";
			}
			// 根据控制图id查询数据是否存在异常
			param = new HashMap<>();
			param.put("jcsjControlChartId", controlChartInfomation.getKztxxId());
			param.put("jcsjState", 2);
			List<DetectionData> detectionDatas = detectionDataMapper.findByCondition(map);
			map = new HashMap<>();
			if (detectionDatas.isEmpty()) {
				param = new HashMap<>();
				param.put("jcsjControlChartId", controlChartInfomation.getKztxxId());
				param.put("jcsjState", 3);
				detectionDatas = detectionDataMapper.findByCondition(map);
				if (detectionDatas.isEmpty()) {
					map.put("zt", 1);
				} else {
					map.put("zt", 3);
				}
			} else {
				map.put("zt", 2);
			}

			map.put("id", controlChartInfomation.getKztxxId());
			map.put("bh", controlChartInfomation.getKztxxNumber());
			map.put("jcxm", detectionItem.getJcxmName());
			map.put("tl", controlChartType.getKztlxName());
			map.put("ybrl", controlChartInfomation.getKztxxSampleCapacity());
			map.put("cclx", ccxxMessage);
			map.put("cc1", cc1);
			map.put("cc2", cc2);
			map.put("cc3", cc3);
			map.put("cc4", cc4);
			map.put("cc5", cc5);
			map.put("cc6", cc6);
			map.put("cc7", cc7);
			map.put("cc8", cc8);
			map.put("cc9", cc9);
			map.put("ggsx", controlChartInfomation.getKztxxSpecificationUpperLimit());
			map.put("mbz", controlChartInfomation.getKztxxTargetValue());
			map.put("ggxx", controlChartInfomation.getKztxxSpecificationDownLimit());
			map.put("pygz", str);
			map.put("gxyh", user.getYhName());
			map.put("gxsj", controlChartInfomation.getKztxxExtend2());
			rows.add(map);
		}

		result.put("total", count);
		result.put("success", SUCCESS_CODE);
		result.put("message", SEARCH_SUCCESS);
		result.put("rows", rows);
		return result;
	}

	/**
	 * 控制图信息设置查询
	 * 
	 * @param id 控制图信息id
	 * @author huangh
	 * @return Map<String, Object>
	 */
	@Override
	public Map<String, Object> getControlChartSet(Integer id) {
		Map<String, Object> result = new HashMap<>();
		Map<String, Object> param = new HashMap<>();

		ControlChartInfomation controlChartInfomations = controlChartInfomationMapper.findById(id);

		// 查询控制图类型名称
		String typeName = controlChartTypeMapper.findById(controlChartInfomations.getKztxxTypeId()).getKztlxName();

		// 查询控制图检测项目名称
		String jcxmName = detectionItemMapper.findById(controlChartInfomations.getKztxxDetectionItemId()).getJcxmName();

		// 根据控制图id查询判异规则id以及编号
		List<Map<String, String>> list = occRuleInstanceMapper.findOOCRuleByControlChartId(id);
		String str = null;
		for (Map<String, String> map2 : list) {
			param = new HashMap<>();
			param.put("pygzslControlChartId", id);
			param.put("pygzslOocRuleId", map2.get("occRuleId"));
			List<Integer> list2 = occRuleInstanceMapper.findOOCRuleInstanceByControlChartIdOccRuleId(param);
			str = map2.get("occRuleCode").toString();
			for (Integer i : list2) {
				if (i != null) {
					str = str + "-" + i.toString();
				}
			}
			str = str + ";";
		}

		// 根据控制图id查询关联的层次信息
		param = new HashMap<>();
		param.put("kztxxccglControlChartId", id);
		ControlChartInfomationHierarchicalInformationRelationship ccxxMessage = controlChartRelationshipMapper
				.findByCondition(param).get(0);

		result.put("success", SUCCESS_CODE);
		result.put("message", SEARCH_SUCCESS);
		result.put("rows", controlChartInfomations);
		result.put("tlName", typeName);
		result.put("jcxmName", jcxmName);
		result.put("cclx", ccxxMessage);
		result.put("occRule", str);
		return result;
	}

	/**
	 * 控制图信息新增
	 * 
	 * @param ControlChartInfomation 新增时需保存的数据
	 * @author huangh
	 * @return Map<String, Object>
	 */
	@Override
	public Map<String, Object> addControlChartMessage(ControlChartInfomation controlChartInfomation) {
		Map<String, Object> result = new HashMap<>();
		Map<String, Object> param = new HashMap<>();

		param.put("kztxxNumber", controlChartInfomation.getKztxxNumber());
		List<ControlChartInfomation> controlChartInfomations = controlChartInfomationMapper.findByCondition(param);
		if (controlChartInfomations.isEmpty()) {
			controlChartInfomation.setKztxxExtend1(NORMAL_STATE);
			controlChartInfomation.setKztxxExtend2(String.valueOf(Times.getNow()));
			controlChartInfomationMapper.insert(controlChartInfomation);
			ControlChartInfomationHierarchicalInformationRelationship message = new ControlChartInfomationHierarchicalInformationRelationship();
			message.setKztxxccglControlChartId(controlChartInfomation.getKztxxId());
			controlChartRelationshipMapper.insert(message);
			result.put("success", SUCCESS_CODE);
			result.put("message", INSERT_SUCCESS);
		} else {
			result.put("success", "9999");
			result.put("message", "已存在相同的编号");
		}

		return result;
	}

	/**
	 * 控制图信息修改/删除
	 * 
	 * @param ControlChartInfomation
	 *            修改时传需要修改的数据，删除只传id
	 * @param state
	 *            状态 0：修改；1：删除
	 * @author huangh
	 * @return Map<String, Object> 
	 */
	@Override
	public Map<String, Object> updateControlChartMessage(ControlChartInfomation controlChartInfomation, Integer state) {
		Map<String, Object> result = new HashMap<>();
		Map<String, Object> param = new HashMap<>();

		// 判断执行的操作是修改还是删除
		if (state == OperationType.UPDATE.getCode().intValue()) {
			// 根据控制图信息的编号查询是否存在同编号的控制图
			param.put("kztxxNumber", controlChartInfomation.getKztxxNumber());
			List<ControlChartInfomation> controlChartInfomations = controlChartInfomationMapper.findByCondition(param);
			for (ControlChartInfomation ControlChartInfomation : controlChartInfomations) {
				if (!ControlChartInfomation.getKztxxId().equals(controlChartInfomation.getKztxxId())) {
					state++;
				}
			}
			// 如果存在同编号的控制图则提示已存在相同编号
			if (state == 0) {
				controlChartInfomation.setKztxxExtend2(String.valueOf(Times.getNow()));
				controlChartInfomationMapper.update(controlChartInfomation);
				result.put("success", SUCCESS_CODE);
				result.put("message", UPDATE_SUCCESS);
			} else {
				result.put("success", "9999");
				result.put("message", "已存在相同编号");
			}
		} else if (state == OperationType.DELETE.getCode().intValue()) {
			// 将控制图信息的记录状态改为2
			controlChartInfomation.setKztxxExtend1(DELETE_STATE);
			controlChartInfomation.setKztxxExtend2(String.valueOf(Times.getNow()));
			controlChartInfomationMapper.update(controlChartInfomation);
			result.put("success", SUCCESS_CODE);
			result.put("message", DELETE_SUCCESS);
		}

		return result;
	}

}
