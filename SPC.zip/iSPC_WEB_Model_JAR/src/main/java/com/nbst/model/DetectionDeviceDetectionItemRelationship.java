package com.nbst.model;

public class DetectionDeviceDetectionItemRelationship {
	private Integer jcsbjcxglId;
	// 检测设备id
	private Integer jcsbjcxglDetectionDeviceId;
	// 检测项id
	private Integer jcsbjcxglDetectionItemId;
	// 状态 1：正常 2：已删除
	private String jcsbjcxglExtend1="1";

	private String jcsbjcxglExtend2;

	private String jcsbjcxglExtend3;

	private String jcsbjcxglExtend4;

	private String jcsbjcxglExtend5;

	public Integer getJcsbjcxglId() {
		return jcsbjcxglId;
	}

	public void setJcsbjcxglId(Integer jcsbjcxglId) {
		this.jcsbjcxglId = jcsbjcxglId;
	}

	public Integer getJcsbjcxglDetectionDeviceId() {
		return jcsbjcxglDetectionDeviceId;
	}

	public void setJcsbjcxglDetectionDeviceId(Integer jcsbjcxglDetectionDeviceId) {
		this.jcsbjcxglDetectionDeviceId = jcsbjcxglDetectionDeviceId;
	}

	public Integer getJcsbjcxglDetectionItemId() {
		return jcsbjcxglDetectionItemId;
	}

	public void setJcsbjcxglDetectionItemId(Integer jcsbjcxglDetectionItemId) {
		this.jcsbjcxglDetectionItemId = jcsbjcxglDetectionItemId;
	}

	public String getJcsbjcxglExtend1() {
		return jcsbjcxglExtend1;
	}

	public void setJcsbjcxglExtend1(String jcsbjcxglExtend1) {
		this.jcsbjcxglExtend1 = jcsbjcxglExtend1 == null ? null : jcsbjcxglExtend1.trim();
	}

	public String getJcsbjcxglExtend2() {
		return jcsbjcxglExtend2;
	}

	public void setJcsbjcxglExtend2(String jcsbjcxglExtend2) {
		this.jcsbjcxglExtend2 = jcsbjcxglExtend2 == null ? null : jcsbjcxglExtend2.trim();
	}

	public String getJcsbjcxglExtend3() {
		return jcsbjcxglExtend3;
	}

	public void setJcsbjcxglExtend3(String jcsbjcxglExtend3) {
		this.jcsbjcxglExtend3 = jcsbjcxglExtend3 == null ? null : jcsbjcxglExtend3.trim();
	}

	public String getJcsbjcxglExtend4() {
		return jcsbjcxglExtend4;
	}

	public void setJcsbjcxglExtend4(String jcsbjcxglExtend4) {
		this.jcsbjcxglExtend4 = jcsbjcxglExtend4 == null ? null : jcsbjcxglExtend4.trim();
	}

	public String getJcsbjcxglExtend5() {
		return jcsbjcxglExtend5;
	}

	public void setJcsbjcxglExtend5(String jcsbjcxglExtend5) {
		this.jcsbjcxglExtend5 = jcsbjcxglExtend5 == null ? null : jcsbjcxglExtend5.trim();
	}

	@Override
	public String toString() {
		return "DetectionDeviceDetectionItemRelationship [jcsbjcxglId=" + jcsbjcxglId + ", jcsbjcxglDetectionDeviceId="
				+ jcsbjcxglDetectionDeviceId + ", jcsbjcxglDetectionItemId=" + jcsbjcxglDetectionItemId
				+ ", jcsbjcxglExtend1=" + jcsbjcxglExtend1 + ", jcsbjcxglExtend2=" + jcsbjcxglExtend2
				+ ", jcsbjcxglExtend3=" + jcsbjcxglExtend3 + ", jcsbjcxglExtend4=" + jcsbjcxglExtend4
				+ ", jcsbjcxglExtend5=" + jcsbjcxglExtend5 + "]";
	}

}