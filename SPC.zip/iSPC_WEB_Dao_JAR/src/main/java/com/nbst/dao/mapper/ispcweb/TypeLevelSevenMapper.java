package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.TypeLevelSeven;

public interface TypeLevelSevenMapper {
	int delete(Integer cclxsevenId);

	int insert(TypeLevelSeven record);

	TypeLevelSeven findById(Integer cclxsevenId);

	int update(TypeLevelSeven record);

	List<TypeLevelSeven> findByCondition(Map<String, Object> map);

	int count(Map<String, Object> map);
}