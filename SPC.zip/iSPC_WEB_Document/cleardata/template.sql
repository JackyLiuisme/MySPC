delete from device_history_production_num where LSCL_SB_CODE='deviceCode' and LSCL_DATE=clearDate;
delete from device_production_circle where SCZQ_SB_CODE='deviceCode' and SCZQ_DATE=clearDate;
delete from device_real_production where SSSC_SB_CODE='deviceCode' and SSSC_START_TIME=clearDate;
delete from device_real_state where SSZT_SB_CODE='deviceCode' and SSZT_START_TIME=clearDate;
delete from device_state_scale where ZTBL_SB_CODE='deviceCode' and ZTBL_DATE=clearDate;
delete from device_warning_count_record where GJS_SB_CODE='deviceCode' and GJS_DATE=clearDate;
delete from device_warning_record where GJJL_SB_CODE='deviceCode' and GJJL_END_TIME>clearDate and GJJL_START_TIME<clearDate+86400000;