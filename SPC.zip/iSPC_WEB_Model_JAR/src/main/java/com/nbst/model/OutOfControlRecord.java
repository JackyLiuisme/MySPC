package com.nbst.model;

public class OutOfControlRecord {
	private Integer skjlId;
	// 对应的控制图信息id
    private Integer skjlControlChartId;
	// 对应的检测数据id
	private Integer skjlDetectionDataId;
	public Integer getSkjlControlChartId() {
		return skjlControlChartId;
	}

	public void setSkjlControlChartId(Integer skjlControlChartId) {
		this.skjlControlChartId = skjlControlChartId;
	}

	// 失控原因
	private String skjlReason;
	// 处理措施
	private String skjlStep;
	// 处理人id
	private Integer skjlManagePersonId;
	// 处理时间
	private Long skjlManageTime;
	// 审核状态
	private Integer skjlAuditState;
	// 审核结果
	private String skjlAuditResult;
	// 审核描述
	private String skjlAuditDescribe;
	// 审核人id
	private Integer skjlAuditPersionId;
	// 审核时间
	private Long skjlAuditTime;

	private String skjlExtend1;

	private String skjlExtend2;

	private String skjlExtend3;

	private String skjlExtend4;

	private String skjlExtend5;

	public Integer getSkjlId() {
		return skjlId;
	}

	public void setSkjlId(Integer skjlId) {
		this.skjlId = skjlId;
	}

	

	public Integer getSkjlDetectionDataId() {
		return skjlDetectionDataId;
	}

	public void setSkjlDetectionDataId(Integer skjlDetectionDataId) {
		this.skjlDetectionDataId = skjlDetectionDataId;
	}

	public String getSkjlReason() {
		return skjlReason;
	}

	public void setSkjlReason(String skjlReason) {
		this.skjlReason = skjlReason == null ? null : skjlReason.trim();
	}

	public String getSkjlStep() {
		return skjlStep;
	}

	public void setSkjlStep(String skjlStep) {
		this.skjlStep = skjlStep == null ? null : skjlStep.trim();
	}

	public Integer getSkjlManagePersonId() {
		return skjlManagePersonId;
	}

	public void setSkjlManagePersonId(Integer skjlManagePersonId) {
		this.skjlManagePersonId = skjlManagePersonId;
	}

	public Long getSkjlManageTime() {
		return skjlManageTime;
	}

	public void setSkjlManageTime(Long skjlManageTime) {
		this.skjlManageTime = skjlManageTime;
	}

	public Integer getSkjlAuditState() {
		return skjlAuditState;
	}

	public void setSkjlAuditState(Integer skjlAuditState) {
		this.skjlAuditState = skjlAuditState;
	}

	public String getSkjlAuditResult() {
		return skjlAuditResult;
	}

	public void setSkjlAuditResult(String skjlAuditResult) {
		this.skjlAuditResult = skjlAuditResult == null ? null : skjlAuditResult.trim();
	}

	public String getSkjlAuditDescribe() {
		return skjlAuditDescribe;
	}

	public void setSkjlAuditDescribe(String skjlAuditDescribe) {
		this.skjlAuditDescribe = skjlAuditDescribe == null ? null : skjlAuditDescribe.trim();
	}

	public Integer getSkjlAuditPersionId() {
		return skjlAuditPersionId;
	}

	public void setSkjlAuditPersionId(Integer skjlAuditPersionId) {
		this.skjlAuditPersionId = skjlAuditPersionId;
	}

	public Long getSkjlAuditTime() {
		return skjlAuditTime;
	}

	public void setSkjlAuditTime(Long skjlAuditTime) {
		this.skjlAuditTime = skjlAuditTime;
	}

	public String getSkjlExtend1() {
		return skjlExtend1;
	}

	public void setSkjlExtend1(String skjlExtend1) {
		this.skjlExtend1 = skjlExtend1 == null ? null : skjlExtend1.trim();
	}

	public String getSkjlExtend2() {
		return skjlExtend2;
	}

	public void setSkjlExtend2(String skjlExtend2) {
		this.skjlExtend2 = skjlExtend2 == null ? null : skjlExtend2.trim();
	}

	public String getSkjlExtend3() {
		return skjlExtend3;
	}

	public void setSkjlExtend3(String skjlExtend3) {
		this.skjlExtend3 = skjlExtend3 == null ? null : skjlExtend3.trim();
	}

	public String getSkjlExtend4() {
		return skjlExtend4;
	}

	public void setSkjlExtend4(String skjlExtend4) {
		this.skjlExtend4 = skjlExtend4 == null ? null : skjlExtend4.trim();
	}

	public String getSkjlExtend5() {
		return skjlExtend5;
	}

	public void setSkjlExtend5(String skjlExtend5) {
		this.skjlExtend5 = skjlExtend5 == null ? null : skjlExtend5.trim();
	}

	@Override
	public String toString() {
		return "OutOfControlRecord [skjlId=" + skjlId + ", skjlControlChartId=" + skjlControlChartId
				+ ", skjlDetectionDataId=" + skjlDetectionDataId + ", skjlReason=" + skjlReason + ", skjlStep="
				+ skjlStep + ", skjlManagePersonId=" + skjlManagePersonId + ", skjlManageTime=" + skjlManageTime
				+ ", skjlAuditState=" + skjlAuditState + ", skjlAuditResult=" + skjlAuditResult + ", skjlAuditDescribe="
				+ skjlAuditDescribe + ", skjlAuditPersionId=" + skjlAuditPersionId + ", skjlAuditTime=" + skjlAuditTime
				+ ", skjlExtend1=" + skjlExtend1 + ", skjlExtend2=" + skjlExtend2 + ", skjlExtend3=" + skjlExtend3
				+ ", skjlExtend4=" + skjlExtend4 + ", skjlExtend5=" + skjlExtend5 + "]";
	}


}