package com.nbst.service.Impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nbst.dao.mapper.ispcweb.TypeLevelEightMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelFiveMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelFourMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelNameMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelNineMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelOneMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelSevenMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelSixMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelThreeMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelTwoMapper;
import com.nbst.model.ControlChartInfomationHierarchicalInformationRelationship;
import com.nbst.service.IControlChartHeadDataService;

import groovy.util.logging.Slf4j;

/**
 * 表头数据查询
 * 
 * @param ControlChartInfomationHierarchicalInformationRelationship 层次信息
 * @author lijiajun
 * @return
 */
@Slf4j
@Service
@Transactional
public class ControlChartHeadDataServiceImpl implements IControlChartHeadDataService {
	@Autowired
	TypeLevelOneMapper oneMapper;
	@Autowired
	TypeLevelTwoMapper twoMapper;
	@Autowired
	TypeLevelThreeMapper threeMapper;
	@Autowired
	TypeLevelFourMapper fourMapper;
	@Autowired
	TypeLevelFiveMapper fiveMapper;
	@Autowired
	TypeLevelSixMapper sixMapper;
	@Autowired
	TypeLevelSevenMapper sevenMapper;
	@Autowired
	TypeLevelEightMapper eightMapper;
	@Autowired
	TypeLevelNineMapper nineMapper;
	@Autowired
	TypeLevelNameMapper nameMapper;

	@Override
	public Map<String, Object> updateControlChartHeadData(
			ControlChartInfomationHierarchicalInformationRelationship controlChartInfomationHierarchicalInformationRelationship) {
		Map<String, Object> returnmap = new HashMap<>();
		Map<String, Map<String, Object>> list = new HashMap<>();
		if (controlChartInfomationHierarchicalInformationRelationship.getKztxxccglTypeLevelOneState() == 2) {
			Map<String, Object> map1 = new HashMap<>();
			String name = nameMapper.findById(1).getCcmcName();
			map1.put("name", name);
			Integer id = controlChartInfomationHierarchicalInformationRelationship.getKztxxccglTypeLevelOneId();
			map1.put("id", id);
			String value = oneMapper.findById(id).getCclxoneName();
			map1.put("value", value);
			list.put("level1", map1);
		}
		if (controlChartInfomationHierarchicalInformationRelationship.getKztxxccglTypeLevelTwoState() == 2) {
			Map<String, Object> map1 = new HashMap<>();
			String name = nameMapper.findById(1).getCcmcName();
			map1.put("name", name);
			Integer id = controlChartInfomationHierarchicalInformationRelationship.getKztxxccglTypeLevelTwoId();
			map1.put("id", id);
			String value = twoMapper.findById(id).getCclxtwoName();
			map1.put("value", value);
			list.put("level1", map1);
		}
		if (controlChartInfomationHierarchicalInformationRelationship.getKztxxccglTypeLevelThreeState() == 2) {
			Map<String, Object> map1 = new HashMap<>();
			String name = nameMapper.findById(1).getCcmcName();
			map1.put("name", name);
			Integer id = controlChartInfomationHierarchicalInformationRelationship.getKztxxccglTypeLevelThreeId();
			map1.put("id", id);
			String value = threeMapper.findById(id).getCclxthreeName();
			map1.put("value", value);
			list.put("level1", map1);
		}
		if (controlChartInfomationHierarchicalInformationRelationship.getKztxxccglTypeLevelFourState() == 2) {
			Map<String, Object> map1 = new HashMap<>();
			String name = nameMapper.findById(1).getCcmcName();
			map1.put("name", name);
			Integer id = controlChartInfomationHierarchicalInformationRelationship.getKztxxccglTypeLevelFourId();
			map1.put("id", id);
			String value = fourMapper.findById(id).getCclxfourName();
			map1.put("value", value);
			list.put("level1", map1);
		}
		if (controlChartInfomationHierarchicalInformationRelationship.getKztxxccglTypeLevelFiveState() == 2) {
			Map<String, Object> map1 = new HashMap<>();
			String name = nameMapper.findById(1).getCcmcName();
			map1.put("name", name);
			Integer id = controlChartInfomationHierarchicalInformationRelationship.getKztxxccglTypeLevelFiveId();
			map1.put("id", id);
			String value = fiveMapper.findById(id).getCclxfiveName();
			map1.put("value", value);
			list.put("level1", map1);
		}
		if (controlChartInfomationHierarchicalInformationRelationship.getKztxxccglTypeLevelSixState() == 2) {
			Map<String, Object> map1 = new HashMap<>();
			String name = nameMapper.findById(1).getCcmcName();
			map1.put("name", name);
			Integer id = controlChartInfomationHierarchicalInformationRelationship.getKztxxccglTypeLevelSixId();
			map1.put("id", id);
			String value = sixMapper.findById(id).getCclxsixName();
			map1.put("value", value);
			list.put("level1", map1);
		}
		if (controlChartInfomationHierarchicalInformationRelationship.getKztxxccglTypeLevelSevenState() == 2) {
			Map<String, Object> map1 = new HashMap<>();
			String name = nameMapper.findById(1).getCcmcName();
			map1.put("name", name);
			Integer id = controlChartInfomationHierarchicalInformationRelationship.getKztxxccglTypeLevelSevenId();
			map1.put("id", id);
			String value = sevenMapper.findById(id).getCclxsevenName();
			map1.put("value", value);
			list.put("level1", map1);
		}
		if (controlChartInfomationHierarchicalInformationRelationship.getKztxxccglTypeLevelEightState() == 2) {
			Map<String, Object> map1 = new HashMap<>();
			String name = nameMapper.findById(1).getCcmcName();
			map1.put("name", name);
			Integer id = controlChartInfomationHierarchicalInformationRelationship.getKztxxccglTypeLevelEightId();
			map1.put("id", id);
			String value = eightMapper.findById(id).getCclxeightName();
			map1.put("value", value);
			list.put("level1", map1);
		}
		if (controlChartInfomationHierarchicalInformationRelationship.getKztxxccglTypeLevelNineState() == 2) {
			Map<String, Object> map1 = new HashMap<>();
			String name = nameMapper.findById(1).getCcmcName();
			map1.put("name", name);
			Integer id = controlChartInfomationHierarchicalInformationRelationship.getKztxxccglTypeLevelNineId();
			map1.put("id", id);
			String value = nineMapper.findById(id).getCclxnineName();
			map1.put("value", value);
			list.put("level1", map1);
		}
		returnmap.put("code", "0000");
		returnmap.put("message", "查找成功");
		returnmap.put("rows", list);
		return returnmap;

	}

}
