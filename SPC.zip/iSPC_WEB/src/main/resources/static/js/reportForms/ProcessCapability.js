function setting(){
	$("#myModal").modal('show');
}

showTree();
function showTree(){
	//配置树形
	var setting = {
		async : {
			enable : true,
	//			url : zTreeUrl(),
	//		    type : "GET",
	//			dataFilter : filter
		},
		view : {
			selectedMulti : false,
			showIcon : false,
		    fontCss : {color:"black"}
		},
		edit : {
			enable : true,
			showRemoveBtn : false,
			showRenameBtn : false
		},
		data : {
			/*
			 * keep: { parent:true, leaf:true },
			 */
			simpleData : {
				enable : true,
			}
		},
		callback : {
//			onClick : onClick,
//			onAsyncSuccess: zTreeOnAsyncSuccess
		}
	};
	var data=[
		{id:1,pId:0,name:"xxxxSPC系统"},
		{id:2,pId:1,name:"分支1"},
		{id:3,pId:1,name:"分支2"},
		{id:4,pId:1,name:"分支3"},
		{id:5,pId:1,name:"分支4"},
		{id:5,pId:1,name:"分支4"},
		{id:5,pId:1,name:"分支4"},
		{id:5,pId:1,name:"分支4"},
		{id:5,pId:1,name:"分支4"},
		{id:5,pId:1,name:"分支4"},
		{id:5,pId:1,name:"分支4"},
		{id:5,pId:1,name:"分支4"},
		{id:5,pId:1,name:"分支4"},
		{id:5,pId:1,name:"分支4"},
		{id:5,pId:1,name:"分支4"},
		{id:5,pId:1,name:"分支4"},
		{id:5,pId:1,name:"分支4"},
		{id:5,pId:1,name:"分支4"},
		{id:5,pId:1,name:"分支4"},
		
	]
	$.fn.zTree.init($("#menu"), setting, data);
	var treeObj = $.fn.zTree.getZTreeObj("menu");
	treeObj.expandAll(true);
}

var flag=1;

function up(){
	$("#sc"+(flag-1)).show().siblings().hide();
	flag--;
}

function down(){
	$("#sc"+(flag+1)).show().siblings().hide();	
	flag++;
}



showTable();
function showTable() {
	$('#table').bootstrapTable('destroy').bootstrapTable({
//		url : subURL('equipmentCapacity/search.action'), //请求后台的URL（*）  
		dataType:'jsonp',
		striped : false, // 是否显示行间隔色
		pagination : true, // 是否显示分页（*）
		sortable : false, // 是否启用排序
		sortOrder : "asc", // 排序方式
        toolbar:"#toolbar",
		pageNumber : 1, // 初始化加载第一页，默认第一页
		pageSize : 10, // 每页的记录行数（*）
		pageList : [ 10, 25, 50, 100 ], // 可供选择的每页的行数（*）
		strictSearch : true,
		clickToSelect : true, // 是否启用点击选中行
		height : 512, // 行高，如果没有设置height属性，表格自动根据记录条数觉得表格高度
		columns : [ 
      {field : 'd1',title : '控制组名称',align:"center"},	
      {field : 'd2',title : '检测项目',align:"center"},
       {field : 'd2',title : '产品型号',align:"center"}, 
       {field : 'd3',title : '产品名称',align:"center"}, 
       {field : 'd4',title : '产线',align:"center"}, 
       {field : 'd5',title : '班次',align:"center"}, 
       {field : 'd6',title : 'Cpk',align:"center"}, 
       {field : 'd7',title : 'Cp',align:"center"}, 
       {field : 'd7',title : 'Cpl',align:"center"}, 
       {field : 'd8',title : 'CPU',align:"center"}, 
       {field : 'd9',title : 'Ppk',align:"center"}, 
       {field : 'd10',title : 'Pp',align:"center"}, 
       {field : 'd11',title : 'PPL',align:"center"}, 
       {field : 'd12',title : 'Ca',align:"center"}, 
       {field : 'd13',title : '平均值',align:"center"}, 
       {field : 'd14',title : '极差值',align:"center"}, 
       {field : 'd15',title : '标准差（整体）',align:"center"}, 
		{field : 'd16',title : '标准差（组内）',align:"center"},		
		{field : 'd17',title : '最大值',align:"center"},		
		{field : 'd18',title : '最小值',align:"center"},		
		{field : 'd19',title : '记录数',align:"center"},		
		],
		onLoadSuccess : function(data) {

		}
	});
	var data=[
			{
				"d1":"\太友科技SPC系统\参考案例（以工序顺序构建）\计量型检测\工序-04",
				"d2":"参数D",
				"d3":"产品型号-1",
				"d4":"产品-01",
				"d5":"产线#01",
				"d6":"丙班",
				"d7":"1.06",
				"d8":"1.06",
				"d9":"1.15",
				"d10":"0.96",
				"d11":"0.96",
				"d12":"0.95",
				"d13":"0.968",
				"d14":"0.987",
				"d15":"0.154",
				"d16":"0.258",
				"d17":"0.952",
				"d18":"0.26",
				"d19":"12"
			}

		]
	$('#table').bootstrapTable('load',data);
};