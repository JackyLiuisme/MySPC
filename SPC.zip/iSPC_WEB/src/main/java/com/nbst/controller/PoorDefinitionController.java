package com.nbst.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nbst.comnutil.AppUtil;
import com.nbst.model.PoorDefinition;
import com.nbst.service.IPoorDefinitionService;

import groovy.util.logging.Slf4j;

@Controller
@CrossOrigin
@Slf4j
@RequestMapping("/poorDefinition")
public class PoorDefinitionController {
	
	@Autowired
	private IPoorDefinitionService poorDefinitionService;
	
	/**
	 * 添加不良定义接口
	 * @param pd
	 * @return
	 */
	@RequestMapping(value = "/add.action", method = RequestMethod.POST)
	@ResponseBody
	public Object addPoorDefnition(PoorDefinition pd) {
		return AppUtil.conversionJsonp(poorDefinitionService.addPoorDefinition(pd));
	}
	
	/**
	 * 查询不良定义接口
	 * @param limit
	 * @param offset
	 * @return
	 */
	@RequestMapping(value = "/search.action", method = RequestMethod.GET)
	@ResponseBody
	public Object searchPoorDefnition(Integer limit,Integer offset) {
		return AppUtil.conversionJsonp(poorDefinitionService.searchPoorDefinition(limit,offset));
	}
	
	/**
	 * 修改或删除不良定义接口
	 * @param pd
	 * @return
	 */
	@RequestMapping(value = "/update.action", method = RequestMethod.POST)
	@ResponseBody
	public Object updatePoorDefnition(PoorDefinition pd,Integer state) {
		return AppUtil.conversionJsonp(poorDefinitionService.updatePoorDefinition(pd,state));
	}
	
}
