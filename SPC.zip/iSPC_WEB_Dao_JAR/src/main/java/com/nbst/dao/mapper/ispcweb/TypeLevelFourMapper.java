package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.TypeLevelFour;

public interface TypeLevelFourMapper {
	int delete(Integer cclxfourId);

	int insert(TypeLevelFour record);

	TypeLevelFour findById(Integer cclxfourId);

	int update(TypeLevelFour record);

	List<TypeLevelFour> findByCondition(Map<String, Object> map);

	int count(Map<String, Object> map);
}