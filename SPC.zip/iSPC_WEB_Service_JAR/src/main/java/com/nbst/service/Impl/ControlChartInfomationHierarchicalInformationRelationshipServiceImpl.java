package com.nbst.service.Impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nbst.dao.mapper.ispcweb.ControlChartInfomationHierarchicalInformationRelationshipMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelEightMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelFiveMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelFourMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelNameMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelNineMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelOneMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelSevenMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelSixMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelThreeMapper;
import com.nbst.dao.mapper.ispcweb.TypeLevelTwoMapper;
import com.nbst.model.ControlChartInfomationHierarchicalInformationRelationship;
import com.nbst.model.Grouping;
import com.nbst.model.TypeLevelName;
import com.nbst.model.User;
import com.nbst.service.IControlChartInfomationHierarchicalInformationRelationshipService;

import groovy.util.logging.Slf4j;

/**
 * @author yangl
 *
 */
@Slf4j
@Service
@Transactional
public class ControlChartInfomationHierarchicalInformationRelationshipServiceImpl
		implements IControlChartInfomationHierarchicalInformationRelationshipService {
	@Autowired
	ControlChartInfomationHierarchicalInformationRelationshipMapper relationshipMapper;
	@Autowired
	TypeLevelOneMapper oneMapper;
	@Autowired
	TypeLevelTwoMapper twoMapper;
	@Autowired
	TypeLevelThreeMapper threeMapper;
	@Autowired
	TypeLevelFourMapper fourMapper;
	@Autowired
	TypeLevelFiveMapper fiveMapper;
	@Autowired
	TypeLevelSixMapper sixMapper;
	@Autowired
	TypeLevelSevenMapper sevenMapper;
	@Autowired
	TypeLevelEightMapper eightMapper;
	@Autowired
	TypeLevelNineMapper nineMapper;
	@Autowired
	TypeLevelNameMapper nameMapper;

	/**
	 * 控制图层次信息关联修改
	 * 
	 * @param relationship
	 * @return
	 */
	@Override
	public Object alterRelationship(ControlChartInfomationHierarchicalInformationRelationship relationship) {
		Map<String, Object> resultMap = new HashMap<>();

		int flag = relationshipMapper.update(relationship);
		if (flag > 0) {
			resultMap.put("message", "修改成功");
			resultMap.put("code", "0000");
		} else {
			resultMap.put("message", "修改失败");
			resultMap.put("code", "9994");
		}
		return resultMap;
	}

	/**
	 * 控制图层次信息关联查询
	 * 
	 * @param controlChartId
	 * @return
	 */
	@Override
	public Object searchRelationship(Integer controlChartId) {
		Map<String, Object> resultMap = new HashMap<>();
		Map<String, Object> conditionMap = new HashMap<>();

		conditionMap.put("kztxxccglControlChartId", controlChartId);
		
		ControlChartInfomationHierarchicalInformationRelationship relation=relationshipMapper.findByCondition(conditionMap).get(0);
		
		Map<String,Map<String,Object>>list=new HashMap<>();
		
		//默认层次数据类型名的id是从1到9
		Map<String,Object>map1=new HashMap<>();
		String name=nameMapper.findById(1).getCcmcName();
		map1.put("name", name);
		Integer state=relation.getKztxxccglTypeLevelOneState();
		map1.put("state", state);
		Integer id=relation.getKztxxccglTypeLevelOneId();
		map1.put("id", id);
		String value=oneMapper.findById(id).getCclxoneName();
		map1.put("value", value);
		list.put("level1",map1);
		
		Map<String,Object>map2=new HashMap<>();
		name=nameMapper.findById(2).getCcmcName();
		map2.put("name", name);
		state=relation.getKztxxccglTypeLevelTwoState();
		map2.put("state", state);
		id=relation.getKztxxccglTypeLevelTwoId();
		map2.put("id", id);
		value=twoMapper.findById(id).getCclxtwoName();
		map2.put("value", value);
		list.put("level2",map2);
		
		Map<String,Object>map3=new HashMap<>();
		name=nameMapper.findById(3).getCcmcName();
		map3.put("name", name);
		state=relation.getKztxxccglTypeLevelThreeState();
		map3.put("state", state);
		id=relation.getKztxxccglTypeLevelThreeId();
		map3.put("id", id);
		value=threeMapper.findById(id).getCclxthreeName();
		map3.put("value", value);
		list.put("level3",map3);
		
		Map<String,Object>map4=new HashMap<>();
		name=nameMapper.findById(4).getCcmcName();
		map4.put("name", name);
		state=relation.getKztxxccglTypeLevelFourState();
		map4.put("state", state);
		id=relation.getKztxxccglTypeLevelFourId();
		map4.put("id", id);
		value=fourMapper.findById(id).getCclxfourName();
		map4.put("value", value);
		list.put("level4",map4);
		
		Map<String,Object>map5=new HashMap<>();
		name=nameMapper.findById(5).getCcmcName();
		map5.put("name", name);
		state=relation.getKztxxccglTypeLevelFiveState();
		map5.put("state", state);
		id=relation.getKztxxccglTypeLevelFiveId();
		map5.put("id", id);
		value=fiveMapper.findById(id).getCclxfiveName();
		map5.put("value", value);
		list.put("level5",map5);
		
		Map<String,Object>map6=new HashMap<>();
		name=nameMapper.findById(6).getCcmcName();
		map6.put("name", name);
		state=relation.getKztxxccglTypeLevelSixState();
		map6.put("state", state);
		id=relation.getKztxxccglTypeLevelSixId();
		map6.put("id", id);
		value=sixMapper.findById(id).getCclxsixName();
		map6.put("value", value);
		list.put("level6",map6);
	
		Map<String,Object>map7=new HashMap<>();
		name=nameMapper.findById(7).getCcmcName();
		map7.put("name", name);
		state=relation.getKztxxccglTypeLevelSevenState();
		map7.put("state", state);
		id=relation.getKztxxccglTypeLevelSevenId();
		map7.put("id", id);
		value=sevenMapper.findById(id).getCclxsevenName();
		map7.put("value", value);
		list.put("level7",map7);
		
		Map<String,Object>map8=new HashMap<>();
		name=nameMapper.findById(8).getCcmcName();
		map8.put("name", name);
		state=relation.getKztxxccglTypeLevelEightState();
		map8.put("state", state);
		id=relation.getKztxxccglTypeLevelEightId();
		map8.put("id", id);
		value=eightMapper.findById(id).getCclxeightName();
		map8.put("value", value);
		list.put("level8",map8);
		
		Map<String,Object>map9=new HashMap<>();
		name=nameMapper.findById(9).getCcmcName();
		map9.put("name", name);
		state=relation.getKztxxccglTypeLevelNineState();
		map9.put("state", state);
		id=relation.getKztxxccglTypeLevelNineId();
		map9.put("id", id);
		value=nineMapper.findById(id).getCclxnineName();
		map9.put("value", value);
		list.put("level9",map9);
	
		resultMap.put("code", "0000");
		resultMap.put("message", "查找成功");
		resultMap.put("rows", list);
		return resultMap;
	}

}
