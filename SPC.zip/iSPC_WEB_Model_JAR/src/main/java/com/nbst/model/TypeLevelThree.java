package com.nbst.model;

public class TypeLevelThree {
	// ID
	private Integer cclxthreeId;
	// 层次类型名称
	private String cclxthreeName;
	//状态
	private String cclxthreeExtend1;

	private String cclxthreeExtend2;

	private String cclxthreeExtend3;

	private String cclxthreeExtend4;

	private String cclxthreeExtend5;

	public Integer getCclxthreeId() {
		return cclxthreeId;
	}

	public void setCclxthreeId(Integer cclxthreeId) {
		this.cclxthreeId = cclxthreeId;
	}

	public String getCclxthreeName() {
		return cclxthreeName;
	}

	public void setCclxthreeName(String cclxthreeName) {
		this.cclxthreeName = cclxthreeName == null ? null : cclxthreeName.trim();
	}

	public String getCclxthreeExtend1() {
		return cclxthreeExtend1;
	}

	public void setCclxthreeExtend1(String cclxthreeExtend1) {
		this.cclxthreeExtend1 = cclxthreeExtend1 == null ? null : cclxthreeExtend1.trim();
	}

	public String getCclxthreeExtend2() {
		return cclxthreeExtend2;
	}

	public void setCclxthreeExtend2(String cclxthreeExtend2) {
		this.cclxthreeExtend2 = cclxthreeExtend2 == null ? null : cclxthreeExtend2.trim();
	}

	public String getCclxthreeExtend3() {
		return cclxthreeExtend3;
	}

	public void setCclxthreeExtend3(String cclxthreeExtend3) {
		this.cclxthreeExtend3 = cclxthreeExtend3 == null ? null : cclxthreeExtend3.trim();
	}

	public String getCclxthreeExtend4() {
		return cclxthreeExtend4;
	}

	public void setCclxthreeExtend4(String cclxthreeExtend4) {
		this.cclxthreeExtend4 = cclxthreeExtend4 == null ? null : cclxthreeExtend4.trim();
	}

	public String getCclxthreeExtend5() {
		return cclxthreeExtend5;
	}

	public void setCclxthreeExtend5(String cclxthreeExtend5) {
		this.cclxthreeExtend5 = cclxthreeExtend5 == null ? null : cclxthreeExtend5.trim();
	}

	@Override
	public String toString() {
		return "TypeLevelThree [cclxthreeId=" + cclxthreeId + ", cclxthreeName=" + cclxthreeName + ", cclxthreeExtend1="
				+ cclxthreeExtend1 + ", cclxthreeExtend2=" + cclxthreeExtend2 + ", cclxthreeExtend3=" + cclxthreeExtend3
				+ ", cclxthreeExtend4=" + cclxthreeExtend4 + ", cclxthreeExtend5=" + cclxthreeExtend5 + "]";
	}
}