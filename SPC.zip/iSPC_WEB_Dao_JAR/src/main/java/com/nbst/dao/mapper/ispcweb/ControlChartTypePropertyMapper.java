package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.ControlChartTypeProperty;

public interface ControlChartTypePropertyMapper {
    int delete(Integer kztsxId);

    int insert(ControlChartTypeProperty record);

    ControlChartTypeProperty findById(Integer kztsxId);

    int update(ControlChartTypeProperty record);

    List<ControlChartTypeProperty> findByCondition(Map<String,Object> map);
    
    int count(Map<String,Object> map);
}