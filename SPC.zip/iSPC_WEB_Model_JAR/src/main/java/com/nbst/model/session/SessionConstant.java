/**
 * 
 */
package com.nbst.model.session;

/**
 * @author hellozjf
 *
 */
public class SessionConstant {

    public static final String SUB_WEB_URL = "SUB_WEB_URL";
    public static final String USER = "USER";
    public static final String COMPANY = "COMPANY";
}
