package com.nbst.model;

public class DetectionDevice {
	private Integer jcsbId;// ID

	private String jcsbName;// 设备名称

	private String jcsbCode;// 设备编号

	private String jcsbIp;// 设备IP

	private String jcsbType;// 设备类型

	private Integer jcsbPictureWjId;// 设备图片文件Id

	private String jcsbFzCode;// 设备分组编号

	private String jcsbLocal;// 设备地理位置

	private String jcsbManufacturer;// 生产厂家

	private String jcsbManufacturerConnection;// 生产厂家联系方式

	private String jcsbDefaultEnergyConsumption;// 理论能耗

	private Integer jcsbDefaultWorkHours;// 理论工作时长

	private Long jcsbDefaultTotalProduction;// 理论总产量

	private Long jcsbInvestmentTime;// 投入时间

	private Long jcsbMaintenanceTime;// 维保时间

	private Long jcsbDeleteTime;// 删除时间

	private Long jcsbUpdateTime;// 修改时间

	private Long jcsbCreateTime;// 创建时间

	private Integer jcsbState=1;// 状态：1，正常；2，已删除

	private Integer jcsbCreateUserId;// 创建用户ID

	private String jcsbSblxName;// 设备类型名称

	private Integer jcsbPrepareWorkingMinutes; // 准备工时（分）

	private Integer jcsbWorkingHoursPerShift; // 每班工作时间（小时）

	private String jcsbPost; // 岗位

	private Long jcsbIconWidth; // 设备图标在车间示意图的宽度

	private Long jcsbIconHeight; // 设备图标在车间示意图的高度

	private Double jcsbRateX; // X轴百分比

	private Double jcsbRateY; // Y轴百分比

	private String jcsbRatePicPrefix; // 设备百分比图片所在文件夹

	private String jcsbModel;// 设备型号

	private String jcsbLevel;// 设备等级

	private String jcsbProductionDate;// 出场日期

	private String jcsbMotorCapacity;// 电机容量

	private String jcsbOldCode;// 设备原编码

	private String jcsbExtend1;// 扩展字段1

	private String jcsbExtend2;// 扩展字段2

	private String jcsbExtend3;// 扩展字段3

	private String jcsbExtend4;// 扩展字段4

	private String jcsbExtend5;// 扩展字段5

	private String jcsbExtend6;// 扩展字段6

	private String jcsbExtend7;// 扩展字段7

	private String jcsbExtend8;// 扩展字段8

	private String jcsbExtend9;// 扩展字段9

	private String jcsbExtend10;// 扩展字段10

	public Integer getJcsbId() {
		return jcsbId;
	}

	public void setJcsbId(Integer jcsbId) {
		this.jcsbId = jcsbId;
	}

	public String getJcsbName() {
		return jcsbName;
	}

	public void setJcsbName(String jcsbName) {
		this.jcsbName = jcsbName;
	}

	public String getJcsbCode() {
		return jcsbCode;
	}

	public void setJcsbCode(String jcsbCode) {
		this.jcsbCode = jcsbCode;
	}

	public String getJcsbIp() {
		return jcsbIp;
	}

	public void setJcsbIp(String jcsbIp) {
		this.jcsbIp = jcsbIp;
	}

	public String getJcsbType() {
		return jcsbType;
	}

	public void setJcsbType(String jcsbType) {
		this.jcsbType = jcsbType;
	}

	public Integer getJcsbPictureWjId() {
		return jcsbPictureWjId;
	}

	public void setJcsbPictureWjId(Integer jcsbPictureWjId) {
		this.jcsbPictureWjId = jcsbPictureWjId;
	}

	public String getJcsbFzCode() {
		return jcsbFzCode;
	}

	public void setJcsbFzCode(String jcsbFzCode) {
		this.jcsbFzCode = jcsbFzCode;
	}

	public String getJcsbLocal() {
		return jcsbLocal;
	}

	public void setJcsbLocal(String jcsbLocal) {
		this.jcsbLocal = jcsbLocal;
	}

	public String getJcsbManufacturer() {
		return jcsbManufacturer;
	}

	public void setJcsbManufacturer(String jcsbManufacturer) {
		this.jcsbManufacturer = jcsbManufacturer;
	}

	public String getJcsbManufacturerConnection() {
		return jcsbManufacturerConnection;
	}

	public void setJcsbManufacturerConnection(String jcsbManufacturerConnection) {
		this.jcsbManufacturerConnection = jcsbManufacturerConnection;
	}

	public String getJcsbDefaultEnergyConsumption() {
		return jcsbDefaultEnergyConsumption;
	}

	public void setJcsbDefaultEnergyConsumption(String jcsbDefaultEnergyConsumption) {
		this.jcsbDefaultEnergyConsumption = jcsbDefaultEnergyConsumption;
	}

	public Integer getJcsbDefaultWorkHours() {
		return jcsbDefaultWorkHours;
	}

	public void setJcsbDefaultWorkHours(Integer jcsbDefaultWorkHours) {
		this.jcsbDefaultWorkHours = jcsbDefaultWorkHours;
	}

	public Long getJcsbDefaultTotalProduction() {
		return jcsbDefaultTotalProduction;
	}

	public void setJcsbDefaultTotalProduction(Long jcsbDefaultTotalProduction) {
		this.jcsbDefaultTotalProduction = jcsbDefaultTotalProduction;
	}

	public Long getJcsbInvestmentTime() {
		return jcsbInvestmentTime;
	}

	public void setJcsbInvestmentTime(Long jcsbInvestmentTime) {
		this.jcsbInvestmentTime = jcsbInvestmentTime;
	}

	public Long getJcsbMaintenanceTime() {
		return jcsbMaintenanceTime;
	}

	public void setJcsbMaintenanceTime(Long jcsbMaintenanceTime) {
		this.jcsbMaintenanceTime = jcsbMaintenanceTime;
	}

	public Long getJcsbDeleteTime() {
		return jcsbDeleteTime;
	}

	public void setJcsbDeleteTime(Long jcsbDeleteTime) {
		this.jcsbDeleteTime = jcsbDeleteTime;
	}

	public Long getJcsbUpdateTime() {
		return jcsbUpdateTime;
	}

	public void setJcsbUpdateTime(Long jcsbUpdateTime) {
		this.jcsbUpdateTime = jcsbUpdateTime;
	}

	public Long getJcsbCreateTime() {
		return jcsbCreateTime;
	}

	public void setJcsbCreateTime(Long jcsbCreateTime) {
		this.jcsbCreateTime = jcsbCreateTime;
	}

	public Integer getJcsbState() {
		return jcsbState;
	}

	public void setJcsbState(Integer jcsbState) {
		this.jcsbState = jcsbState;
	}

	public Integer getJcsbCreateUserId() {
		return jcsbCreateUserId;
	}

	public void setJcsbCreateUserId(Integer jcsbCreateUserId) {
		this.jcsbCreateUserId = jcsbCreateUserId;
	}

	public String getJcsbSblxName() {
		return jcsbSblxName;
	}

	public void setJcsbSblxName(String jcsbSblxName) {
		this.jcsbSblxName = jcsbSblxName;
	}

	public Integer getJcsbPrepareWorkingMinutes() {
		return jcsbPrepareWorkingMinutes;
	}

	public void setJcsbPrepareWorkingMinutes(Integer jcsbPrepareWorkingMinutes) {
		this.jcsbPrepareWorkingMinutes = jcsbPrepareWorkingMinutes;
	}

	public Integer getJcsbWorkingHoursPerShift() {
		return jcsbWorkingHoursPerShift;
	}

	public void setJcsbWorkingHoursPerShift(Integer jcsbWorkingHoursPerShift) {
		this.jcsbWorkingHoursPerShift = jcsbWorkingHoursPerShift;
	}

	public String getJcsbPost() {
		return jcsbPost;
	}

	public void setJcsbPost(String jcsbPost) {
		this.jcsbPost = jcsbPost;
	}

	public Long getJcsbIconWidth() {
		return jcsbIconWidth;
	}

	public void setJcsbIconWidth(Long jcsbIconWidth) {
		this.jcsbIconWidth = jcsbIconWidth;
	}

	public Long getJcsbIconHeight() {
		return jcsbIconHeight;
	}

	public void setJcsbIconHeight(Long jcsbIconHeight) {
		this.jcsbIconHeight = jcsbIconHeight;
	}

	public Double getJcsbRateX() {
		return jcsbRateX;
	}

	public void setJcsbRateX(Double jcsbRateX) {
		this.jcsbRateX = jcsbRateX;
	}

	public Double getJcsbRateY() {
		return jcsbRateY;
	}

	public void setJcsbRateY(Double jcsbRateY) {
		this.jcsbRateY = jcsbRateY;
	}

	public String getJcsbRatePicPrefix() {
		return jcsbRatePicPrefix;
	}

	public void setJcsbRatePicPrefix(String jcsbRatePicPrefix) {
		this.jcsbRatePicPrefix = jcsbRatePicPrefix;
	}

	public String getJcsbModel() {
		return jcsbModel;
	}

	public void setJcsbModel(String jcsbModel) {
		this.jcsbModel = jcsbModel;
	}

	public String getJcsbLevel() {
		return jcsbLevel;
	}

	public void setJcsbLevel(String jcsbLevel) {
		this.jcsbLevel = jcsbLevel;
	}

	public String getJcsbProductionDate() {
		return jcsbProductionDate;
	}

	public void setJcsbProductionDate(String jcsbProductionDate) {
		this.jcsbProductionDate = jcsbProductionDate;
	}

	public String getJcsbMotorCapacity() {
		return jcsbMotorCapacity;
	}

	public void setJcsbMotorCapacity(String jcsbMotorCapacity) {
		this.jcsbMotorCapacity = jcsbMotorCapacity;
	}

	public String getJcsbOldCode() {
		return jcsbOldCode;
	}

	public void setJcsbOldCode(String jcsbOldCode) {
		this.jcsbOldCode = jcsbOldCode;
	}

	public String getJcsbExtend1() {
		return jcsbExtend1;
	}

	public void setJcsbExtend1(String jcsbExtend1) {
		this.jcsbExtend1 = jcsbExtend1;
	}

	public String getJcsbExtend2() {
		return jcsbExtend2;
	}

	public void setJcsbExtend2(String jcsbExtend2) {
		this.jcsbExtend2 = jcsbExtend2;
	}

	public String getJcsbExtend3() {
		return jcsbExtend3;
	}

	public void setJcsbExtend3(String jcsbExtend3) {
		this.jcsbExtend3 = jcsbExtend3;
	}

	public String getJcsbExtend4() {
		return jcsbExtend4;
	}

	public void setJcsbExtend4(String jcsbExtend4) {
		this.jcsbExtend4 = jcsbExtend4;
	}

	public String getJcsbExtend5() {
		return jcsbExtend5;
	}

	public void setJcsbExtend5(String jcsbExtend5) {
		this.jcsbExtend5 = jcsbExtend5;
	}

	public String getJcsbExtend6() {
		return jcsbExtend6;
	}

	public void setJcsbExtend6(String jcsbExtend6) {
		this.jcsbExtend6 = jcsbExtend6;
	}

	public String getJcsbExtend7() {
		return jcsbExtend7;
	}

	public void setJcsbExtend7(String jcsbExtend7) {
		this.jcsbExtend7 = jcsbExtend7;
	}

	public String getJcsbExtend8() {
		return jcsbExtend8;
	}

	public void setJcsbExtend8(String jcsbExtend8) {
		this.jcsbExtend8 = jcsbExtend8;
	}

	public String getJcsbExtend9() {
		return jcsbExtend9;
	}

	public void setJcsbExtend9(String jcsbExtend9) {
		this.jcsbExtend9 = jcsbExtend9;
	}

	public String getJcsbExtend10() {
		return jcsbExtend10;
	}

	public void setJcsbExtend10(String jcsbExtend10) {
		this.jcsbExtend10 = jcsbExtend10;
	}

	@Override
	public String toString() {
		return "DetectionDevice [jcsbId=" + jcsbId + ", jcsbName=" + jcsbName + ", jcsbCode=" + jcsbCode + ", jcsbIp="
				+ jcsbIp + ", jcsbType=" + jcsbType + ", jcsbPictureWjId=" + jcsbPictureWjId + ", jcsbFzCode="
				+ jcsbFzCode + ", jcsbLocal=" + jcsbLocal + ", jcsbManufacturer=" + jcsbManufacturer
				+ ", jcsbManufacturerConnection=" + jcsbManufacturerConnection + ", jcsbDefaultEnergyConsumption="
				+ jcsbDefaultEnergyConsumption + ", jcsbDefaultWorkHours=" + jcsbDefaultWorkHours
				+ ", jcsbDefaultTotalProduction=" + jcsbDefaultTotalProduction + ", jcsbInvestmentTime="
				+ jcsbInvestmentTime + ", jcsbMaintenanceTime=" + jcsbMaintenanceTime + ", jcsbDeleteTime="
				+ jcsbDeleteTime + ", jcsbUpdateTime=" + jcsbUpdateTime + ", jcsbCreateTime=" + jcsbCreateTime
				+ ", jcsbState=" + jcsbState + ", jcsbCreateUserId=" + jcsbCreateUserId + ", jcsbSblxName="
				+ jcsbSblxName + ", jcsbPrepareWorkingMinutes=" + jcsbPrepareWorkingMinutes
				+ ", jcsbWorkingHoursPerShift=" + jcsbWorkingHoursPerShift + ", jcsbPost=" + jcsbPost
				+ ", jcsbIconWidth=" + jcsbIconWidth + ", jcsbIconHeight=" + jcsbIconHeight + ", jcsbRateX=" + jcsbRateX
				+ ", jcsbRateY=" + jcsbRateY + ", jcsbRatePicPrefix=" + jcsbRatePicPrefix + ", jcsbModel=" + jcsbModel
				+ ", jcsbLevel=" + jcsbLevel + ", jcsbProductionDate=" + jcsbProductionDate + ", jcsbMotorCapacity="
				+ jcsbMotorCapacity + ", jcsbOldCode=" + jcsbOldCode + ", jcsbExtend1=" + jcsbExtend1 + ", jcsbExtend2="
				+ jcsbExtend2 + ", jcsbExtend3=" + jcsbExtend3 + ", jcsbExtend4=" + jcsbExtend4 + ", jcsbExtend5="
				+ jcsbExtend5 + ", jcsbExtend6=" + jcsbExtend6 + ", jcsbExtend7=" + jcsbExtend7 + ", jcsbExtend8="
				+ jcsbExtend8 + ", jcsbExtend9=" + jcsbExtend9 + ", jcsbExtend10=" + jcsbExtend10 + "]";
	}


}