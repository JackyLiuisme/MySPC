package com.nbst.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nbst.comnutil.AppUtil;
import com.nbst.model.DetectionItem;
import com.nbst.service.IDetectionItemService;

import groovy.util.logging.Slf4j;

/**
 * @author yangl
 *
 */
@Controller
@RequestMapping("/DetectionItem")
@Slf4j
@CrossOrigin
public class DetectionItemController {
	@Autowired
	private IDetectionItemService detectionItemService;

	/**
	 * 检测项新增
	 * 
	 * @param detectionItem
	 * @return
	 */
	@RequestMapping(value = "/add.action", method = RequestMethod.POST)
	@ResponseBody
	public Object addDetectionItem(DetectionItem detectionItem) {
		return AppUtil.conversionJsonp(detectionItemService.addDetectionItem(detectionItem));
	}

	/**
	 * 检测项修改/删除
	 * 
	 * @param detectionItem
	 * @param state
	 * @return
	 */
	@RequestMapping(value = "/update.action", method = RequestMethod.POST)
	@ResponseBody
	public Object update(DetectionItem detectionItem, Integer state) {
		return AppUtil.conversionJsonp(detectionItemService.alterDetectionItem(detectionItem, state));
	}

	/**
	 * 检测项查询
	 * 
	 * @param limit
	 * @param offset
	 * @return
	 */
	@RequestMapping(value = "/search.action", method = RequestMethod.GET)
	@ResponseBody
	public Object search(Integer limit, Integer offset) {
		return AppUtil.conversionJsonp(detectionItemService.searchDetectionItem(limit, offset));
	}
}
