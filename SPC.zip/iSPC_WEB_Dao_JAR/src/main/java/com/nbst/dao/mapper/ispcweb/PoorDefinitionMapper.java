package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.PoorDefinition;

public interface PoorDefinitionMapper {
    int delete(Integer bldyId);

    int insert(PoorDefinition record);

    PoorDefinition findById(Integer bldyId);

    int update(PoorDefinition record);

    List<PoorDefinition> findByCondition(Map<String,Object> map);
    
    int count(Map<String,Object> map);
}