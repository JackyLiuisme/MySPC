package com.nbst.model;

public class PoorDefinitionControlChartInfomationRelationship {
    private Integer bldykztxxglId;

    private Integer bldykztxxglPoorDefinitionId;

    private String bldykztxxglScope;

    private Integer bldykztxxglControlChartTypeId;

    private Integer bldykztxxglDetectionItemId;

    private String bldykztxxglExtend1;

    private String bldykztxxglExtend2;

    private String bldykztxxglExtend3;

    private String bldykztxxglExtend4;

    private String bldykztxxglExtend5;

    public Integer getBldykztxxglId() {
        return bldykztxxglId;
    }

    public void setBldykztxxglId(Integer bldykztxxglId) {
        this.bldykztxxglId = bldykztxxglId;
    }

    public Integer getBldykztxxglPoorDefinitionId() {
        return bldykztxxglPoorDefinitionId;
    }

    public void setBldykztxxglPoorDefinitionId(Integer bldykztxxglPoorDefinitionId) {
        this.bldykztxxglPoorDefinitionId = bldykztxxglPoorDefinitionId;
    }

    public String getBldykztxxglScope() {
        return bldykztxxglScope;
    }

    public void setBldykztxxglScope(String bldykztxxglScope) {
        this.bldykztxxglScope = bldykztxxglScope == null ? null : bldykztxxglScope.trim();
    }

    public Integer getBldykztxxglControlChartTypeId() {
        return bldykztxxglControlChartTypeId;
    }

    public void setBldykztxxglControlChartTypeId(Integer bldykztxxglControlChartTypeId) {
        this.bldykztxxglControlChartTypeId = bldykztxxglControlChartTypeId;
    }

    public Integer getBldykztxxglDetectionItemId() {
        return bldykztxxglDetectionItemId;
    }

    public void setBldykztxxglDetectionItemId(Integer bldykztxxglDetectionItemId) {
        this.bldykztxxglDetectionItemId = bldykztxxglDetectionItemId;
    }

    public String getBldykztxxglExtend1() {
        return bldykztxxglExtend1;
    }

    public void setBldykztxxglExtend1(String bldykztxxglExtend1) {
        this.bldykztxxglExtend1 = bldykztxxglExtend1 == null ? null : bldykztxxglExtend1.trim();
    }

    public String getBldykztxxglExtend2() {
        return bldykztxxglExtend2;
    }

    public void setBldykztxxglExtend2(String bldykztxxglExtend2) {
        this.bldykztxxglExtend2 = bldykztxxglExtend2 == null ? null : bldykztxxglExtend2.trim();
    }

    public String getBldykztxxglExtend3() {
        return bldykztxxglExtend3;
    }

    public void setBldykztxxglExtend3(String bldykztxxglExtend3) {
        this.bldykztxxglExtend3 = bldykztxxglExtend3 == null ? null : bldykztxxglExtend3.trim();
    }

    public String getBldykztxxglExtend4() {
        return bldykztxxglExtend4;
    }

    public void setBldykztxxglExtend4(String bldykztxxglExtend4) {
        this.bldykztxxglExtend4 = bldykztxxglExtend4 == null ? null : bldykztxxglExtend4.trim();
    }

    public String getBldykztxxglExtend5() {
        return bldykztxxglExtend5;
    }

    public void setBldykztxxglExtend5(String bldykztxxglExtend5) {
        this.bldykztxxglExtend5 = bldykztxxglExtend5 == null ? null : bldykztxxglExtend5.trim();
    }
}