package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.DetectionDevice;

public interface DetectionDeviceMapper {
    int delete(Integer jcsbId);

    int insert(DetectionDevice record);

    DetectionDevice findById(Integer jcsbId);

    int update(DetectionDevice record);

    List<DetectionDevice> findByCondition(Map<String,Object> map);
    
    int count(Map<String,Object> map);
}