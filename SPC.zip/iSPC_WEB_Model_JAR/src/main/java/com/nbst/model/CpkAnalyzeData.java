package com.nbst.model;

public class CpkAnalyzeData {
	private Integer cpkfxsjCpkAnalyzeDiagramId;
	// 所属的控制图信息id
	private Integer cpkfxsjControlChartId;
	// 样本数
	private Integer cpkfxsjSampleCount;
	// 平均值
	private String cpkfxsjAvreageValue;
	// 最大值
	private String cpkfxsjMaximumValue;
	// 最小值
	private String cpkfxsjMinimumValue;
	// 子组大小
	private String cpkfxsjSubgroupSize;
	// 规格上限
	private String cpkfxsjStandardUpperLimit;
	// 目标值
	private String cpkfxsjTargetValue;
	// 规格下限
	private String cpkfxsjSpecificationDownLimit;
	// 标准差（组间）
	private String cpkfxsjStandardDeviationBetwwenGroups;
	// 标准差（组内）
	private String cpkfxsjStandardDeviationInGroups;
	// 标准差（组间）/（组内）
	private String cpkfxsjStandardDeviationBetwwenGroupsDividedByInGroups;
	// 标准差（整体）
	private String cpkfxsjStandardDeviationTotal;
	// 正3倍标准差
	private String cpkfxsjThreeTimesOfStandardDeviation;
	// 负3倍标准差
	private String cpkfxsjThreeNegativeTimesOfStandardDeviation;
	// CPK
	private String cpkfxsjCpk;
	// Cp
	private String cpkfxsjCp;
	// CPL
	private String cpkfxsjCpl;
	// CPU
	private String cpkfxsjCpu;
	// PPK
	private String cpkfxsjPpk;
	// Pp
	private String cpkfxsjPp;
	// PPL
	private String cpkfxsjPpl;
	// PPU
	private String cpkfxsjPpu;
	// Ca
	private String cpkfxsjCa;
	// PPM<LSL（实测）
	private String cpkfxsjPpmLessThanLslMeasured;
	// PPM>USL（实测）
	private String cpkfxsjPpmMoreThanUslMeasured;
	// PPM Total（实测）
	private String cpkfxsjPpmTotalMeasured;
	// PPM<LSL（组内预期）
	private String cpkfxsjPpmLessThanLslEstimatiedInGroup;
	// PPM>USL（组内预期）
	private String cpkfxsjPpmMoreThanUslEstimatiedInGroup;
	// PPM Total（组内预期）
	private String cpkfxsjPpmTotalEstimatedInGroup;
	// PPM<LSL（整体预期）
	private String cpkfxsjPpmLessThanLslEstimatiedTotally;
	// PPM>USL（整体预期)
	private String cpkfxsjPpmMoreThanUslEstimatiedTotally;
	// PPM Total（整体预期)
	private String cpkfxsjPpmTotalEstimatedEstimatiedTotally;

	private String cpkfxsjExtend1;

	private String cpkfxsjExtend2;

	private String cpkfxsjExtend3;

	private String cpkfxsjExtend4;

	private String cpkfxsjExtend5;

	public Integer getCpkfxsjCpkAnalyzeDiagramId() {
		return cpkfxsjCpkAnalyzeDiagramId;
	}

	public void setCpkfxsjCpkAnalyzeDiagramId(Integer cpkfxsjCpkAnalyzeDiagramId) {
		this.cpkfxsjCpkAnalyzeDiagramId = cpkfxsjCpkAnalyzeDiagramId;
	}

	public Integer getCpkfxsjControlChartId() {
		return cpkfxsjControlChartId;
	}

	public void setCpkfxsjControlChartId(Integer cpkfxsjControlChartId) {
		this.cpkfxsjControlChartId = cpkfxsjControlChartId;
	}

	public Integer getCpkfxsjSampleCount() {
		return cpkfxsjSampleCount;
	}

	public void setCpkfxsjSampleCount(Integer cpkfxsjSampleCount) {
		this.cpkfxsjSampleCount = cpkfxsjSampleCount;
	}

	public String getCpkfxsjAvreageValue() {
		return cpkfxsjAvreageValue;
	}

	public void setCpkfxsjAvreageValue(String cpkfxsjAvreageValue) {
		this.cpkfxsjAvreageValue = cpkfxsjAvreageValue == null ? null : cpkfxsjAvreageValue.trim();
	}

	public String getCpkfxsjMaximumValue() {
		return cpkfxsjMaximumValue;
	}

	public void setCpkfxsjMaximumValue(String cpkfxsjMaximumValue) {
		this.cpkfxsjMaximumValue = cpkfxsjMaximumValue == null ? null : cpkfxsjMaximumValue.trim();
	}

	public String getCpkfxsjMinimumValue() {
		return cpkfxsjMinimumValue;
	}

	public void setCpkfxsjMinimumValue(String cpkfxsjMinimumValue) {
		this.cpkfxsjMinimumValue = cpkfxsjMinimumValue == null ? null : cpkfxsjMinimumValue.trim();
	}

	public String getCpkfxsjSubgroupSize() {
		return cpkfxsjSubgroupSize;
	}

	public void setCpkfxsjSubgroupSize(String cpkfxsjSubgroupSize) {
		this.cpkfxsjSubgroupSize = cpkfxsjSubgroupSize == null ? null : cpkfxsjSubgroupSize.trim();
	}

	public String getCpkfxsjStandardUpperLimit() {
		return cpkfxsjStandardUpperLimit;
	}

	public void setCpkfxsjStandardUpperLimit(String cpkfxsjStandardUpperLimit) {
		this.cpkfxsjStandardUpperLimit = cpkfxsjStandardUpperLimit == null ? null : cpkfxsjStandardUpperLimit.trim();
	}

	public String getCpkfxsjTargetValue() {
		return cpkfxsjTargetValue;
	}

	public void setCpkfxsjTargetValue(String cpkfxsjTargetValue) {
		this.cpkfxsjTargetValue = cpkfxsjTargetValue == null ? null : cpkfxsjTargetValue.trim();
	}

	public String getCpkfxsjSpecificationDownLimit() {
		return cpkfxsjSpecificationDownLimit;
	}

	public void setCpkfxsjSpecificationDownLimit(String cpkfxsjSpecificationDownLimit) {
		this.cpkfxsjSpecificationDownLimit = cpkfxsjSpecificationDownLimit == null ? null
				: cpkfxsjSpecificationDownLimit.trim();
	}

	public String getCpkfxsjStandardDeviationBetwwenGroups() {
		return cpkfxsjStandardDeviationBetwwenGroups;
	}

	public void setCpkfxsjStandardDeviationBetwwenGroups(String cpkfxsjStandardDeviationBetwwenGroups) {
		this.cpkfxsjStandardDeviationBetwwenGroups = cpkfxsjStandardDeviationBetwwenGroups == null ? null
				: cpkfxsjStandardDeviationBetwwenGroups.trim();
	}

	public String getCpkfxsjStandardDeviationInGroups() {
		return cpkfxsjStandardDeviationInGroups;
	}

	public void setCpkfxsjStandardDeviationInGroups(String cpkfxsjStandardDeviationInGroups) {
		this.cpkfxsjStandardDeviationInGroups = cpkfxsjStandardDeviationInGroups == null ? null
				: cpkfxsjStandardDeviationInGroups.trim();
	}

	public String getCpkfxsjStandardDeviationBetwwenGroupsDividedByInGroups() {
		return cpkfxsjStandardDeviationBetwwenGroupsDividedByInGroups;
	}

	public void setCpkfxsjStandardDeviationBetwwenGroupsDividedByInGroups(
			String cpkfxsjStandardDeviationBetwwenGroupsDividedByInGroups) {
		this.cpkfxsjStandardDeviationBetwwenGroupsDividedByInGroups = cpkfxsjStandardDeviationBetwwenGroupsDividedByInGroups == null
				? null
				: cpkfxsjStandardDeviationBetwwenGroupsDividedByInGroups.trim();
	}

	public String getCpkfxsjStandardDeviationTotal() {
		return cpkfxsjStandardDeviationTotal;
	}

	public void setCpkfxsjStandardDeviationTotal(String cpkfxsjStandardDeviationTotal) {
		this.cpkfxsjStandardDeviationTotal = cpkfxsjStandardDeviationTotal == null ? null
				: cpkfxsjStandardDeviationTotal.trim();
	}

	public String getCpkfxsjThreeTimesOfStandardDeviation() {
		return cpkfxsjThreeTimesOfStandardDeviation;
	}

	public void setCpkfxsjThreeTimesOfStandardDeviation(String cpkfxsjThreeTimesOfStandardDeviation) {
		this.cpkfxsjThreeTimesOfStandardDeviation = cpkfxsjThreeTimesOfStandardDeviation == null ? null
				: cpkfxsjThreeTimesOfStandardDeviation.trim();
	}

	public String getCpkfxsjThreeNegativeTimesOfStandardDeviation() {
		return cpkfxsjThreeNegativeTimesOfStandardDeviation;
	}

	public void setCpkfxsjThreeNegativeTimesOfStandardDeviation(String cpkfxsjThreeNegativeTimesOfStandardDeviation) {
		this.cpkfxsjThreeNegativeTimesOfStandardDeviation = cpkfxsjThreeNegativeTimesOfStandardDeviation == null ? null
				: cpkfxsjThreeNegativeTimesOfStandardDeviation.trim();
	}

	public String getCpkfxsjCpk() {
		return cpkfxsjCpk;
	}

	public void setCpkfxsjCpk(String cpkfxsjCpk) {
		this.cpkfxsjCpk = cpkfxsjCpk == null ? null : cpkfxsjCpk.trim();
	}

	public String getCpkfxsjCp() {
		return cpkfxsjCp;
	}

	public void setCpkfxsjCp(String cpkfxsjCp) {
		this.cpkfxsjCp = cpkfxsjCp == null ? null : cpkfxsjCp.trim();
	}

	public String getCpkfxsjCpl() {
		return cpkfxsjCpl;
	}

	public void setCpkfxsjCpl(String cpkfxsjCpl) {
		this.cpkfxsjCpl = cpkfxsjCpl == null ? null : cpkfxsjCpl.trim();
	}

	public String getCpkfxsjCpu() {
		return cpkfxsjCpu;
	}

	public void setCpkfxsjCpu(String cpkfxsjCpu) {
		this.cpkfxsjCpu = cpkfxsjCpu == null ? null : cpkfxsjCpu.trim();
	}

	public String getCpkfxsjPpk() {
		return cpkfxsjPpk;
	}

	public void setCpkfxsjPpk(String cpkfxsjPpk) {
		this.cpkfxsjPpk = cpkfxsjPpk == null ? null : cpkfxsjPpk.trim();
	}

	public String getCpkfxsjPp() {
		return cpkfxsjPp;
	}

	public void setCpkfxsjPp(String cpkfxsjPp) {
		this.cpkfxsjPp = cpkfxsjPp == null ? null : cpkfxsjPp.trim();
	}

	public String getCpkfxsjPpl() {
		return cpkfxsjPpl;
	}

	public void setCpkfxsjPpl(String cpkfxsjPpl) {
		this.cpkfxsjPpl = cpkfxsjPpl == null ? null : cpkfxsjPpl.trim();
	}

	public String getCpkfxsjPpu() {
		return cpkfxsjPpu;
	}

	public void setCpkfxsjPpu(String cpkfxsjPpu) {
		this.cpkfxsjPpu = cpkfxsjPpu == null ? null : cpkfxsjPpu.trim();
	}

	public String getCpkfxsjCa() {
		return cpkfxsjCa;
	}

	public void setCpkfxsjCa(String cpkfxsjCa) {
		this.cpkfxsjCa = cpkfxsjCa == null ? null : cpkfxsjCa.trim();
	}

	public String getCpkfxsjPpmLessThanLslMeasured() {
		return cpkfxsjPpmLessThanLslMeasured;
	}

	public void setCpkfxsjPpmLessThanLslMeasured(String cpkfxsjPpmLessThanLslMeasured) {
		this.cpkfxsjPpmLessThanLslMeasured = cpkfxsjPpmLessThanLslMeasured == null ? null
				: cpkfxsjPpmLessThanLslMeasured.trim();
	}

	public String getCpkfxsjPpmMoreThanUslMeasured() {
		return cpkfxsjPpmMoreThanUslMeasured;
	}

	public void setCpkfxsjPpmMoreThanUslMeasured(String cpkfxsjPpmMoreThanUslMeasured) {
		this.cpkfxsjPpmMoreThanUslMeasured = cpkfxsjPpmMoreThanUslMeasured == null ? null
				: cpkfxsjPpmMoreThanUslMeasured.trim();
	}

	public String getCpkfxsjPpmTotalMeasured() {
		return cpkfxsjPpmTotalMeasured;
	}

	public void setCpkfxsjPpmTotalMeasured(String cpkfxsjPpmTotalMeasured) {
		this.cpkfxsjPpmTotalMeasured = cpkfxsjPpmTotalMeasured == null ? null : cpkfxsjPpmTotalMeasured.trim();
	}

	public String getCpkfxsjPpmLessThanLslEstimatiedInGroup() {
		return cpkfxsjPpmLessThanLslEstimatiedInGroup;
	}

	public void setCpkfxsjPpmLessThanLslEstimatiedInGroup(String cpkfxsjPpmLessThanLslEstimatiedInGroup) {
		this.cpkfxsjPpmLessThanLslEstimatiedInGroup = cpkfxsjPpmLessThanLslEstimatiedInGroup == null ? null
				: cpkfxsjPpmLessThanLslEstimatiedInGroup.trim();
	}

	public String getCpkfxsjPpmMoreThanUslEstimatiedInGroup() {
		return cpkfxsjPpmMoreThanUslEstimatiedInGroup;
	}

	public void setCpkfxsjPpmMoreThanUslEstimatiedInGroup(String cpkfxsjPpmMoreThanUslEstimatiedInGroup) {
		this.cpkfxsjPpmMoreThanUslEstimatiedInGroup = cpkfxsjPpmMoreThanUslEstimatiedInGroup == null ? null
				: cpkfxsjPpmMoreThanUslEstimatiedInGroup.trim();
	}

	public String getCpkfxsjPpmTotalEstimatedInGroup() {
		return cpkfxsjPpmTotalEstimatedInGroup;
	}

	public void setCpkfxsjPpmTotalEstimatedInGroup(String cpkfxsjPpmTotalEstimatedInGroup) {
		this.cpkfxsjPpmTotalEstimatedInGroup = cpkfxsjPpmTotalEstimatedInGroup == null ? null
				: cpkfxsjPpmTotalEstimatedInGroup.trim();
	}

	public String getCpkfxsjPpmLessThanLslEstimatiedTotally() {
		return cpkfxsjPpmLessThanLslEstimatiedTotally;
	}

	public void setCpkfxsjPpmLessThanLslEstimatiedTotally(String cpkfxsjPpmLessThanLslEstimatiedTotally) {
		this.cpkfxsjPpmLessThanLslEstimatiedTotally = cpkfxsjPpmLessThanLslEstimatiedTotally == null ? null
				: cpkfxsjPpmLessThanLslEstimatiedTotally.trim();
	}

	public String getCpkfxsjPpmMoreThanUslEstimatiedTotally() {
		return cpkfxsjPpmMoreThanUslEstimatiedTotally;
	}

	public void setCpkfxsjPpmMoreThanUslEstimatiedTotally(String cpkfxsjPpmMoreThanUslEstimatiedTotally) {
		this.cpkfxsjPpmMoreThanUslEstimatiedTotally = cpkfxsjPpmMoreThanUslEstimatiedTotally == null ? null
				: cpkfxsjPpmMoreThanUslEstimatiedTotally.trim();
	}

	public String getCpkfxsjPpmTotalEstimatedEstimatiedTotally() {
		return cpkfxsjPpmTotalEstimatedEstimatiedTotally;
	}

	public void setCpkfxsjPpmTotalEstimatedEstimatiedTotally(String cpkfxsjPpmTotalEstimatedEstimatiedTotally) {
		this.cpkfxsjPpmTotalEstimatedEstimatiedTotally = cpkfxsjPpmTotalEstimatedEstimatiedTotally == null ? null
				: cpkfxsjPpmTotalEstimatedEstimatiedTotally.trim();
	}

	public String getCpkfxsjExtend1() {
		return cpkfxsjExtend1;
	}

	public void setCpkfxsjExtend1(String cpkfxsjExtend1) {
		this.cpkfxsjExtend1 = cpkfxsjExtend1 == null ? null : cpkfxsjExtend1.trim();
	}

	public String getCpkfxsjExtend2() {
		return cpkfxsjExtend2;
	}

	public void setCpkfxsjExtend2(String cpkfxsjExtend2) {
		this.cpkfxsjExtend2 = cpkfxsjExtend2 == null ? null : cpkfxsjExtend2.trim();
	}

	public String getCpkfxsjExtend3() {
		return cpkfxsjExtend3;
	}

	public void setCpkfxsjExtend3(String cpkfxsjExtend3) {
		this.cpkfxsjExtend3 = cpkfxsjExtend3 == null ? null : cpkfxsjExtend3.trim();
	}

	public String getCpkfxsjExtend4() {
		return cpkfxsjExtend4;
	}

	public void setCpkfxsjExtend4(String cpkfxsjExtend4) {
		this.cpkfxsjExtend4 = cpkfxsjExtend4 == null ? null : cpkfxsjExtend4.trim();
	}

	public String getCpkfxsjExtend5() {
		return cpkfxsjExtend5;
	}

	public void setCpkfxsjExtend5(String cpkfxsjExtend5) {
		this.cpkfxsjExtend5 = cpkfxsjExtend5 == null ? null : cpkfxsjExtend5.trim();
	}

	@Override
	public String toString() {
		return "CpkAnalyzeData [cpkfxsjCpkAnalyzeDiagramId=" + cpkfxsjCpkAnalyzeDiagramId + ", cpkfxsjControlChartId="
				+ cpkfxsjControlChartId + ", cpkfxsjSampleCount=" + cpkfxsjSampleCount + ", cpkfxsjAvreageValue="
				+ cpkfxsjAvreageValue + ", cpkfxsjMaximumValue=" + cpkfxsjMaximumValue + ", cpkfxsjMinimumValue="
				+ cpkfxsjMinimumValue + ", cpkfxsjSubgroupSize=" + cpkfxsjSubgroupSize + ", cpkfxsjStandardUpperLimit="
				+ cpkfxsjStandardUpperLimit + ", cpkfxsjTargetValue=" + cpkfxsjTargetValue
				+ ", cpkfxsjSpecificationDownLimit=" + cpkfxsjSpecificationDownLimit
				+ ", cpkfxsjStandardDeviationBetwwenGroups=" + cpkfxsjStandardDeviationBetwwenGroups
				+ ", cpkfxsjStandardDeviationInGroups=" + cpkfxsjStandardDeviationInGroups
				+ ", cpkfxsjStandardDeviationBetwwenGroupsDividedByInGroups="
				+ cpkfxsjStandardDeviationBetwwenGroupsDividedByInGroups + ", cpkfxsjStandardDeviationTotal="
				+ cpkfxsjStandardDeviationTotal + ", cpkfxsjThreeTimesOfStandardDeviation="
				+ cpkfxsjThreeTimesOfStandardDeviation + ", cpkfxsjThreeNegativeTimesOfStandardDeviation="
				+ cpkfxsjThreeNegativeTimesOfStandardDeviation + ", cpkfxsjCpk=" + cpkfxsjCpk + ", cpkfxsjCp="
				+ cpkfxsjCp + ", cpkfxsjCpl=" + cpkfxsjCpl + ", cpkfxsjCpu=" + cpkfxsjCpu + ", cpkfxsjPpk=" + cpkfxsjPpk
				+ ", cpkfxsjPp=" + cpkfxsjPp + ", cpkfxsjPpl=" + cpkfxsjPpl + ", cpkfxsjPpu=" + cpkfxsjPpu
				+ ", cpkfxsjCa=" + cpkfxsjCa + ", cpkfxsjPpmLessThanLslMeasured=" + cpkfxsjPpmLessThanLslMeasured
				+ ", cpkfxsjPpmMoreThanUslMeasured=" + cpkfxsjPpmMoreThanUslMeasured + ", cpkfxsjPpmTotalMeasured="
				+ cpkfxsjPpmTotalMeasured + ", cpkfxsjPpmLessThanLslEstimatiedInGroup="
				+ cpkfxsjPpmLessThanLslEstimatiedInGroup + ", cpkfxsjPpmMoreThanUslEstimatiedInGroup="
				+ cpkfxsjPpmMoreThanUslEstimatiedInGroup + ", cpkfxsjPpmTotalEstimatedInGroup="
				+ cpkfxsjPpmTotalEstimatedInGroup + ", cpkfxsjPpmLessThanLslEstimatiedTotally="
				+ cpkfxsjPpmLessThanLslEstimatiedTotally + ", cpkfxsjPpmMoreThanUslEstimatiedTotally="
				+ cpkfxsjPpmMoreThanUslEstimatiedTotally + ", cpkfxsjPpmTotalEstimatedEstimatiedTotally="
				+ cpkfxsjPpmTotalEstimatedEstimatiedTotally + ", cpkfxsjExtend1=" + cpkfxsjExtend1 + ", cpkfxsjExtend2="
				+ cpkfxsjExtend2 + ", cpkfxsjExtend3=" + cpkfxsjExtend3 + ", cpkfxsjExtend4=" + cpkfxsjExtend4
				+ ", cpkfxsjExtend5=" + cpkfxsjExtend5 + "]";
	}

}