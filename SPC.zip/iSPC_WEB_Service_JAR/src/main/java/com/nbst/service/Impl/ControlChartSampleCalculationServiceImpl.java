package com.nbst.service.Impl;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nbst.service.IControlChartSampleCalculationService;

import groovy.util.logging.Slf4j;

@Slf4j
@Service
@Transactional

public class ControlChartSampleCalculationServiceImpl implements IControlChartSampleCalculationService {
	/**
	 * @author lijiajun
	 * @param jcsjDataSample 样本数据
	 * @return returnmap
	 */
	@Override
	public Map<String, Object> controlChartSampleCalculation(String jcsjDataSample) {
		// 将传入的样本数据按照“，”分割
		String[] StringArray = jcsjDataSample.split(",");
		double[] Array = new double[StringArray.length];
		// 将string类型的StringArray转换成double类型存入 Array
		for (int i = 0; i < StringArray.length; i++) {
			Array[i] = Double.valueOf(StringArray[i]);
		}
		//求样本的和
		double num = 0;
		List<Object> list = new ArrayList<>();
		for (int i = 0; i < StringArray.length; i++) {
			num = num + Array[i];
		}
		// 计算平均值avg
		double avg = num / StringArray.length;
		for (int i = 0; i < StringArray.length; i++) {
			num = (Array[i] - avg) * (Array[i] - avg);
		}
		// 计算标准查dev
		double dev = Math.sqrt(num / StringArray.length);
		// 计算最大值max、最小值min
		double min = Array[0];
		double max = Array[0];
		for (int i = 0; i < StringArray.length; i++) {
			if (min > Array[i]) {
				min = Array[i];
			}
		}
		for (int i = 0; i < StringArray.length; i++) {
			if (max < Array[i]) {
				max = Array[i];
			}
		}
		// 计算极差值range
		double range = max - min;
		//将需要返回的值传入list
		list.add(String.valueOf(avg));
		list.add(String.valueOf(range));
		list.add(String.valueOf(dev));
		list.add(String.valueOf(max));
		list.add(String.valueOf(min));
		//返回
		Map<String, Object> returnmap = new HashMap<>();
		returnmap.put("jcsjControlChartData", list);
		return returnmap;
	}

}
