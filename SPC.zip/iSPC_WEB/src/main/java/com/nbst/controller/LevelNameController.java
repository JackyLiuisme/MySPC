package com.nbst.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nbst.comnutil.AppUtil;
import com.nbst.service.IQueryService;

import groovy.util.logging.Slf4j;

@Controller
@RequestMapping("/type")
@Slf4j
@CrossOrigin
public class LevelNameController {
	@Autowired
	private IQueryService queryService;
	/**
	 * 层次name删除和修改
	 * 
	 * @param id
	 * @param name
	 * @author lijiajun
	 * @return
	 */
	
	@RequestMapping(value = "/update.action", method = RequestMethod.POST)
	@ResponseBody
	public Object updatLevelNameItems(Integer id, String name) {
		return AppUtil.conversionJsonp(queryService.updateLevelNameItems(id, name));
	}
	
	/**
	 * 层次name查詢
	 * @author lijiajun
	 * @return
	 */
	@RequestMapping(value = "/search.action", method = RequestMethod.GET)
	@ResponseBody
	public Object searchLevelNameItems() {
		return AppUtil.conversionJsonp(queryService.searchLevelNameItems());
	}
}
