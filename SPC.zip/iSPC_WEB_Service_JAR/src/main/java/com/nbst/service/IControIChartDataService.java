package com.nbst.service;

import java.util.Map;

import com.nbst.model.DetectionData;

public interface IControIChartDataService {
	/**
	 * 表内数据增加
	 * 
	 * @param detectionData 检测数据项
	 * @author lijiajun
	 */
	Map<String, Object> addControlChartData(DetectionData detectionData);

	/**
	 * 表内数据修改
	 * 
	 * @param detectionData 检测数据项
	 * @author lijiajun
	 */
	Map<String, Object> updateControlChartData(DetectionData detectionData);

	/**
	 * 表内数据查找
	 * 
	 * @param jcsjControlChartId 控制图id
	 * @param jcsjRecordTime     录入时间
	 * @param jcsjExtractTime    抽取时间
	 * @author lijiajun
	 */
	Map<String, Object> searchControlChartData(Integer jcsjControlChartId, Long jcsjRecordTime, Long jcsjExtractTime);

	/**
	 * 表内数据删除
	 * 
	 * @param jcsjId 数据id
	 * @author lijiajun
	 */
	Map<String, Object> deletControlChartData(Integer jcsjId);
}
