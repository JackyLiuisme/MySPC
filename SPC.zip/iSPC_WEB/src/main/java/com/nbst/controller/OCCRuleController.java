package com.nbst.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nbst.comnutil.AppUtil;
import com.nbst.service.IOCCRuleService;

@Controller
@CrossOrigin
@RequestMapping("/OCCRule")
public class OCCRuleController {

	@Autowired
	private IOCCRuleService OCCRuleService;

	/**
	 * 判异规则查询
	 * 
	 * @param id 控制图信息id
	 * @author huangh
	 * @return Object
	 */
	@RequestMapping(value = "/search.action", method = RequestMethod.GET)
	@ResponseBody
	public Object getOCCRule(Integer id) {
		return AppUtil.conversionJsonp(OCCRuleService.getOCCRule(id));
	}

	/**
	 * 修改判异规则
	 * 
	 * @param id 控制图信息id
	 * @param str 关联的判异规则id以及变量名和值
	 * @author huangh
	 * @return Object
	 */
	@RequestMapping(value = "/update.action", method = RequestMethod.POST)
	@ResponseBody
	public Object updateOCCRule(Integer id, String str) {
		return AppUtil.conversionJsonp(OCCRuleService.updateOCCRule(id, str));
	}

}
