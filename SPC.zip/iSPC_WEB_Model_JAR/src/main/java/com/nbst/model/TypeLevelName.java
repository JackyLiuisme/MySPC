package com.nbst.model;

public class TypeLevelName {
	// ID
	private Integer ccmcId;
	// 层次类型名称
	private String ccmcName;
	//状态
	private String ccmcExtend1;

	private String ccmcExtend2;

	private String ccmcExtend3;

	private String ccmcExtend4;

	private String ccmcExtend5;

	public Integer getCcmcId() {
		return ccmcId;
	}

	public void setCcmcId(Integer ccmcId) {
		this.ccmcId = ccmcId;
	}

	public String getCcmcName() {
		return ccmcName;
	}

	public void setCcmcName(String ccmcName) {
		this.ccmcName = ccmcName == null ? null : ccmcName.trim();
	}

	public String getCcmcExtend1() {
		return ccmcExtend1;
	}

	public void setCcmcExtend1(String ccmcExtend1) {
		this.ccmcExtend1 = ccmcExtend1 == null ? null : ccmcExtend1.trim();
	}

	public String getCcmcExtend2() {
		return ccmcExtend2;
	}

	public void setCcmcExtend2(String ccmcExtend2) {
		this.ccmcExtend2 = ccmcExtend2 == null ? null : ccmcExtend2.trim();
	}

	public String getCcmcExtend3() {
		return ccmcExtend3;
	}

	public void setCcmcExtend3(String ccmcExtend3) {
		this.ccmcExtend3 = ccmcExtend3 == null ? null : ccmcExtend3.trim();
	}

	public String getCcmcExtend4() {
		return ccmcExtend4;
	}

	public void setCcmcExtend4(String ccmcExtend4) {
		this.ccmcExtend4 = ccmcExtend4 == null ? null : ccmcExtend4.trim();
	}

	public String getCcmcExtend5() {
		return ccmcExtend5;
	}

	public void setCcmcExtend5(String ccmcExtend5) {
		this.ccmcExtend5 = ccmcExtend5 == null ? null : ccmcExtend5.trim();
	}

	@Override
	public String toString() {
		return "TypeLevelName [ccmcId=" + ccmcId + ", ccmcName=" + ccmcName + ", ccmcExtend1=" + ccmcExtend1
				+ ", ccmcExtend2=" + ccmcExtend2 + ", ccmcExtend3=" + ccmcExtend3 + ", ccmcExtend4=" + ccmcExtend4
				+ ", ccmcExtend5=" + ccmcExtend5 + "]";
	}
}