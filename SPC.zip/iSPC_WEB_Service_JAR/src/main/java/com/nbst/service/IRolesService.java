package com.nbst.service;

import com.nbst.model.Roles;

/**
 * @author yangl
 *
 */
public interface IRolesService {
	// 角色新增
	Object add(Roles role);

	// 角色修改/删除
	Object alter(Roles role, Integer state);

	// 角色查询
	Object search(Integer limit, Integer offset);
}
