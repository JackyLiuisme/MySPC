package com.nbst.model;

public class RunawayProcessingExperience {
	private Integer skcljyId;
	// 失控原因
	private String skcljyReason;
	// 处理措施
	private String skcljyStep;

	private String skcljyExtend1;

	private String skcljyExtend2;

	private String skcljyExtend3;

	private String skcljyExtend4;

	private String skcljyExtend5;

	public Integer getSkcljyId() {
		return skcljyId;
	}

	public void setSkcljyId(Integer skcljyId) {
		this.skcljyId = skcljyId;
	}

	public String getSkcljyReason() {
		return skcljyReason;
	}

	public void setSkcljyReason(String skcljyReason) {
		this.skcljyReason = skcljyReason == null ? null : skcljyReason.trim();
	}

	public String getSkcljyStep() {
		return skcljyStep;
	}

	public void setSkcljyStep(String skcljyStep) {
		this.skcljyStep = skcljyStep == null ? null : skcljyStep.trim();
	}

	public String getSkcljyExtend1() {
		return skcljyExtend1;
	}

	public void setSkcljyExtend1(String skcljyExtend1) {
		this.skcljyExtend1 = skcljyExtend1 == null ? null : skcljyExtend1.trim();
	}

	public String getSkcljyExtend2() {
		return skcljyExtend2;
	}

	public void setSkcljyExtend2(String skcljyExtend2) {
		this.skcljyExtend2 = skcljyExtend2 == null ? null : skcljyExtend2.trim();
	}

	public String getSkcljyExtend3() {
		return skcljyExtend3;
	}

	public void setSkcljyExtend3(String skcljyExtend3) {
		this.skcljyExtend3 = skcljyExtend3 == null ? null : skcljyExtend3.trim();
	}

	public String getSkcljyExtend4() {
		return skcljyExtend4;
	}

	public void setSkcljyExtend4(String skcljyExtend4) {
		this.skcljyExtend4 = skcljyExtend4 == null ? null : skcljyExtend4.trim();
	}

	public String getSkcljyExtend5() {
		return skcljyExtend5;
	}

	public void setSkcljyExtend5(String skcljyExtend5) {
		this.skcljyExtend5 = skcljyExtend5 == null ? null : skcljyExtend5.trim();
	}

	@Override
	public String toString() {
		return "RunawayProcessingExperience [skcljyId=" + skcljyId + ", skcljyReason=" + skcljyReason + ", skcljyStep="
				+ skcljyStep + ", skcljyExtend1=" + skcljyExtend1 + ", skcljyExtend2=" + skcljyExtend2
				+ ", skcljyExtend3=" + skcljyExtend3 + ", skcljyExtend4=" + skcljyExtend4 + ", skcljyExtend5="
				+ skcljyExtend5 + "]";
	}

}