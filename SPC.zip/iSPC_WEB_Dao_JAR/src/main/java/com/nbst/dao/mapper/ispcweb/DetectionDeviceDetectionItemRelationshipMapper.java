package com.nbst.dao.mapper.ispcweb;

import java.util.List;
import java.util.Map;

import com.nbst.model.DetectionDeviceDetectionItemRelationship;

public interface DetectionDeviceDetectionItemRelationshipMapper {
    int delete(Integer jcsbjcxglId);

    int insert(DetectionDeviceDetectionItemRelationship record);

    DetectionDeviceDetectionItemRelationship findById(Integer jcsbjcxglId);

    int update(DetectionDeviceDetectionItemRelationship record);

    List<DetectionDeviceDetectionItemRelationship> findByCondition(Map<String,Object> map);
    
    int count(Map<String,Object> map);
}