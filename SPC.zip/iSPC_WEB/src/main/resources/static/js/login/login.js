var gStorage = window.localStorage;//获取windows本地存储数据

/*
 * @Description: 预加载
 * @param :
 */
$(function(){
	fnReadUserInfo();
});

/*
 * @Description: 获取windows本地存储里的userInfo信息,
 * 				 如果没有存userInfo信息，用户名输入框获得焦点,
 * 				  如果有存userInfo信息，则把用户名、密码等写到页面上
 * @param :
 */
function fnReadUserInfo() {
	var sUserInfo = JSON.parse(gStorage.getItem("userInfo"));//获取windows本地存储里的userInfo信息
	if (sUserInfo == undefined || sUserInfo == null) {
		$("#username").focus();
	}else{
		$("#rememberMe").attr("checked", true);
		$("#username").val(sUserInfo.username);
		$("#password").val(sUserInfo.password);
//		$("#i"+$.cookie("systemType")).prop('checked',true);
	}
}

/*
 * @Description: 登录页面回车事件
 * @param :
 */
$(document).on("keydown",function(e) {
	if (event.keyCode == "13") {// keyCode=13是回车键
		$("#denglu").click();
	}
});

/*
 * @Description: 登录按钮点击事件
 * @param :
 */
$("#denglu").click(function(){
	var sUsername = $("#username").val();//获取用户名
	var sPassword = $("#password").val();//获取密码
	//var sType = $("input[name='systemType']:checked").val();//获取选中系统
	if(sUsername == ""){
		setTimeout(function(){
			swal_Tips("用户名不能为空","请输入用户名！");
		}, 100);
	}else if(sPassword == ""){
		setTimeout(function(){
			swal_Tips("密码不能为空","请输入密码！");
		}, 100);
	}else{
		setTimeout(function(){
			$.ajax({
				url :pathUrl("login.action"),
				type : 'POST',
				async : true,
				cache:false,
				dataType : 'JSON',
				data : {
					"account" : sUsername,
					"password" : sPassword
				},
				success : function(data) {
//				console.log(data)
					if (data.code == "0000") {
						/*
						 * 如果勾选了记住密码，则把用户名、密码、勾选状态存入localStorage的userInfo字段里
						 * 如果没有勾选记住密码，则清除localStorage的userInfo键值对
						 */
						if($("#rememberMe").prop("checked")) {
							var oInfo = {
									"rmbUser" : "true",
									"username" : sUsername,
									"password" : sPassword
//									"systemType" : sType
							};
							gStorage.setItem("userInfo",JSON.stringify(oInfo));//存入localStorage的userInfo字段里，存入的数据要是string类型
						}else{
							gStorage.removeItem("userInfo");//localStorage删除userInfo键值对
							//gstorage.clear();//localStorage清除所有内容
						}
						var url = "";
						url = pathUrl("in");
//					if(type == "mes"){
//					}else if(type == "erp"){
//						url = pathUrl("ierp");
//					}else if(type  == "wms"){
//						url = pathUrl("iwms");
//					}
						window.location.href = url;
					} else {
						swal_Tips(data.message);
					}
				},
				error : function(event,xhr,options,exc) {
					console.log(event.status)
					console.log(event.statusText)
					console.log(xhr)
					console.log(options)
					console.log(exc)
					swal_Tips("登录失败！");
				}
			});
		},0);
	}
});