package com.nbst.service;

import java.util.Map;

/**
 * 计算接口
 * 
 * @param jcsjControlChartId 控制图id
 * @param kztxxTypeId        控制图类型id
 * @param kzttjSampleSize    样本容量
 * @author lijiajun
 *
 */
public interface ICalculationService {
	Map<String, Object> calculationChartInfomation(Integer jcsjControlChartId, Integer kztxxTypeId,
			Integer kzttjSampleSize);

}
