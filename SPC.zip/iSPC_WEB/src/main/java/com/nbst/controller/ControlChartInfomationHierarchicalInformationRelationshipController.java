package com.nbst.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nbst.comnutil.AppUtil;
import com.nbst.model.ControlChartInfomationHierarchicalInformationRelationship;
import com.nbst.service.IControlChartInfomationHierarchicalInformationRelationshipService;

import groovy.util.logging.Slf4j;

/**
 * @author yangl
 *
 */
@Controller
@RequestMapping("/controlChartHierarchicalInformationRelationship")
@Slf4j
@CrossOrigin
public class ControlChartInfomationHierarchicalInformationRelationshipController {
	@Autowired
	private IControlChartInfomationHierarchicalInformationRelationshipService relationService;


	/**
	 * 控制图层次信息关联修改
	 * 
	 * @param relation
	 * @return
	 */
	@RequestMapping(value = "/update.action", method = RequestMethod.POST)
	@ResponseBody
	public Object update(ControlChartInfomationHierarchicalInformationRelationship relation) {
		return AppUtil.conversionJsonp(relationService.alterRelationship(relation));
	}

	/**
	 * 控制图层次信息关联查询
	 * 
	 * @param controlChartId
	 * @return
	 */
	@RequestMapping(value = "/search.action", method = RequestMethod.GET)
	@ResponseBody
	public Object search(Integer controlChartId) {
		return AppUtil.conversionJsonp(relationService.searchRelationship(controlChartId));
	}
}
