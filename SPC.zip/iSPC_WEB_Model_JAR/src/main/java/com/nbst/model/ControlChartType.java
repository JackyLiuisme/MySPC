package com.nbst.model;

public class ControlChartType {
	private Integer kztlxId;
	// 控制图名称
	private String kztlxName;
	// 是否检测不良项
	private Integer kztlxPoorDefinitionState;
	// 控制图创建时间
	private Long kztlxCreateTime;

	private String kztlxExtend1;

	private String kztlxExtend2;

	private String kztlxExtend3;

	private String kztlxExtend4;

	private String kztlxExtend5;

	public Integer getKztlxId() {
		return kztlxId;
	}

	public void setKztlxId(Integer kztlxId) {
		this.kztlxId = kztlxId;
	}

	public String getKztlxName() {
		return kztlxName;
	}

	public void setKztlxName(String kztlxName) {
		this.kztlxName = kztlxName == null ? null : kztlxName.trim();
	}

	public Integer getKztlxPoorDefinitionState() {
		return kztlxPoorDefinitionState;
	}

	public void setKztlxPoorDefinitionState(Integer kztlxPoorDefinitionState) {
		this.kztlxPoorDefinitionState = kztlxPoorDefinitionState;
	}

	public Long getKztlxCreateTime() {
		return kztlxCreateTime;
	}

	public void setKztlxCreateTime(Long kztlxCreateTime) {
		this.kztlxCreateTime = kztlxCreateTime;
	}

	public String getKztlxExtend1() {
		return kztlxExtend1;
	}

	public void setKztlxExtend1(String kztlxExtend1) {
		this.kztlxExtend1 = kztlxExtend1 == null ? null : kztlxExtend1.trim();
	}

	public String getKztlxExtend2() {
		return kztlxExtend2;
	}

	public void setKztlxExtend2(String kztlxExtend2) {
		this.kztlxExtend2 = kztlxExtend2 == null ? null : kztlxExtend2.trim();
	}

	public String getKztlxExtend3() {
		return kztlxExtend3;
	}

	public void setKztlxExtend3(String kztlxExtend3) {
		this.kztlxExtend3 = kztlxExtend3 == null ? null : kztlxExtend3.trim();
	}

	public String getKztlxExtend4() {
		return kztlxExtend4;
	}

	public void setKztlxExtend4(String kztlxExtend4) {
		this.kztlxExtend4 = kztlxExtend4 == null ? null : kztlxExtend4.trim();
	}

	public String getKztlxExtend5() {
		return kztlxExtend5;
	}

	public void setKztlxExtend5(String kztlxExtend5) {
		this.kztlxExtend5 = kztlxExtend5 == null ? null : kztlxExtend5.trim();
	}

	@Override
	public String toString() {
		return "ControlChartType [kztlxId=" + kztlxId + ", kztlxName=" + kztlxName + ", kztlxPoorDefinitionState="
				+ kztlxPoorDefinitionState + ", kztlxCreateTime=" + kztlxCreateTime + ", kztlxExtend1=" + kztlxExtend1
				+ ", kztlxExtend2=" + kztlxExtend2 + ", kztlxExtend3=" + kztlxExtend3 + ", kztlxExtend4=" + kztlxExtend4
				+ ", kztlxExtend5=" + kztlxExtend5 + "]";
	}

}