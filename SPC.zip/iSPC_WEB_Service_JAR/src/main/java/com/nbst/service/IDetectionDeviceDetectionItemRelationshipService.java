package com.nbst.service;

import com.nbst.model.DetectionDeviceDetectionItemRelationship;

/**
 * @author yangl
 *
 */
public interface IDetectionDeviceDetectionItemRelationshipService {
	// 检测设备检测项关联新增
	Object add(DetectionDeviceDetectionItemRelationship relation);

	// 检测设备检测项关联修改/删除
	Object alter(DetectionDeviceDetectionItemRelationship relation,Integer state);

	// 检测设备检测项关联查询
	Object search(Integer limit, Integer offset);
}
